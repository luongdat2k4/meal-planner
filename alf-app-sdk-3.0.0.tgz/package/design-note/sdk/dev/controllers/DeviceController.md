# `DeviceController` — Thiết bị & Haptics

## Vai trò

Quản lý tập trung thông tin thiết bị (Device ID, OS version, model, screen size, phone/tablet, safe-area insets) và phản hồi xúc giác (Haptics).

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Lấy thông tin thiết bị + screen size + safe area |
| `refresh()` | — | `Promise<void>` | Refresh lại thông tin thiết bị |
| `getOSVersion()` | — | `string` | Lấy OS version |
| `getDeviceId()` | — | `string` | Lấy device UUID |
| `getScreenSize()` | — | `ScreenSize` | Lấy kích thước màn hình (CSS pixels + physical) |
| `isPhone()` | — | `boolean` | Kiểm tra có phải phone (< 600px width) |
| `isTablet()` | — | `boolean` | Kiểm tra có phải tablet (≥ 600px width) |
| `vibrate(type)` | `HapticType` | `Promise<void>` | Rung với kiểu predefined |
| `tap()` | — | `Promise<void>` | Rung nhẹ (light haptic) |

---

## Cấu trúc dữ liệu

```typescript
interface DeviceInfo {
  deviceId: string
  os: string
  osVersion: string
  model: string
  platform: 'ios' | 'android' | 'web'
  manufacturer: string
  isVirtual: boolean
  appVersion: string
  appBuild: string
}

interface ScreenSize {
  width: number    // screen width in CSS pixels
  height: number   // screen height in CSS pixels
  scale: number    // devicePixelRatio
  widthPx: number  // physical width in pixels
  heightPx: number // physical height in pixels
}

interface SafeAreaInsets {
  top: number
  right: number
  bottom: number
  left: number
}

type HapticType = 'light' | 'medium' | 'heavy' | 'selection' | 'success' | 'warning' | 'error'
```

## Dependencies

- `@capacitor/device` — thông tin thiết bị
- `@capacitor/haptics` — phản hồi xúc giác

## Lưu ý

- `isPhone()` / `isTablet()` dùng heuristic: width < 600 CSS pixels → phone, ngược lại tablet
- Trên iOS kiểm tra thêm model name có "iPad" không
- `safeArea` đọc từ CSS custom properties `--sat`, `--sar`, `--sab`, `--sal`
- `screenSize` đọc từ `window.screen` + `devicePixelRatio`
- Haptics silent fail trên web — không throw error
