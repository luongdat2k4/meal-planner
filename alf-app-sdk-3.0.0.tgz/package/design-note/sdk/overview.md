# ALF Framework — Tổng quan kiến trúc

## 1. Triết lý thiết kế

**ALF Framework** là một lớp trừu tượng (abstraction layer) cho ứng dụng **Capacitor**, đóng vai trò là "Swiss Army knife" — mọi chức năng của app đều truy cập qua một điểm vào duy nhất: **Singleton `ALF`** ([ALF.ts.md](dev/ALF.ts.md)).

```text
src/main.ts  ──>  initSDK(config)  ──>  ALF (singleton)
                                          ├── ALF.Config          (ConfigManager)
                                          ├── ALF.Ads             (AdController)
                                          ├── ALF.Camera          (CameraController)
                                          ├── ALF.Permission      (PermissionController)
                                          ├── ALF.Storage         (StorageController)
                                          ├── ALF.Firebase        (FirebaseController)
                                          ├── ALF.Analytics       (AnalyticsController)
                                          ├── ALF.Share           (ShareController)
                                          └── ALF.Media           (MediaController)
```

Mỗi controller là một **class riêng biệt**, tuân thủ **OOP**, có thể gọi lẫn nhau khi cần (xem pseudo-code tại [controllers/](../controllers/)). Ví dụ: `ShareController` có thể gọi `MediaController` để capture ảnh rồi share.

Toàn bộ cấu hình của framework (key, settings, feature flag) được truyền vào qua tham số `config` của `initSDK(config)`. **ConfigManager** (`ALF.Config`) lưu config này trong memory — không controller nào đọc file trực tiếp.

## 2. Luồng config

```text
config.json (mỗi repo tự có)
       │
       ▼  (ConfigConverter.convertFromJSON)
initSDK({ settings, keys })
       │
       ▼  (ALF.Config.set(config))
ConfigManager — trong memory
       │
       ├── AdController        ──  this.af.Config.get('keys.applovin')
       ├── AnalyticsController  ──  this.af.Config.get('keys.appsflyer')
       ├── FirebaseController   ──  this.af.Config.get('keys.firebase')
       └── mọi controller       ──  this.af.Config.get('settings')
```

## 3. Yêu cầu từ thiết kế

- **`initSDK(config)`** được gọi từ `main.ts`, nhận object config (key + settings), tự động khởi tạo toàn bộ SDK.
- Dự án gọi qua cú pháp: `ALF.Ads.InitBannerAd()` hoặc `ALF.Camera.Take()`.
- Mỗi module có `Controller` riêng, dễ mở rộng, dễ maintain.
- Controllers có thể phụ thuộc chéo (cross-dependency).
- Config được set trước mọi controller, controller đọc qua **`ALF.Config`**.
- Có `ConfigConverter` để chuyển một file JSON bất kỳ thành config object hợp lệ.

## 4. Actors & vai trò

| Actor | Vai trò |
|---|---|
| **`ALF`** | Singleton global. Chứa ConfigManager + tất cả controller. |
| **`initSDK(config)`** | Hàm khởi tạo duy nhất, nhận object config. |
| **ConfigManager** | Module trong ALF, lưu config trong memory, cung cấp `get(path)`. |
| **ConfigConverter** | Utility: đọc file JSON → parse + merge defaults → object config hợp lệ. |
| **`*Controller`** | Class quản lý 1 nhóm chức năng (Ads, Camera, Storage...). |

## 5. Cấu trúc Config object

```text
{
  "settings": {
    "dev": true,             // chế độ dev (debug log, sandbox)
    "isGame": false,         // app thuộc dạng game?
    "isApp": true,           // app thuộc dạng ứng dụng?
    "appName": "MyApp",
    "appVersion": "1.0.0",
    "environment": "production"   // "dev" | "staging" | "production"
  },
  "keys": {
    "applovin": { android: { sdkKey, banner, ... }, ios: { ... } },
    "admob":    { android: { appId, banner, ... }, ios: { ... } },
    "appsflyer": { devKey, iosAppId, androidAppId },
    "firebase":  { apiKey, projectId, appId, messagingSenderId }
  }
}
```

- `settings`: các tham số bật/tắt tính năng, cấu hình chung.
- `keys`: tất cả API/SDK keys, ad unit IDs.

## 6. Luồng khởi tạo

```text
main.ts
  └─> initSDK(config)
        │
        ├─> ALF.Config.set(config)    [ConfigManager — lưu vào memory]
        │
        ├─> ALF.Permission.RequestTracking()  [iOS ATT]
        ├─> ALF.Analytics.init()    [AppsFlyer — dùng config.keys.appsflyer]
        ├─> ALF.Ads.init()          [AppLovin MAX — dùng config.keys.applovin]
        ├─> ALF.Firebase.init()     [Firebase Remote Config]
        ├─> ALF.Storage.init()      [Capacitor Filesystem Database]
        ├─> ALF.Permission.init()
        ├─> ALF.Camera.init()
        ├─> ALF.Share.init()
        └─> ALF.Media.init()
```

Sau khi `initSDK()` hoàn tất, app mới mount Vue app thông qua `app.mount('#app')`.

## 7. ConfigConverter — Từ JSON đến object

Mỗi repo có file `config.json` riêng (cấu trúc tuỳ ý). Framework cung cấp hàm `convertFromJSON()` để:

1. Đọc file JSON từ path bất kỳ.
2. Parse và map các field vào cấu trúc Config chuẩn.
3. Merge với default values cho các field thiếu.
4. Trả về object `Config` hợp lệ để truyền vào `initSDK()`.

```pseudo
// Mỗi repo có thể có cấu trúc config.json khác nhau, VD:
// { "ads": { "max": { "androidSdkKey": "xxx" } } }
// 
// Framework convert:
config = ConfigConverter.convertFromJSON('path/to/config.json', {
  mappings: {
    'ads.max.androidSdkKey': 'keys.applovin.android.sdkKey',
    'appsflyer.devKey':      'keys.appsflyer.devKey'
  },
  defaults: {
    settings: { dev: false, isGame: false, isApp: true }
  }
})

// Sau đó truyền thẳng vào initSDK:
initSDK(config)
```

## 8. Nguyên tắc

- **OOP**: mỗi controller là một class, đóng gói logic + state.
- **Single Responsibility**: mỗi controller chỉ quản lý 1 nhóm chức năng.
- **Dependency Injection qua `ALF`**: controller lấy instance controller khác qua `ALF.Instance`.
- **Config Separation of Concerns**: config tập trung ở ConfigManager, controller không biết nguồn gốc config.
- **Lazy initialization**: một số controller có thể init sau (khi dùng lần đầu) nếu không cần thiết cho startup.
