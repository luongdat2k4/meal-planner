# App Data — lưu trạng thái người dùng

## 1. Mục đích

Lưu **trạng thái đã hoàn thành onboarding / chọn ngôn ngữ** và **ngôn ngữ đã chọn** vào thiết bị, để lần sau mở app không phải làm lại các bước đó.

## 2. Cấu trúc dữ liệu

Dữ liệu được lưu trong `app-data.json` thông qua `StorageController` (Capacitor Filesystem).

```typescript
interface AppPersistedData {
  /** Ngôn ngữ người dùng đã chọn (ví dụ: 'vi', 'en') */
  locale: string | null
  /** Đã chọn ngôn ngữ lần đầu qua màn ChooseLanguage? */
  languageChosen: boolean
  /** Đã xem hết màn Onboarding? */
  onboardingCompleted: boolean
}
```

## 3. AppData utility class

**File:** `src/af/utils/AppData.ts`

- `AppData.load()` — đọc `app-data.json` từ Filesystem, trả về `AppPersistedData` (default nếu chưa có).
- `AppData.save(data)` — ghi toàn bộ `AppPersistedData` vào Filesystem.
- Các method helper:
  - `setLocale(locale)` — lưu locale + đánh dấu `languageChosen = true`
  - `completeOnboarding()` — đánh dấu `onboardingCompleted = true`
  - `resetAll()` — xoá file, reset toàn bộ

## 4. Luồng boot (main.ts)

```
main.ts bootApp()
  │
  ├─ initSDK(config)
  │
  ├─ AppData.load()
  │     │
  │     ├─ Nếu languageChosen = true  → skip ChooseLanguage
  │     ├─ Nếu onboardingCompleted = true → skip Onboarding
  │     └─ Cả 2 đều false → flow bình thường
  │
  └─ navigateTo(destination)
```

## 5. Khi user hoàn thành màn hình

### ChooseLanguageView
- User chọn ngôn ngữ + bấm Xác nhận
- Gọi `AppData.setLocale(code)` lưu locale + đánh dấu languageChosen = true
- Chuyển đến Onboarding hoặc Home

### OnboardingView
- User bấm "Bắt đầu" hoặc "Bỏ qua"
- Gọi `AppData.completeOnboarding()`
- Chuyển đến Home

## 6. Reset data (Home mẫu)

Nút "Reset Data" ở màn Home gọi `AppData.resetAll()`, xoá toàn bộ dữ liệu đã lưu. Khi tải lại app, user sẽ thấy lại màn ChooseLanguage → Onboarding.

Dùng để mô phỏng việc user vào Settings → Xoá dữ liệu app (Clear Data) trên thiết bị thật.
