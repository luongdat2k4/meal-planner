# Native video ad (AdMob)

**Ngày:** 2026-09-24 · **Version:** 1.2.0 (chưa publish) · **Nối tiếp:** [2026-09-22-native-ad-events-lifecycle.md](2026-09-22-native-ad-events-lifecycle.md)

Template `medium` đã có `MediaView` từ `d153fc9`, nên creative video **đã tự phát** được. Việc còn
thiếu là mọi thứ quanh player: không chỉnh được request, không biết video đang làm gì, không điều
khiển được. Note này ghi lại đã thêm gì và vì sao.

---

## Đã làm

| Hạng mục | Android | iOS |
|---|---|---|
| Video options trong request | `VideoOptions.Builder` → `NativeAdOptions.setVideoOptions` | `VideoOptions` trong `options:` của `AdLoader` |
| Media aspect ratio | `NativeAdOptions.setMediaAspectRatio(NATIVE_MEDIA_ASPECT_RATIO_*)` | `NativeAdMediaAdLoaderOptions.mediaAspectRatio` |
| Event video → `OnNativeAdVideoEvent` | `VideoController.VideoLifecycleCallbacks` | `VideoControllerDelegate` |
| `playNativeAdVideo` / `pauseNativeAdVideo` / `muteNativeAdVideo` | `VideoController.play/pause/mute` (UI thread) | `VideoController.play/pause/setMute` (main) |
| `NativeAdData` thêm `mediaAspectRatio`, `videoDuration`, `videoCustomControlsEnabled` | `MediaContent` | `MediaContent` |

Tầng JS: `NativeAdLoadOptions` (`video`, `mediaAspectRatio`) cho `ShowAdMobNativeAd` /
`LoadAdMobNativeAd`; event `{ type: 'video', state }`; `PlayAdMobNativeAdVideo`,
`PauseAdMobNativeAdVideo`, `SetAdMobNativeAdVideoMuted`. Test view có chip Media image/video,
`startMuted`, `customControls`, nút Play/Pause/Mute/Unmute và tag trạng thái video.

## Quyết định

- **Option chốt lúc load, không lúc show.** Google SDK đưa `VideoOptions` vào `AdLoader`, không có
  API đổi sau khi ad đã về. Nên `ShowAdMobNativeAd({ video })` chỉ có tác dụng khi chính lời gọi đó
  phải load; ad preload giữ option cũ. Ghi rõ trong JSDoc thay vì âm thầm reload (reload = mất ad đã
  có, thêm một request).
- **`startMuted` mặc định `true`** — cũng là default của SDK, và là khuyến nghị của AdMob cho ad tự
  phát trong feed. Truyền tường minh để không phụ thuộc default của từng bản SDK.
- **Một event `OnNativeAdVideoEvent` có `state`**, không phải 6 event riêng: 6 overload `addListener`
  + 6 listener chỉ để chuyển tiếp cùng một payload là thừa.
- **`start` chỉ Android.** iOS `VideoControllerDelegate` không có callback tương ứng; không giả lập
  bằng "play đầu tiên" vì sau `end` → replay sẽ lại là play đầu tiên của một chu kỳ mới, dễ sai.
- **Play/Pause/Mute không bị chặn khi không có custom controls**, chỉ tài liệu hóa rằng player có
  thể bỏ qua. Chặn cứng dựa trên `isCustomControlsEnabled` sẽ bịa ra một ràng buộc mà chưa verify
  được trên device.
- **Test unit video riêng cho dev mode.** Test unit native thường gần như không trả video, nên khi
  request có `video` thì dev mode dùng test unit native video. Đi theo precedent
  `getAdMobTestBannerId(size, collapsible)` (chọn test unit theo option). Production vẫn một unit.
- **Test unit tách theo nền tảng.** `ADMOB_TEST_AD_UNIT_IDS.native` cũ là id Android nhưng được dùng
  cả trên iOS — sửa luôn vì đằng nào cũng phải thêm id video theo nền tảng.
- **`nativeAdActiveAdUnitId`**: vì unit giờ có thể khác config, destroy / điều khiển video phải đi
  theo unit thực sự đang giữ ad. Request sang unit khác → destroy ad unit cũ trước (nếu không, ad cũ
  nằm lại trên màn hình mà controller không còn trỏ tới). Request không có `video` giữ unit hiện tại
  để `ShowAdMobNativeAd()` trơn hiện lại được ad video đã ẩn.

## Sửa kèm (bug có sẵn)

- **iOS không compile được**: `nativeAd.mediaContent?.hasVideoContent` và
  `if let mediaContent = nativeAd.mediaContent` — `mediaContent` là non-optional trong GMA SDK 12
  (Swift báo lỗi khi optional-chain / `if let` trên non-optional). Chưa ai build iOS nên chưa lộ.

## Kiểm chứng đã làm

| Hạng mục | Kết quả |
|---|---|
| `npm run type-check` | ✅ pass |
| `npm run build` | ✅ pass |
| `javac` `ALFAdMobPlugin.java` với jar thật `play-services-ads(-api) 25.4.0` + `android.jar` 35 (stub cho class Capacitor và `R`) | ✅ pass — mọi API Google dùng đều tồn tại đúng signature; warning deprecation đều là code cũ |
| Gradle build app thật | ❌ chưa — `src-dev/node_modules` chưa cài |
| Compile iOS | ❌ chưa — cần Mac |

## Còn phải verify trên device

1. **Android + iOS**: chọn Media = video, template `medium`, Show → log `EVENT loaded · VIDEO …`,
   video tự phát không tiếng, có `EVENT video — play` (Android thêm `start`).
2. **iOS**: `VideoControllerDelegate` là `@objc` protocol với method optional — sai tên là im lặng.
   Phải thấy `EVENT video` trên device, không suy ra từ build pass. Kiểm tra luôn giả định
   `mediaContent` non-optional khi build.
3. **Play/Pause/Mute khi không có custom controls**: ghi lại player có phản hồi hay không → cập nhật
   JSDoc cho chắc chắn thay vì "có thể bỏ qua".
4. **Background**: video có dừng tiếng khi app xuống nền không (điều kiện để quyết định có cần
   `handleOnPause` / `handleOnResume` — vẫn còn treo từ note trước). Nếu cần, có thể dùng
   `pauseNativeAdVideo` từ JS ở `appStateChange` như giải pháp tạm.
5. **`HideAdMobNativeAd()`** với video đang phát tiếng: view `GONE` / `isHidden` có làm player dừng.

## Chưa làm (cố ý)

- Template `small` không có media view — creative video vẫn hiện nhưng chỉ icon/text. Thêm media
  vào `small` sẽ phá chiều cao ~80dp của nó.
- Chưa đổi tỉ lệ `MediaView` theo `mediaAspectRatio` ở tầng native; JS nhận `mediaAspectRatio` để tự
  đặt chiều cao placeholder.
- Test unit id của interstitial / rewarded / app open vẫn là id Android dùng chung cho iOS — cùng lỗi
  như native đã sửa ở đây, chưa đụng vì ngoài phạm vi.
