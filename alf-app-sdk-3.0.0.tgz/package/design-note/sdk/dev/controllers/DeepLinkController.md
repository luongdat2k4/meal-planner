# `DeepLinkController` — Deep Link

## Vai trò

Bắt **App Links / Universal Links**, phân tích URL và điều hướng đến đúng màn hình trong app. Cần thiết cho marketing campaign và trải nghiệm liền mạch.

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Lấy launch URL + lắng nghe `appUrlOpen` |
| `onLink(listener)` | `(DeepLinkData) => void` | `() => void` | Subscribe deep link → trả về unsubscribe fn |
| `dispatch(url)` | string | `void` | Phát deep link thủ công (test) |
| `disconnect()` | — | `void` | Dừng lắng nghe, cleanup |

---

## Luồng

```mermaid
flowchart TD
    A["appUrlOpen event"] --> B["new URL(url)"]
    B --> C["Parse path + queryParams + host + scheme"]
    C --> D["Lưu _lastLink"]
    D --> E["Notify listeners"]
    E --> F["Vue Router navigate theo path"]
```

---

## Cấu trúc dữ liệu

```typescript
interface DeepLinkData {
  url: string
  path: string
  queryParams: Record<string, string>
  host: string | null
  scheme: string | null
}
```

## Dependencies

- `@capacitor/app` — `appUrlOpen`, `getLaunchUrl()`

## Lưu ý

- Xử lý cả cold start (app chưa chạy) qua `getLaunchUrl()` và warm start qua `appUrlOpen`
- `dispatch()` cho phép test deep link trên web
- Kết hợp `NotificationController.onPushTapped` + `DeepLinkController` để routing chính xác
