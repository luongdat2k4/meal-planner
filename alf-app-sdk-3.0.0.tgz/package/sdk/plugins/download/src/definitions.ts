export interface DownloadResult {
  /** Absolute path where the file was saved on the device. */
  path: string
}

export interface DownloadToDeviceOptions {
  /** HTTP/HTTPS url to download. */
  url: string
  /**
   * Path relative to the system Download folder (Android) or the app's
   * Documents folder (iOS). Nested folders are created automatically.
   */
  targetPath: string
}

export interface DownloadToAppOptions {
  /** HTTP/HTTPS url to download. */
  url: string
  /**
   * Path relative to the app's private storage root, e.g. "models/llama.bin".
   * Nested folders are created automatically.
   */
  relativePath: string
}

export interface DownloadProgressEvent {
  /** The url being downloaded. */
  url: string
  /** Bytes received so far. */
  receivedBytes: number
  /** Total bytes, or 0 when the server didn't send a Content-Length. */
  totalBytes: number
  /** Download progress in range 0..1. */
  progress: number
}

export interface ExistsResult {
  exists: boolean
}

export interface PluginListenerHandle {
  remove: () => void
}

export interface ALFDownloadPlugin {
  /**
   * Download a file into the system Download folder (Android) / app Documents
   * (iOS), relative to that folder. Returns the absolute path of the file.
   */
  downloadToDevice(options: DownloadToDeviceOptions): Promise<DownloadResult>

  /**
   * Download a file into the app's private storage under `relativePath`.
   * Returns the absolute path, suitable for loading by native code (e.g. an
   * on-device AI model).
   */
  downloadToApp(options: DownloadToAppOptions): Promise<DownloadResult>

  /** Resolve the absolute path a `relativePath` would map to inside app storage. */
  getAppPath(options: { relativePath: string }): Promise<DownloadResult>

  /** Check whether a file already exists inside app storage. */
  isAppFileExists(options: { relativePath: string }): Promise<ExistsResult>

  addListener(
    eventName: 'OnDownloadProgress',
    listenerFunc: (event: DownloadProgressEvent) => void,
  ): Promise<PluginListenerHandle>

  removeAllListeners(): Promise<void>
}
