# Firebase — Hướng dẫn cấu hình cho dự án dùng `@alf/app-sdk`

Tài liệu này hướng dẫn cách thêm Firebase vào dự án đang dùng `@alf/app-sdk`, bao gồm:

- File cấu hình native (`google-services.json` cho Android, `GoogleService-Info.plist` cho iOS)
- API keys trong `config.json` (dùng cho Remote Config runtime)

---

## 1. Tổng quan

`@alf/app-sdk` sử dụng Firebase cho **Remote Config** (kiểm soát tính năng từ xa).  
Firebase có **2 lớp cấu hình riêng biệt**, cả hai đều bắt buộc:

| Lớp | File / Nơi điền | Mục đích |
|---|---|---|
| Native (Android) | `google-services.json` | Xác thực thiết bị với Firebase, bắt buộc để Firebase SDK native hoạt động |
| Native (iOS) | `GoogleService-Info.plist` | Tương tự cho iOS |
| Runtime (JS) | `config.json` → `keys.firebase` | Cung cấp `apiKey`, `projectId`, `appId` cho `@alf/app-sdk` khởi tạo Remote Config |

---

## 2. Lấy file cấu hình từ Firebase Console

### 2.1. Tạo / chọn project

1. Vào [Firebase Console](https://console.firebase.google.com/)
2. Chọn project (hoặc tạo mới → **Add project**)
3. Làm theo hướng dẫn: đặt tên project, bật/tắt Google Analytics
4. Sau khi project được tạo, click vào **Android** hoặc **iOS** icon để thêm app

### 2.2. Thêm app Android

1. **Register app**: nhập **Android package name** (ví dụ `com.example.myapp`)
   - Package name phải **khớp** với `appId` trong `capacitor.config.ts` / `capacitor.config.json`
2. **Download config**: nhấn **Download google-services.json**
3. Bỏ qua các bước còn lại (thêm SDK, code mẫu) — `@alf/app-sdk` đã lo phần đó

### 2.3. Thêm app iOS

1. **Register app**: nhập **iOS bundle ID** (ví dụ `com.example.myapp`)
   - Bundle ID phải **khớp** với trong Xcode project
2. **Download config**: nhấn **Download GoogleService-Info.plist**
3. Bỏ qua các bước còn lại

---

## 3. Đặt file native vào dự án

### 3.1. Android — `google-services.json`

Đặt file tại thư mục gốc của Android platform:

```
thư-mục-dự-án/
└── android/
    └── app/
        └── google-services.json    ← Đặt ở đây
```

> Đường dẫn đầy đủ: `android/app/google-services.json`

### 3.2. iOS — `GoogleService-Info.plist`

Đặt file tại thư mục gốc của iOS platform:

```
thư-mục-dự-án/
└── ios/
    └── App/
        └── GoogleService-Info.plist    ← Đặt ở đây
```

> Đường dẫn đầy đủ: `ios/App/GoogleService-Info.plist`

**Sau khi đặt file, chạy:**

```bash
npx cap sync
```

Câu lệnh này copy file cấu hình vào đúng vị trí trong native project.

---

## 4. Điền Firebase keys vào `config.json`

Firebase keys dùng cho **Remote Config runtime** (JS layer).  
Mở file `config.json` (hoặc file config tương ứng của dự án) và điền vào phần `keys.firebase`:

```json
{
  "keys": {
    "firebase": {
      "apiKey": "AIzaSy...",
      "projectId": "my-app-12345",
      "appId": "1:123456789:android:abc123def456",
      "messagingSenderId": "123456789"
    }
  }
}
```

### 4.1. Lấy giá trị từ Firebase Console

Sau khi thêm app Android/iOS, vào **Project Settings** (⚙️ → **Project settings**):

1. **General** tab → mục **Your apps** → chọn app Android hoặc iOS
2. Trong phần **SDK setup and configuration**, chọn tab **Config**
3. Các giá trị cần lấy:

| Trong config.json | Firebase Console | Trong google-services.json |
|---|---|---|
| `apiKey` | `apiKey` (Web API Key) | `api_key` |
| `projectId` | `projectId` | `project_id` |
| `appId` | `appId` (mobilesdk_app_id) | `mobilesdk_app_id` |
| `messagingSenderId` | `projectNumber` → **Project Settings > General > Project number** | `project_number` |

### 4.2. Kiểm tra cấu trúc config

```json
{
  "settings": {
    "dev": false,
    "isApp": true,
    "appName": "MyApp",
    "appVersion": "1.0.0",
    "environment": "production"
  },
  "keys": {
    "firebase": {
      "apiKey": "AIzaSy...",
      "projectId": "my-app-12345",
      "appId": "1:123456789:android:abc123def456",
      "messagingSenderId": "123456789"
    }
  }
}
```

---

## 5. Cách SDK xử lý Firebase

Khi `initSDK(config)` được gọi, `FirebaseController` (trong `@alf/app-sdk`) sẽ:

1. **Đọc `keys.firebase`** từ config — nếu thiếu `apiKey`, `projectId`, hoặc `appId` → **bỏ qua**, không init Firebase (không crash)
2. **Gọi `FirebaseRemoteConfig.fetchAndActivate()`** — lấy Remote Config từ Firebase
3. Nếu fetch thất bại (do không có file native, không có network, keys sai) → **log warning**, app vẫn chạy bình thường

> **App sẽ không crash nếu thiếu Firebase config.** SDK xử lý graceful degradation.

### 5.1. Khi nào Firebase thực sự cần?

Firebase chỉ cần cho **Remote Config** — các tính năng khác của app (ads, analytics, mua hàng...) **vẫn hoạt động** nếu Firebase bị skipped.

Nếu project của bạn **không dùng** Remote Config, bạn có thể bỏ qua hoàn toàn bước cấu hình Firebase.

---

## 6. Kiểm tra Firebase đã hoạt động

### 6.1. Trên Android

Chạy app và kiểm tra logcat:

```bash
# Hoặc mở Android Studio → Logcat
adb logcat | grep -i firebase
```

Kỳ vọng thấy:

```
[FirebaseController] Remote Config fetched & activated
```

Nếu thấy:

```
[FirebaseController] Firebase keys missing or empty — skipping init
```

→ Chưa điền keys trong `config.json`.

Nếu thấy:

```
[FirebaseController] init error — Firebase disabled: ...
```

→ File native (`google-services.json`) chưa được đặt đúng vị trí hoặc chưa chạy `npx cap sync`.

### 6.2. Trên iOS

Mở Xcode, chạy app và kiểm tra console log tương tự.

---

## 7. Troubleshooting

### `google-services.json` không được copy vào APK

```bash
# Kiểm tra file có tồn tại không
ls android/app/google-services.json

# Sync lại
npx cap sync android

# Nếu vẫn không được, kiểm tra build.gradle có plugin google-services không:
# file: android/app/build.gradle
# Phải có dòng:
#   apply plugin: 'com.google.gms.google-services'
```

### `GoogleService-Info.plist` không được copy vào IPA

```bash
# Kiểm tra file có tồn tại không
ls ios/App/GoogleService-Info.plist

# Sync lại
npx cap sync ios
```

### Remote Config trả về null / không fetch được

1. Kiểm tra `config.json` có đúng 4 keys: `apiKey`, `projectId`, `appId`, `messagingSenderId`
2. Kiểm tra file native đã đặt đúng vị trí
3. Vào Firebase Console → **Remote Config** → tạo ít nhất 1 parameter mẫu
4. Đảm bảo thiết bị có kết nối mạng

### Firebase keys lộ trên client

Firebase keys (đặc biệt là `apiKey`) được thiết kế để public (xem [Firebase security FAQ](https://firebase.google.com/docs/functions/secure-api#understand_your_api_key)).  
Tuy nhiên, để an toàn hơn, bạn có thể:

- **App Check**: bật trong Firebase Console để chặn request từ thiết bị không hợp lệ
- **Security Rules**: thiết lập rule cho Firestore / Realtime Database nếu dùng

---

## 8. Tóm tắt các bước

1. Tạo project trên Firebase Console
2. Thêm app Android → download `google-services.json` → đặt vào `android/app/`
3. Thêm app iOS → download `GoogleService-Info.plist` → đặt vào `ios/App/`
4. Chạy `npx cap sync`
5. Lấy `apiKey`, `projectId`, `appId`, `messagingSenderId` từ Project Settings
6. Điền vào `config.json` → `keys.firebase`
7. Chạy app — kiểm tra log thấy `Remote Config fetched & activated`
