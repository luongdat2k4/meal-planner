# `CameraController` — Chụp ảnh & Live Preview

## Vai trò

Cung cấp khả năng chụp ảnh qua **Capacitor Camera plugin** và live preview camera qua **WebRTC**. Tự động kiểm tra và xin quyền camera thông qua `PermissionController`.

> **Lưu ý:** Chức năng pick ảnh/video từ gallery đã được chuyển sang `FileController`.
> Xem `ALF.Instance.File.PickFromGallery()`.

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | No-op (Capacitor đã có sẵn) |
| `Take(options?)` | `CameraOptions` | `Promise<string>` | Chụp ảnh → base64. Tự xin quyền camera trước. |
| `startLivePreview(videoEl, options?)` | `HTMLVideoElement`, `LiveCameraOptions` | `Promise<void>` | Bật live preview camera (WebRTC) |
| `captureSnapshot(cropToSquare?)` | `boolean?` | `LiveCameraSnapshot \| null` | Chụp frame từ live preview |
| `stopLivePreview()` | — | `void` | Tắt live preview, giải phóng stream |
| `isLiveActive` | — | `boolean` (getter) | Kiểm tra live preview đang hoạt động |

---

## Dependencies

- **PermissionController**: xin quyền camera trước khi chụp
- Output thường truyền sang **ShareController** hoặc **StorageController**

---

## Cách dùng

```typescript
// Chụp ảnh
const imageBase64 = await ALF.Instance.Camera.Take({ quality: 80 })

// Live preview (in-app camera UI)
const videoEl = document.getElementById('preview') as HTMLVideoElement
await ALF.Instance.Camera.startLivePreview(videoEl, { facingMode: 'environment' })

// Chụp snapshot từ live preview
const snap = ALF.Instance.Camera.captureSnapshot(true) // crop vuông
if (snap) console.log(snap.dataUrl)

// Tắt preview
ALF.Instance.Camera.stopLivePreview()
```

> Để pick ảnh/video từ gallery hoặc browse từ máy tính, dùng `ALF.Instance.File.*`.
