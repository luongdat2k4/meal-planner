package alf;

import android.os.Trace;

/**
 * Names the heavy plugin methods in a Perfetto / systrace capture as
 * "ALF.<method>", so a hitch can be traced to the ad call behind it.
 * beginSection/endSection are near-free when no trace is running.
 */
public final class ALFTrace {
    private ALFTrace() {}

    /** Run {@code body} inside a trace section on the calling thread. */
    public static void run(String section, Runnable body) {
        Trace.beginSection(section);
        try {
            body.run();
        } finally {
            Trace.endSection();
        }
    }

    /** A Runnable that traces itself on whichever thread it ends up running (e.g. runOnUiThread). */
    public static Runnable wrap(String section, Runnable body) {
        return () -> run(section, body);
    }
}
