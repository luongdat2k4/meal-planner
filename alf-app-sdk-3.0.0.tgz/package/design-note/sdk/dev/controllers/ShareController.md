# `ShareController` — Chia sẻ media

## Vai trò

Cung cấp khả năng chia sẻ ảnh, video, text và file ra các app khác. Dùng **Capacitor Share plugin** + **Capacitor Filesystem** để ghi media base64 vào cache trước khi mở Sharesheet.

Trên Android, controller dùng Sharesheet chuẩn của hệ điều hành. Các đích như mạng xã hội, Google Drive, Gmail và ứng dụng liên lạc sẽ tự xuất hiện nếu đã cài và khai báo nhận MIME của media (`image/*` hoặc `video/*`). Controller không hard-code package name của app đích.

## Sử dụng

```ts
// Ảnh base64 / data URL
await ALF.Instance.Share.ShareImage(imageBase64, 'anh-chia-se.png', {
  title: 'Ảnh của tôi',
  dialogTitle: 'Chia sẻ ảnh đến',
})

// Video Blob từ MediaController (cũng nhận base64 / data URL)
const video = await ALF.Instance.Media.CreateSlideshowVideo(deps, options)
await ALF.Instance.Share.ShareVideo(video.blob, `clip.${video.ext}`)

// Video đã có trong filesystem native
await ALF.Instance.Share.ShareVideo('file:///data/user/0/my.app/cache/clip.mp4')

// API tổng quát, MIME type là bắt buộc
const result = await ALF.Instance.Share.ShareMedia({
  uri: 'file:///data/user/0/my.app/cache/photo.webp',
  mimeType: 'image/webp',
}, {
  text: 'Xem ảnh này nhé',
  dialogTitle: 'Chọn ứng dụng',
})

console.log(result.activityType) // package Android đã chọn, nếu hệ điều hành trả về
```

---

## Luồng ShareImage

```mermaid
flowchart TD
    A["ShareImage(base64Data, fileName?)"] --> B{"fileName?"}
    B -->|No| C["Tự tạo tên file từ base64 header<br/>image_timestamp.png"]
    B -->|Có| D["Dùng fileName"]
    C --> E["stripPrefix(base64Data)<br/><i>bỏ header data:image/...;base64,</i>"]
    D --> E
    
    E --> F{"platform === 'web'?"}
    F -->|Yes| G["shareImageOnWeb()"]
    F -->|No| H["shareImageOnNative()"]
    
    subgraph "Native"
        H --> H1["Filesystem.writeFile({<br/>  path: fileName,<br/>  data: pureBase64,<br/>  directory: CACHE<br/>})"]
        H1 --> H2["Share.share({<br/>  title: fileName,<br/>  files: [savedFile.uri]<br/>})"]
    end
    
    subgraph "Web"
        G --> G1["fetch(base64Data) → blob"]
        G1 --> G2["new File([blob], fileName)"]
        G2 --> G3{"navigator.canShare({files})?"}
        G3 -->|Yes| G4["navigator.share({ files: [file] })"]
        G3 -->|No| G5["triggerDownload(base64Data, fileName)<br/><i>fallback download</i>"]
    end
```

## Luồng ShareVideo / ShareMedia

`ShareVideo()` nhận Blob, raw base64, data URL hoặc `file://` URI. `ShareMedia()` là API tổng quát, nhận đúng một trong hai trường `data` hoặc `uri` và yêu cầu MIME `image/*` / `video/*`.

- Native + base64: ghi file vào `Directory.Cache/shared` rồi mở Sharesheet.
- Native + URI: chia sẻ trực tiếp file URI.
- Web + base64: dùng Web Share API; nếu trình duyệt không hỗ trợ chia sẻ file thì tải file xuống.
- Web + URI: không hỗ trợ vì trình duyệt không được đọc trực tiếp filesystem native.

## Luồng ShareText / ShareFile

```mermaid
flowchart LR
    A["ShareText(text, title?)"] --> B["Share.share({ title, text })"]
    C["ShareFile(fileUri, title?)"] --> D["Share.share({ title, files: [uri] })"]
```

## Luồng DownloadImage

```mermaid
flowchart TD
    A["DownloadImage(base64Data, fileName?)"] --> B{"platform?"}
    B -->|"web"| C["Tạo link download → click"]
    B -->|"native"| D["Ghi vào Directory.Documents"]
    D --> E["Return URI / fileName"]
```

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `CanShare()` | — | `Promise<boolean>` | Kiểm tra nền tảng có hỗ trợ chia sẻ |
| `ShareImage(base64, fileName?, options?)` | string, string, ShareOptions | `Promise<ShareResult>` | Chia sẻ ảnh, tương thích API cũ |
| `ShareVideo(dataOrUri, fileName?, options?)` | string, string, ShareOptions | `Promise<ShareResult>` | Chia sẻ video base64/data URL/file URI |
| `ShareMedia(media, options?)` | ShareMediaInput, ShareOptions | `Promise<ShareResult>` | API tổng quát cho ảnh hoặc video |
| `ShareText(text, title?)` | string, string | `Promise<ShareResult>` | Chia sẻ văn bản thuần |
| `ShareFile(fileUri, title?)` | string, string | `Promise<ShareResult>` | Chia sẻ file từ `file://` URI có sẵn |
| `DownloadImage(base64, fileName?)` | string, string | `Promise<string>` | Tải ảnh xuống thiết bị |

## Private helpers

| Hàm | Chức năng |
|---|---|
| `writeMediaToCache(data, fileName)` | Ghi media tạm vào CACHE và trả về URI |
| `shareMediaOnWeb(media, fileName, options)` | Blob → Web Share API → fallback download |

## Dependencies

- Có thể gọi **MediaController**: `this.af.Media.CaptureImage()` → lấy ảnh rồi share
- Có thể gọi **StorageController**: lấy file path trước khi share
