# Fix: Native ad events + lifecycle (AdMob)

**Ngày:** 2026-09-22 · **Version:** 1.1.31 → 1.2.0 (chưa publish) · **Nối tiếp commit:** `d153fc9`

Commit `d153fc9` chuyển native ad sang render bằng `NativeAdView` thật. Rà lại sau commit đó phát
hiện 2 lỗ hổng khiến việc chuyển đổi chưa hoàn chỉnh. Note này ghi lại **đã sửa gì và vì sao**.

---

## Bug 1 — Native ad hoàn toàn im lặng

### Triệu chứng

| Vấn đề | Bằng chứng trước khi sửa |
|---|---|
| 2 event "ma" | `definitions.ts` khai báo `OnAdLoadedEvent` / `OnAdFailedToLoadEvent`, nhưng `notifyListeners` ở native **chỉ có 2 event rewarded**. `addListener` compile được, trả handle hợp lệ, callback **không bao giờ chạy** — lỗi im lặng, không log, không warning |
| Android bỏ trống callback | `loadNativeAdInternal` chỉ override `onAdFailedToLoad`; `onAdImpression()` / `onAdClicked()` rơi vào no-op của lớp cha |
| iOS thiếu delegate | Plugin implement `NativeAdLoaderDelegate` + `FullScreenContentDelegate`, **không** implement `NativeAdDelegate` — chính là protocol chứa `nativeAdDidRecordImpression` / `nativeAdDidRecordClick` |
| Không có paid event | `setOnPaidEventListener` (Android) / `paidEventHandler` (iOS) không xuất hiện ở đâu |

### Tác động thực tế

1. **`ShowAdMobNativeAd()` trả `true` không chứng minh ad đã hiện.** Nó resolve ngay sau khi
   `addView` thành công — rect ngoài viewport, view bị che, placeholder cao 0 đều vẫn `true`.
   Claim trung tâm của `d153fc9` ("giờ đã ghi impression") không verify được bằng code.
2. **Click native ad = user rời app, app không hề biết.** Không pause được game/audio; cooldown
   trong `SetOnAdCloseHandler` không tính native → có thể show interstitial ngay khi user quay lại
   từ trang advertiser (2 ad liên tiếp, và giống accidental-click pattern mà AdMob để ý).
3. **ROAS thiếu doanh thu native.** `appsflyer-capacitor-plugin` đã có trong dependencies; thiếu
   paid event nghĩa là mọi format khác gửi được revenue, riêng native thì không.
4. **Không đối chiếu được với AdMob dashboard** khi impression thấp bất thường (không fill / fill mà
   không hiện / hiện mà bị che — không phân biệt được).

### Đã sửa

**Đặt tên event riêng cho native** thay vì tái dùng `OnAdLoadedEvent` (payload của nó là
`NativeAdData`; nếu sau này banner/interstitial cũng emit thì xung đột type). 2 event ma **bị xóa**.

| Event mới | Payload |
|---|---|
| `OnNativeAdLoadedEvent` | `NativeAdData` |
| `OnNativeAdFailedToLoadEvent` | `{ adUnitId, error }` |
| `OnNativeAdImpressionEvent` | `{ adUnitId }` |
| `OnNativeAdClickedEvent` | `{ adUnitId }` |
| `OnNativeAdPaidEvent` | `{ adUnitId, value, currencyCode, precision }` |

| File | Thay đổi |
|---|---|
| `sdk/android/.../ALFAdMobPlugin.java` | `withAdListener` thêm `onAdImpression()` / `onAdClicked()`; `onAdFailedToLoad` emit thêm event; `nativeAd.setOnPaidEventListener(...)` gắn ngay khi ad loaded (**trước** khi caller kịp show, vì paid event bắn theo impression); helper `nativeAdToJson` / `notifyNativeAdEvent` / `notifyNativeAdPaid` / `precisionName`; import `AdValue` |
| `sdk/ios/Sources/ALFAdMobPlugin.swift` | `extension ALFAdMobPlugin: NativeAdDelegate` (`nativeAdDidRecordImpression` / `nativeAdDidRecordClick`); `adLoader(didReceive:)` gắn `nativeAd.delegate` + `paidEventHandler`, emit loaded event; `didFailToReceiveAdWithError` emit failed event; helper `adUnitId(for:)` / `nativeAdPayload` / `notifyNativeAdEvent` / `notifyNativeAdPaid` / `precisionName` |
| `sdk/plugins/admob/src/definitions.ts` | Thêm `NativeAdUnitEvent`, `NativeAdErrorEvent`, `NativeAdPaidEvent`, `AdValuePrecision`; 5 `addListener` overload mới; **xóa** 2 overload ma |
| `sdk/alf/types/ad.types.ts` | `NativeAdEvent` (discriminated union) + `NativeAdEventHandler` |
| `sdk/alf/controllers/AdController.ts` | `SetOnNativeAdEventHandler(handler): () => void` + `attachNativeAdListeners()` + `emitNativeAdEvent()`; `destroy()` dọn listener |
| `sdk/alf/index.ts` | Export type mới |
| `src-dev/views/test-view/NativeAdTestView.vue` | Đếm `Impressions` / `Clicks` trên status bar + log 5 event — để verify trên device thật |

**Chuẩn hoá cross-platform** (2 nền tảng trả khác nhau nếu để nguyên):

- `value`: Android `getValueMicros()` chia `1_000_000d`; iOS `adValue.value.doubleValue` → cả hai là
  **đơn vị tiền tệ nguyên**.
- `precision`: map về 4 chuỗi `unknown` / `estimated` / `publisherProvided` / `precise`.
- `nativeAdToJson` / `nativeAdPayload` dùng chung cho `loadNativeAd` và `loaded` event → payload
  luôn khớp, không phải maintain 2 chỗ (đồng thời gỡ đoạn map asset trùng lặp đang nằm inline).

**Thiết kế API tầng controller:** theo đúng pattern `SetOnAdCloseHandler` đang có — sync, trả
unsubscribe fn, nhiều handler song song, `try/catch` từng handler để một handler lỗi không chặn
handler khác. Listener plugin gắn **lazy** ở handler đầu tiên; `nativeAdListenerPromise` là
in-flight guard chống gắn trùng khi nhiều handler đăng ký cùng lúc (gắn là async). No-op trên web.

---

## Bug 2 — Không hook lifecycle, ad không được giải phóng

### Triệu chứng

- `ALFAdMobPlugin` (Android) **không có** `handleOnDestroy` / `handleOnPause` / `handleOnResume`,
  dù precedent đã có ngay trong repo: `ALFDownloadPlugin.handleOnDestroy()`.
- Plugin giữ `nativeAdViews` (`NativeAdView`), `nativeAds` (`NativeAd`) và `banners` (`AdView`) —
  cả `NativeAd` lẫn `AdView` đều **đòi `destroy()` tường minh**.
- Chúng chỉ được giải phóng khi JS gọi `DestroyAdMobNativeAd()` / `DestroyBannerAd()` /
  `ALF.Ads.destroy()`.

### Tác động thực tế

Khi Activity bị hủy (back thoát app, rotate nếu app không set `configChanges`, hệ thống thu hồi
task), **JS không kịp chạy** vì WebView chết cùng Activity. Mức độ chính xác: plugin instance gắn
với Activity nên map cũng mất và GC rồi sẽ thu — **không phải leak vĩnh viễn cấp process** — nhưng:

- `NativeAd.destroy()` không được gọi → SDK còn giữ resource native (rõ nhất là video player
  surface của template `medium`) tới khi GC; AdMob log warning.
- `AdView.destroy()` không được gọi → Google document rõ đây là leak, **ảnh hưởng cả banner** chứ
  không riêng native.
- Rotate màn hình liên tục (app không chặn `configChanges`) là trường hợp nặng nhất: mỗi lần
  recreate bỏ lại một `NativeAd`/`AdView` chưa huỷ.

### Đã sửa

`ALFAdMobPlugin.handleOnDestroy()`: destroy toàn bộ `NativeAdView` + `NativeAd` + `AdView` còn
trong map, clear các map full-screen (`interstitials` / `rewardedAds` / `openAppAds` /
`rewardedGranted` — các format này không có `destroy()`, bỏ reference là đủ và tránh show lại ad cũ).

Hai chi tiết cố ý:

- Khai báo **`public`** (không phải `protected`) — khớp precedent `ALFDownloadPlugin`, và nếu base
  class Capacitor khai `public` thì `protected` sẽ **không compile** (không được giảm visibility).
- Gọi view trực tiếp, **không** `runOnUiThread` — `handleOnDestroy` đã chạy trên main thread, còn
  post có thể chạy sau khi Activity đã biến mất.

iOS: `CAPPlugin` không có callback tương đương và plugin sống cùng app, nên **không thêm hook giả**.
Chỉ sửa một leak thật: `nativeAdLoaders` trước đây chỉ được xoá khi load **fail** hoặc khi destroy →
giờ xoá ngay sau khi load xong.

---

## Kiểm chứng đã làm

| Hạng mục | Kết quả |
|---|---|
| `npm run type-check` (vue-tsc) | ✅ pass |
| `npm run build` (vite + dts) | ✅ pass; `SetOnNativeAdEventHandler`, `NativeAdEvent`, 5 event đều có trong `dist/**/*.d.ts` |
| Brace balance Java/Swift | ✅ cân |
| Compile Android (gradle) | ❌ **chưa** — cần máy có Android SDK |
| Compile iOS (Xcode) | ❌ **chưa** — cần Mac |

### Còn phải verify trên device thật

1. **Android**: `gradle assembleDebug`, mở `NativeAdTestView`, xem `Impressions` có tăng — đối chiếu
   với AdMob **Ad Inspector**.
2. **iOS**: build trên Mac. ⚠️ `NativeAdDelegate` là `@objc` protocol với **method optional** — nếu
   tên/signature sai một ký tự, Swift **không báo lỗi**, delegate chỉ đơn giản không bao giờ được
   gọi. Bắt buộc xác nhận `Impressions` tăng trên device iOS, không suy ra từ việc build pass.
3. **Paid event**: test ad unit của Google thường trả `value = 0`; chỉ kiểm tra event có bắn và
   `currencyCode` / `precision` có giá trị, đừng chờ số tiền thật.
4. **`handleOnDestroy`**: rotate màn hình / back thoát app, xem logcat còn warning leak `NativeAd`
   hay `AdView` không.

---

## Chưa làm (cố ý)

- **Ad view không thuộc DOM** → đổi route Vue Router **không** gỡ ad view, ad trang cũ sẽ đè lên
  trang mới (và impression đã ghi từ trước, nếu user click thì click trên context sai). App phải tự
  gọi `DestroyAdMobNativeAd()` trong `onBeforeUnmount` — hiện là **quy ước ngầm**, chỉ có test view
  làm đúng. Cân nhắc: tự hook router, hoặc bọc thành composable `useNativeAd()`.
- `handleOnPause` / `handleOnResume` cho native ad video — cần verify tiếng có tiếp tục phát khi app
  xuống background trước khi quyết định.
- Throttle `UpdateAdMobNativeAdRect` khi scroll (hiện gọi mỗi frame qua bridge).
- AppLovin MAX vẫn không có native ad.
- Chưa `npm run publish:gitea` — chờ verify device xong, vì publish là không thể lấy lại.

## File liên quan

- Migration cho app dev: [`CHANGELOG.md`](../../../CHANGELOG.md) (mục 1.2.0)
- Chi tiết native: [`native-code-ad.md`](../../sdk/dev/native-code-ad.md) §2.1, §2.2, §2.3, §3
- API controller: [`AdController.md`](../../sdk/dev/controllers/AdController.md) — Luồng Native Ad
