# Changelog

Các thay đổi đáng chú ý của `@alf/app-sdk`. Bản trước `1.2.0` không được ghi lại ở đây.

## 3.0.0 — 2026-11-03

Big update về hiệu năng quảng cáo: bớt giật khi khởi động, khi hiện native và khi đóng interstitial,
dựa trên log đo trên máy thật ngày 2026-11-03. Kế hoạch đầy đủ, bằng chứng và thay đổi phá vỡ:
[plan-note 2026-11-03-ads-performance](design-note/chiennt/plan-note/2026-11-03-ads-performance.md).
Kèm theo: bỏ hẳn màn chọn ngôn ngữ và onboarding của SDK (mục "Removed (setup flow)").

### Added (bước 1: đo trước khi sửa)

- `initSDK` ghi thời gian từng bước (`[initSDK] applovin 1840ms`) và trả `status.timings`
  (`Record<string, number>`, ms; thêm khóa `controllers`, `modules`, `total`). `SDKStatus` giờ là
  interface có `timings`.
- `Ads.GetPerfStats()`: số load đang chạy (cả pool), số native đang hiện, lần load/show gần nhất
  (loại, thời lượng, ok). Màn `NativePoolTestView` của dev app hiển thị nó.
- Plugin Android: các method nặng (`createBanner`, `showBanner`, `createMRec`, `showMRec`, `load*`,
  `show*`, `updateNativeAdRect`, khối UI của `renderNativeAd`) bọc `android.os.Trace` với tên
  `ALF.<method>` để hiện trong Perfetto.
- Dev app: `StrictMode.ThreadPolicy` `detectAll().penaltyLog()` ở bản debug (tag `StrictMode`).

### Changed (khởi động, C1–C2)

- **`initSDK` chạy song song** hai nhóm: ads (MAX ∥ AdMob) và dữ liệu ((Firebase → RemoteConfig) ∥
  Storage ∥ IAP ∥ Payment). Firebase Analytics và ATT (iOS) vẫn chạy trước, theo thứ tự cũ. Firebase
  và RemoteConfig vẫn nối tiếp vì cả hai cùng `fetchAndActivate`. `status.timings` thêm `groupAds`,
  `groupData`.
- **AppsFlyer không chặn `initSDK`**: chạy nền, `status.appsflyer` là `'pending'` khi `initSDK` trả về
  và được cập nhật tại chỗ khi xong. `Analytics.WhenReady(): Promise<boolean>` để chờ. `LogEvent`,
  `SetUserId`, `SetUserEmail` gọi trong lúc AppsFlyer đang khởi động sẽ chờ nó thay vì bỏ AppsFlyer.
- `Ads.MarkFirstScreenShown()` và `settings.adsPerformance.startupAnchor`: `'admob'` (mặc định, như
  2.0.0) hoặc `'firstScreen'`. Với `'firstScreen'`, `WhenStartupStage(ms)` và `startDelayMs` của pool
  tính từ lúc app gọi `MarkFirstScreenShown()` (chờ tối đa 30s), nên boot chậm không còn làm mọi stage
  load cùng lúc khi Home hiện.

### Added (lịch quảng cáo, C3–C5)

- `AdScheduler` trong `AdController` (bỏ qua hết khi `adsPerformance.legacy`):
  - **Native vẽ lần lượt**: các lệnh `ShowAdMobNativeAd` cách nhau tối thiểu `nativeShowGapMs`
    (mặc định 300). Lệnh đang xếp hàng bị bỏ (trả `false`) nếu slot bị `Hide`/`Destroy` trước lượt.
  - **Chờ màn mới vẽ xong**: `Screen.NavigateTo` báo chuyển màn; show/load chờ điều hướng xong + thời
    gian animation + 2 frame + `screenSettleMs` (mặc định 150). App tự điều hướng thì gọi
    `Ads.NotifyScreenChange(done?, animationMs?)`. `Ads.WhenScreenSettled()` để chờ.
  - **Fullscreen ad**: khi interstitial/rewarded/app open đang mở và `afterFullscreenMs` (mặc định
    1000) sau khi đóng, không vẽ native mới, không bắt đầu load mới.
  - **Giới hạn load đồng thời** `maxConcurrentLoads` (mặc định 2), chung cho pool, banner, native và
    preload interstitial/rewarded/app open.
- `NativeAdPool`: lấy ad ra thì nạp bù sau `refillDelayMs` (mặc định 800; chỉnh chung ở
  `adsPerformance` hoặc riêng từng pool trong `NativeAdPoolOptions`). Người gọi đang chờ trong
  `Acquire` vẫn kích load ngay. Mọi load của pool đi qua scheduler; `loadTimeoutMs` chỉ tính thời gian
  request, không tính thời gian chờ lượt.
- Cảnh báo một lần (`logger.warn`) khi hiện native template `small` (không có media view) cho pool hoặc
  lệnh có xin video. `NativePool.RequestsVideo(slot)`.
- `UpdateAdMobNativeAdRect` gộp theo `requestAnimationFrame`: mỗi frame mỗi ad chỉ gửi rect cuối qua
  bridge, rect không đổi thì không gửi.
- `settings.adsPerformance` (`AdsPerformanceSettings`), `Ads.SetPerformanceOptions()` /
  `Ads.GetPerformanceOptions()` để chỉnh khi chạy (vd từ Remote Config, cho A/B).
- `GetPerfStats()` thêm `loadsQueued`, `fullscreenOpen`.

### Changed (plugin native, C6–C8)

- AdMob banner (Android): `hideBanner` → `pause()`, `showBanner` → `resume()`; `handleOnPause` /
  `handleOnResume` dừng/chạy lại banner theo activity (banner app đã ẩn vẫn dừng). iOS chưa có banner AdMob.
- MAX (Android): tạo `MaxAdView`, `loadAd()`, gắn view và `showAd()` chạy trên main thread; thay banner/MREC
  thì `destroy()` cái cũ. Interstitial và app open giữ **một instance mỗi ad unit**, gọi lại `loadAd()`:
  ad đã sẵn thì `load*` resolve ngay; đang load thì lệnh mới đi chung; ad của unit đang hiện thì load chờ
  tới khi đóng. iOS: mọi thao tác MAX chạy trên main queue, interstitial/app open một instance mỗi unit.
- MAX: event mới `OnInterstitialAdDisplayFailedEvent`, `OnRewardedAdDisplayFailedEvent`,
  `OnAppOpenAdDisplayFailedEvent` (`{ adUnitId, error }`). `AdController` dùng chúng để gỡ listener của
  lần show lỗi và báo scheduler, thay vì chờ một Hidden event không bao giờ tới.
- Rect mode (Android): chỉ đổi vị trí thì dùng `setTranslationX/Y` (không layout lại), chỉ đổi
  `LayoutParams` khi đổi kích thước, rect y hệt thì bỏ. iOS: rect y hệt thì bỏ qua `layoutIfNeeded()`.
- `Analytics.LogEvent` / `SetUserId` / `SetUserEmail` không bắt người gọi chờ AppsFlyer khởi động: phần
  Firebase chạy ngay, phần AppsFlyer được xếp hàng chạy sau.

### Removed (setup flow)

- Bỏ hẳn màn chọn ngôn ngữ và onboarding của SDK:
  - Export: `SetupFlow`, `SetupFlowProvide`, `registerSetupRoutes`, `SetupFlowOptions`,
    `ChooseLanguageView`, `OnboardingView`, `OnboardingConfig`.
  - `Settings`: `hasChooseLanguageScreen`, `hasOnboardingScreen`, `onboarding`, `choose_language`.
    Config còn các trường này sẽ bị TypeScript báo lỗi (excess property).
  - `ScreenRegistry`: `choose_language`, `onboarding`.
  - `AppDataController`: `completeOnboarding()`, các trường `languageChosen`, `onboardingCompleted`.
  - i18n: khối `language` và `onboarding` ở mọi locale (`settings.language` vẫn còn).
- Tài liệu `design-note/sdk/ui/onboarding.md`, `design-note/sdk/dev/app-data.md`.

### Changed (setup flow)

- App tự gọi `ALF.Instance.Screen.setRouter(router)` rồi `Screen.NavigateTo('home')` sau `initSDK`
  (trước đây `SetupFlow` làm việc này).
- `initSDK` áp dụng lại locale đã lưu bằng `Data.setLocale()` ngay sau `Data.init()`.
- `OverlayContainer`, `DateTimePicker`, `TimePicker` tự tạo `<div id="alf-overlay">` khi cần
  (trước đây chỉ `SetupFlowProvide` tạo).

### Breaking

- `status.appsflyer` có thể là `'pending'` ngay sau `initSDK`; dùng `Analytics.WhenReady()`.
- Thứ tự init song song: app dựa vào thứ tự ngầm giữa Storage, IAP, Payment, Firebase cần kiểm lại.
- `ShowAdMobNativeAd` resolve muộn hơn (xếp hàng, chờ màn vẽ xong); có thể trả `false` nếu slot bị
  hide/destroy khi đang chờ lượt.
- Pool không nạp lại ngay khi `Acquire`: `Size()` ngay sau đó nhỏ hơn 2.0.0 trong `refillDelayMs`.
- `settings.adsPerformance.legacy: true` quay về toàn bộ hành vi 2.0.0 trong một bản chuyển tiếp.
- Bỏ setup flow (mục "Removed (setup flow)"): app gọi `SetupFlow` / `registerSetupRoutes` /
  `SetupFlowProvide` hoặc config còn `hasChooseLanguageScreen` / `onboarding` sẽ lỗi build; thay bằng
  `Screen.setRouter(router)` + `Screen.NavigateTo(...)`. `legacy` không đưa setup flow trở lại.

### Chưa làm

- Ghim version adapter MAX và bỏ bớt adapter (C9, mục 3.5 plan-note): cần báo cáo doanh thu theo
  network và quyết định của chủ dự án.
- Cờ tối ưu của Google (`OPTIMIZE_INITIALIZATION` / `OPTIMIZE_AD_LOADING`, mục 3.4): chưa xác minh trong
  doc play-services-ads 25.x nên chưa thêm vào manifest.
- Bump version 3.0.0: làm khi phát hành, sau khi đo lại trên máy thật.
- Chưa compile được: Android (thiếu `src-dev/node_modules` cho gradle) và iOS.

## 2.0.0 — 2026-11-02

Kho chờ native (`Ads.NativePool`) và lịch khởi động quảng cáo: native hiện ngay thay vì chờ mạng.
Lên bản major theo quyết định của chủ dự án; không có thay đổi phá vỡ — app không gọi API mới thì chạy
như 1.9.0.

### Added

- `Ads.NativePool`: giữ sẵn native ad đã nạp, chưa vẽ, mỗi ad trong một slot riêng (`pool-<tên>-<n>`).
  - `Configure(name, options)`: `adUnitIds` theo thứ tự ưu tiên, `request`, `capacity`, `maxAgeMs`
    (mặc định 50 phút), `tierStaggerMs` (mặc định 2500), `retryDelayMs`, `startDelayMs`, `loadTimeoutMs`.
  - `Acquire(name, { maxWaitMs, isCurrent, usable, discardUnusable })`: có sẵn thì trả ngay
    (`source: 'pool'`), trống thì chờ; ad về được trao thẳng cho người chờ lâu nhất (`source: 'fresh'`).
  - `GiveBack`, `Discard`, `Fill`, `Clear`, `Size`, `Loading`, và `Has(name, usable?)` — hỏi kho có ad dùng
    được không mà không lấy ra (vd trước khi thay ad đang hiện).
  - Các bậc unit chạy **so le**: bậc sau được gửi khi bậc trước chưa về sau `tierStaggerMs`, bậc trước
    vẫn chạy tiếp. Ad về muộn vào kho, không bị huỷ. Lấy ra là tự nạp bù; trượt hết bậc thì chờ
    `retryDelayMs`.
  - Không nạp khi app ở nền hoặc đã mua remove-ads; `DestroyVisibleAds()` và `destroy()` xả kho.
  - Test ads: tự đổi sang unit native test của Google (bản video khi `request.video`).
  - iOS chưa khoá native theo slot: kho iOS giữ tối đa 1 ad mỗi unit.
- `Ads.InitAdMobEarly(appId?)`: khởi động plugin AdMob ngay, song song với `initSDK` (Android).
- `Ads.WhenAdMobReady()`, `Ads.WhenStartupStage(ms)`: mốc "AdMob sẵn sàng + ms" dùng chung cho lịch
  khởi động (vd 2 native to trước, banner +2,5s, interstitial/rewarded +5s). Chờ mốc tối đa 15s nếu
  AdMob không bao giờ khởi động.
- `isNativePoolSlot(slot)`, `NATIVE_POOL_SLOT_PREFIX`; kiểu `NativeAdPoolOptions`, `NativeAdAcquireOptions`,
  `PooledNativeAd`.
- Dev app: màn `/test/native-pool`.

## 1.9.0 — 2026-10-31

Cờ `settings.testAds`: bật lên thì mọi quảng cáo SDK hiện là test ad, không có doanh thu giả.

### Added

- `settings.testAds?: boolean`, mặc định bằng `settings.dev`, chỉ đọc lúc `initSDK`. Tách khỏi
  `dev` để bản tester chạy test ads mà analytics / RemoteConfig vẫn như production.
- AppLovin MAX test mode (Android): `ALFAppLovinMAX.initialize({ testMode })` đọc GAID và đăng ký
  máy là MAX test device trước init, trả `testDevice`. Thêm dependency
  `play-services-ads-identifier`.
- Khi MAX không vào được test mode (iOS, Ad ID tắt): interstitial, rewarded, app open chạy unit test
  AdMob; MREC là banner AdMob 300x250; banner fallback bỏ bước AppLovin.
- `Ads.IsTestMode()`. `initSDK` warn khi test ads bật.
- Event native `paid` có `isTest`.
- Plugin AdMob: event `OnRewardedAdDismissedEvent`, `OnOpenAppAdDismissedEvent` (Android + iOS).

### Changed

- Test ads: banner AdMob dùng unit test ngay từ đầu. Trước đây bản dev vẫn gọi banner AdMob
  **thật** và MAX thật.
- Test mode: MAX Android không log `ad_impression` / revenue lên Firebase.

## 1.8.0 — 2026-10-23

IAP chạy được thật: consumable không mất khi app chết giữa chừng, remove-ads tắt quảng cáo, có
event doanh thu.

### Added

- `IAP.setGrantHandler(handler)`: app giao hàng consumable (coin, gem…) trong handler. Thứ tự
  là giao hàng → ghi `transactionId` xuống máy → consume (Android) / finish (iOS). App chết trước
  khi ghi thì lần reconcile sau giao lại; chết sau khi ghi thì chỉ consume, không giao lần hai.
  Handler nhận `transactionId` để app tự chống trùng nếu cần.
- `IAP.reconcile()`: đối chiếu với danh sách mua của store. Tự chạy khi init và mỗi lần app quay
  lại foreground. Giao các consumable còn mở (thanh toán pending đã xong, giao hàng bị ngắt) và
  acknowledge non-consumable/subscription chưa acknowledge (Google hoàn tiền sau 3 ngày nếu không).
- Cờ `removesAds` trên sản phẩm trong `keys.iap.products`. Sở hữu sản phẩm đó thì banner, MREC,
  native, interstitial, app open (AppLovin + AdMob) không load/không show; rewarded vẫn chạy. Mua
  xong thì ad đang hiện bị gỡ ngay (`Ads.DestroyVisibleAds()`). `Ads.IsAdsRemoved()`,
  `IAP.isAdsRemoved()`.
- Sản phẩm đã sở hữu được lưu trên máy (`iap-data.json`): `hasEntitlement` và remove-ads đúng ngay
  từ lúc mở app và khi offline. Cache chỉ bỏ một sản phẩm khi store trả lời mà không có nó.
- `IAP.getOwnedProductIds()`, `IAP.onEntitlementsChanged(listener)`.
- Event Firebase `iap_purchase` (`product_id`, `product_type`, `quantity`, `transaction_id`, và
  `value` + `currency` khi đã lấy được giá từ store), một lần cho mỗi giao dịch, không tính
  renewal. Không dùng `purchase` / `in_app_purchase` vì Firebase tự log `in_app_purchase` khi
  link store — log thêm sẽ đếm doanh thu hai lần. Android (như FirebaseAnalytics).
- Lỗi của `purchase()` có `error.code`: `cancelled`, `pending`, `not_purchased`, `unavailable`,
  `product_not_found`, `failed` (type `IAPError`).
- Màn test IAP trong dev app (`/test/iap`).

### Changed

- `IAP.init()` không chờ store nữa: đọc cache rồi lấy sản phẩm + reconcile ở nền, không giữ
  `initSDK`.
- Sản phẩm một lần và subscription được hỏi store riêng (trước gửi tất cả SKU cho cả hai loại).
- Subscription Android được tính là active (plugin không trả `isActive` trên Android).
- `IAPPurchaseOptions.isConsumable` bị bỏ qua (deprecated) — `type` của sản phẩm quyết định.

### Chưa làm

- iOS: plugin tự finish giao dịch đến từ `Transaction.updates` (Ask to Buy, giao dịch còn mở lúc
  mở app) rồi mới báo JS. Nếu JS chưa nghe kịp thì consumable đó không giao lại được.
- Android: Google Play báo user huỷ và thanh toán lỗi giống nhau → cùng `not_purchased`.
- Chưa có server xác thực hoá đơn.
- MREC tạo thẳng qua `ALFAppLovinMAX` (theo `rect`) không đi qua AdController nên không bị chặn.

## 1.7.1 — 2026-10-23

### Changed

- `ALFAppLovinMAX.hideBanner()` dừng luôn auto-refresh của banner, `showBanner()` bật lại. Trước
  đây banner ẩn (GONE) vẫn nạp ad mới mỗi chu kỳ refresh — tốn mạng, CPU và một lần dựng WebView
  mà không ai nhìn thấy. Banner bị ẩn khi lần nạp đầu còn chạy thì vẫn nạp xong (`createBanner`
  vẫn resolve), chỉ dừng refresh sau đó. Không đổi API JS. Android.

## 1.7.0 — 2026-10-23

Gỡ hẳn lớp nút native (overlay) khỏi native ad.

Khi app thu gọn ad full màn hình xuống dải đáy, nút ▼ không còn cần nữa. Trước đây chỉ đổi được
overlay (`updateNativeAdOverlay`), không gỡ được — phải thu nhỏ nút, còn sót một chấm ở góc ad và
nội dung template vẫn bị đẩy xuống chừa chỗ cho hàng nút.

### Added

- `ALFAdMob.removeNativeAdOverlay({ adUnitId | slot })` /
  `AdController.RemoveAdMobNativeAdOverlay(slot?)`: gỡ overlay khỏi ad và trả lại padding gốc của
  template. Không có overlay thì không làm gì. `updateNativeAdOverlay()` hoặc
  `showNativeAd({ overlay })` thêm lại được. Android + iOS.

## 1.6.0 — 2026-10-20

Template native **`mrec`** vừa ô 300×250dp.

`medium` cao tự nhiên ~320dp (body 3 dòng + media sàn 120dp), không nhét được vào chỗ của một
MREC. Ô "native nhỏ" của app chạy chuỗi native → MREC AppLovin trong CÙNG chỗ 300×250, nên cần một
template native có media (video) mà thấp hơn 250dp.

### Added

- `NativeAdTemplate` thêm `'mrec'`: icon + headline + advertiser + media + CTA, KHÔNG body. Cao tự
  nhiên 228dp (đệm 8, header 40, media sàn 120, CTA 40). Android (`alf_native_ad_mrec.xml`).

### Chưa làm

- iOS chưa có template `mrec` — rơi về `medium`.

## 1.5.0 — 2026-10-20

MREC AppLovin đặt được **vào một vùng của trang**, không chỉ ghim mép màn hình.

Ô "native nhỏ" của app đi chuỗi native AdMob → … → MREC AppLovin trong CÙNG một chỗ giữa màn
hình. Trước đây MREC chỉ ghim được `TOP_*` / `BOTTOM_*` / `CENTER`, nên bậc MREC của chuỗi rơi ra
khỏi chỗ đã chừa.

### Added

- `MRecAdUnitOptions.rect` (`MRecRect`, px CSS của WebView như `getBoundingClientRect()`): MREC
  nằm GIỮA vùng này, vẫn đúng 300×250dp (không kéo giãn). Có `rect` thì bỏ qua `position` và
  inset đáy. Android.
- `ALFAppLovinMAX.updateMRecRect({ adUnitId, rect })`: dời MREC đã tạo bằng `rect`. Android.

### Chưa làm

- iOS bỏ qua `rect` (vẫn ghim theo `position`) và chưa có `updateMRecRect`.

## 1.4.0 — 2026-10-20

**Nhiều native ad cùng lúc**, và Meta Audience Network đấu giá được trong nhóm hòa giải AdMob.

Trước đây cả app chỉ có MỘT native ad: `AdController` lấy unit từ `keys.admob.<platform>.native`,
mỗi lần show/load là destroy ad cũ. Kịch bản ads mới cần native ở đáy màn hình cùng lúc với một
native cỡ MREC, nhiều ad unit khác nhau, và có khi hai ô dùng **chung một unit** (unit Meta bidding).

### Added

- **Slot cho native ad.** `NativeAdLoadOptions.slot` / `NativeAdInitOptions.slot`: tên do app đặt
  (`'bottom'`, `'mrec'`…). Mỗi slot giữ ad + view riêng, nên nhiều native ad hiện cùng lúc được, kể
  cả hai ad từ cùng một unit. Show unit khác vào một slot thì ad cũ của slot bị thay (chuỗi fallback
  chạy trong một slot).
- `NativeAdLoadOptions.adUnitId`: chọn unit cho từng lần gọi, thay vì chỉ unit trong config. Dev
  mode vẫn đổi sang test unit.
- Tham số `slot` (cuối, tuỳ chọn) cho `UpdateAdMobNativeAdRect`, `UpdateAdMobNativeAdOverlay`,
  `HideAdMobNativeAd`, `DestroyAdMobNativeAd`, `IsAdMobNativeAdReady`, `PlayAdMobNativeAdVideo`,
  `PauseAdMobNativeAdVideo`, `SetAdMobNativeAdVideoMuted`.
- Plugin: mọi method native nhận `slot`; mọi event native (`Loaded`, `FailedToLoad`, `Impression`,
  `Clicked`, `Paid`, `Video`, `OverlayClose`) kèm `slot`. `NativeAdEvent` của `AdController` có `slot`.
  Type mới `NativeAdSlotOptions`, `NativeAdTargetOptions`.
- Android: dependency `com.google.ads.mediation:facebook:6.22.0.1` (adapter Meta cho **AdMob**
  mediation; override bằng property `admobMetaAdapterVersion`). Adapter `com.applovin.mediation:
  facebook-adapter` sẵn có chỉ phục vụ MAX — thiếu adapter này thì unit AdMob cấu hình Meta bidding
  không bao giờ ra ad Meta. Cả hai kéo cùng `audience-network-sdk 6.22.0`.

### Hành vi

- Không truyền `slot` ⇒ y hệt 1.3.x: một native ad mặc định, unit lấy từ config.
- `ShowAdMobNativeAd({ slot })` resolve `false` khi no fill — dùng để chuyển sang unit kế tiếp.
- `DestroyAdMobNativeAd(slot)` huỷ luôn lần nạp đang chạy của slot: gọi khi màn chứa slot đóng,
  kể cả khi ad chưa kịp hiện.
- Android: lần nạp về muộn của một slot (đã có lần nạp mới hơn, hoặc đã destroy) bị bỏ, không bắn
  event — unit chậm đầu chuỗi không đè lên unit đã thay nó.

### Chưa làm

- **iOS chưa khoá theo slot**: Swift vẫn giữ một ad mỗi `adUnitId` và bỏ qua `slot`. Hai slot khác
  unit vẫn chạy song song; hai slot CÙNG unit thì dùng chung một ad. Event iOS không có `slot`.
  iOS cũng chưa có adapter Meta cho AdMob.

## 1.3.4 — 2026-10-16

Native ad **full màn hình có nút đóng đè lên trên**, để dùng native ad thay interstitial.

Trước đây nút đóng phải vẽ bằng HTML. View native luôn nằm TRÊN WebView nên nút HTML đặt trong
rect của ad bị che mất; app buộc phải chừa một dải riêng cho nút và ad không full màn hình được.

### Added

- `ShowNativeAdOptions.overlay` / `NativeAdInitOptions.overlay` (type `NativeAdOverlay`): plugin tự
  vẽ một lớp native **trên** ad ở chế độ rect: nhãn (tuỳ chọn) bên trái + nút đóng tròn bên phải
  (`closeText`, `closeEnabled`, `label`, `size`). Android + iOS.
- `ALFAdMob.updateNativeAdOverlay({ adUnitId, overlay })` và
  `AdController.UpdateAdMobNativeAdOverlay(overlay)`: đổi chữ/trạng thái nút (đếm ngược → ✕).
- Event `OnNativeAdOverlayCloseEvent { adUnitId }` khi bấm nút đang bật; qua `AdController` là
  native ad event `{ type: 'overlayClose' }`. Plugin không tự đóng gì: app quyết rồi destroy ad.

### Hành vi

- Lớp nút tự hạ xuống dưới status bar / tai thỏ nếu rect của ad chui dưới đó.
- Nội dung template (nhãn "Ad", tiêu đề, media, CTA) được đẩy xuống dưới hàng nút và lên khỏi
  thanh điều hướng — **không asset nào bị che** (policy AdMob). Chỉ nền của ad tràn sát mép.
- Vùng trống của lớp nút cho chạm xuyên xuống ad. Nút đóng đang khoá vẫn nuốt cú chạm, nên chạm
  nhầm vào nút không thành click ad.
- Ẩn / hiện lại / đổi rect / destroy ad thì lớp nút đi theo.

## 1.3.3 — 2026-10-15

Interstitial **AdMob** dùng được, và một app chạy được nhiều ad unit interstitial nối nhau.

### Fixed

- **`ALFAdMob.loadInterstitial()` làm chết app trên Android.** `InterstitialAd.load()` bị gọi trên
  thread của plugin thay vì UI thread ⇒ `IllegalStateException: #008 Must be called on the main UI
  thread`, không ai bắt (bắt được trên SM-A166P, 11/08/2026). Giờ nạp trên UI thread. Sửa luôn
  `loadRewardedAd()` cùng lỗi.
- Hàm interstitial khi SDK chưa `initialize()` reject rồi **vẫn chạy tiếp** và settle call lần hai.
  Giờ reject xong là dừng.

### Added

- Event interstitial AdMob, đều kèm `adUnitId` để phân biệt từng unit (Android + iOS):
  `OnInterstitialAdShowedEvent`, `OnInterstitialAdFailedToShowEvent` (thêm `message`),
  `OnInterstitialAdDismissedEvent`, `OnInterstitialAdPaidEvent` (cùng shape `OnNativeAdPaidEvent`).
  Trước đây không có event nào nên JS không biết lúc ad đóng.
- Type `AdUnitEvent`, `AdUnitErrorEvent`.

### Changed

- `showInterstitial()` lấy ad **ra khỏi cache** ngay lúc show: `isInterstitialReady()` về `false`
  luôn, gọi show lần hai cho cùng unit bị reject thay vì chiếu lại ad đã dùng. Muốn ad kế tiếp thì
  `loadInterstitial()` lại.

## 1.3.2 — 2026-10-14

Biết `ad_impression` của AppLovin MAX đến từ **vị trí nào** trong app.

### Added

- Các hàm show của `ALFAppLovinMAX` (`showBanner`, `showMRec`, `showInterstitial`,
  `showRewardedAd`, `showAppOpenAd`) nhận thêm `placement?: string` (type `AdShowOptions`). MAX gắn
  placement vào impression (`showAd(placement)` / `MaxAdView.setPlacement`), và `ad_impression` trên
  Firebase có thêm **`ad_placement`**.
- `AdController.ShowInterstitial(onClose?, placement?)`, `ShowRewardedVideo(onClose, placement?)` và
  `ShowAppOpenAd(onClose?, placement?)` nhận thêm tham số `placement`.

### Lưu ý

- `ad_impression` của **AdMob** do Firebase tự ghi nên không gắn được `ad_placement`. App nào cần biết
  vị trí của AdMob thì tự log một event riêng lúc ad hiện (AutoBattler dùng `ad_show`). **Không** tự log
  thêm `ad_impression` cho AdMob, vì sẽ đếm trùng doanh thu.

## 1.3.1 — 2026-10-13

### Added

- Mọi event Firebase Analytics tự có thêm **`timestamp`** (epoch ms phía máy, lúc log) và
  **`app_version`** (`settings.appVersion`). Hai tham số này đứng đầu nên không bị cắt ở trần 25,
  app không ghi đè được. `ad_impression` của MAX (log trong Java) cũng có `timestamp` và
  `app_version` (`versionName`).
- `ALF.Instance.FirebaseAnalytics.SetDefaultEventParams(params)`: tham số gắn vào mọi event
  sau đó. Gọi lại thì thay cả bộ, truyền `{}` để xoá. Tham số trùng tên trong event sẽ thắng.

## 1.3.0 — 2026-10-13

**Firebase Analytics** (Android). Plugin native `ALFFirebase` nằm ngay trong SDK nên `cap sync` tự
đăng ký qua `alf-app-sdk`. Không dùng plugin npm vì nó sẽ nằm lồng trong `node_modules` của SDK, và
`cap sync` không đăng ký những plugin đó (đã làm chết AppsFlyer và Remote Config, xem
`design-note/chiennt/plan-note/2026-09-24-analytics-ad-revenue.md`).

### ⚠️ Cần làm ở app

| Việc | Vì sao |
|---|---|
| Có `android/app/google-services.json` và apply plugin `com.google.gms.google-services` | Firebase khởi động từ file này. Thiếu thì SDK warn một lần, analytics tắt |
| Đặt `settings.analyticsEnabled` theo bản build (`true` chỉ cho bản phát hành) | Manifest của SDK để **thu thập TẮT mặc định**. Nếu không đặt, giá trị mặc định là `!settings.dev` |
| `npx cap sync android` sau khi nâng SDK | Để đăng ký `ALFFirebasePlugin` |

### Added

- `ALF.Instance.FirebaseAnalytics`: `LogEvent(name, params)`, `LogScreenView(screenName, screenClass?)`,
  `SetUserId(id | null)`, `SetUserProperty(name, value | null)`, `isActive`.
  - Kiểm tra theo giới hạn Firebase: tên snake_case ≤40 ký tự, không dùng tiền tố `firebase_`/`google_`/`ga_`,
    không dùng tên event Firebase dành riêng (`first_open`, `session_start`, `app_background`…), tối đa 25
    tham số, chuỗi ≤100 ký tự. Sai thì **warn một lần rồi bỏ/cắt**, không throw.
  - Boolean gửi thành chuỗi `"true"`/`"false"`, để hiện như dimension trong GA4.
  - Web **không bao giờ gửi**, chỉ in ra console. Bản không được tính cũng in ra console để soi.
- `settings.analyticsEnabled?: boolean`: bật/tắt thu thập cho bản build này. Cờ được set lại ở
  mỗi lần khởi động, vì Firebase lưu cờ này trên máy.
- `ad_impression` cho **AppLovin MAX** (banner, MREC, interstitial, rewarded, app open) được log
  native từ `onAdRevenuePaid`, gồm `ad_platform=appLovin`, `ad_source`, `ad_format`, `ad_unit_name`,
  `value`, `currency=USD`. AdMob không log tay vì Firebase tự ghi.
- Gradle: `firebase-bom` (mặc định `34.19.0`, app đổi được qua `ext.firebaseBomVersion`) và
  `firebase-analytics`.
- Export `ALFFirebase` (plugin thô) và type `FirebaseAnalyticsController`.

### Changed

- `ALF.Instance.Analytics.LogEvent` / `SetUserId` gửi sang **Firebase và AppsFlyer**. Khi AppsFlyer
  chưa khởi tạo thì warn một lần, không im lặng bỏ event nữa. Init AppsFlyer thất bại thì warn kèm
  cách sửa.
- `initSDK()` khởi tạo Firebase Analytics ngay sau khi set config, trước ads. Kết quả trả về có thêm
  key `firebaseAnalytics`.

### Chưa làm

- iOS: `FirebaseAnalyticsController` không làm gì và warn một lần (TODO trong `Package.swift`).

## 1.2.0 — 2026-09-22

Native ad (AdMob) chuyển sang render bằng **view native thật** (`NativeAdView`) đè lên WebView.
Đây là điều kiện bắt buộc để Google Mobile Ads SDK ghi impression và xử lý click —
cách cũ (bóc asset ra JSON rồi vẽ bằng HTML) **không** ghi impression, click chết, và vi phạm
policy AdMob.

### ⚠️ Breaking

| Thay đổi | Ảnh hưởng | Cách xử lý |
|---|---|---|
| `NativeAdData.mediaUrl` bị bỏ, thay bằng `hasVideoContent: boolean` | Code đọc `mediaUrl` sẽ không compile | Bỏ `mediaUrl`. Giá trị cũ là `toString()` của `Drawable`/`UIImage` nên chưa bao giờ dùng được như URL. Media giờ do `MediaView` bên trong `NativeAdView` tự render (template `medium`) |
| `ReportAdMobNativeAdClick()` **luôn reject** | Mọi lời gọi sẽ throw | Xóa lời gọi. Click do Google SDK xử lý bên trong `NativeAdView` |
| Vẽ native ad bằng HTML từ `LoadAdMobNativeAd()` không còn được hỗ trợ để hiển thị | Ad vẫn hiện nhưng **không có doanh thu** và vi phạm policy | Chuyển sang `ShowAdMobNativeAd()` — xem phần Migration bên dưới |
| Bỏ 2 event `OnAdLoadedEvent` / `OnAdFailedToLoadEvent` khỏi `ALFAdMobPlugin` | Code `addListener` 2 event này sẽ không compile | Chúng **chưa bao giờ được native emit** — callback im lặng không chạy. Dùng `OnNativeAdLoadedEvent` / `OnNativeAdFailedToLoadEvent`, hoặc `SetOnNativeAdEventHandler()` |

### Added

- `ALF.Instance.Ads.ShowAdMobNativeAd(options?)` — dựng `NativeAdView` và gắn lên màn hình,
  tự load ad nếu chưa có. Hai chế độ đặt vị trí:
  - **Anchor**: `position: 'TOP_CENTER' | 'BOTTOM_CENTER'` (+ `height` tùy chọn) — neo mép như banner.
  - **Rect**: `rect: { x, y, width, height }` (CSS px, lấy từ `getBoundingClientRect()`) — đè khít
    lên một placeholder trong layout. `rect` được ưu tiên hơn `position`.
- `ALF.Instance.Ads.UpdateAdMobNativeAdRect(rect)` — dời ad ở rect mode; gọi khi `scroll` / `resize`
  vì ad view nằm **trên** WebView nên không tự cuộn theo trang.
- `ALF.Instance.Ads.HideAdMobNativeAd()` — ẩn view, giữ ad trong bộ nhớ (`ShowAdMobNativeAd()`
  hiện lại mà không ghi thêm impression).
- Template `'small'` (~80dp: icon + headline + body + CTA) và `'medium'` (~300dp: thêm `MediaView`
  cho video/ảnh lớn), dựng giống nhau trên Android và iOS.
- `NativeAdStyle`: `background`, `textColor`, `secondaryTextColor`, `ctaBackground`, `ctaTextColor`,
  `cornerRadius` — màu nhận hex `#RGB`, `#RRGGBB`, `#AARRGGBB`.
- Dev mode dùng **test native ad unit trên cả iOS lẫn Android**, đúng id của từng nền tảng (trước
  đây chỉ Android, nên iOS dev build dùng unit thật và thường không fill; sau đó iOS dùng nhầm id test
  của Android).
- `ALF.Instance.Ads.SetOnNativeAdEventHandler(handler)` — nhận **event do chính Google Mobile Ads
  SDK báo**, trả về unsubscribe fn. 5 loại event:

  | `event.type` | Ý nghĩa |
  |---|---|
  | `loaded` | Ad đã load, kèm `event.ad` (assets như `LoadAdMobNativeAd()`) |
  | `failed` | Load thất bại, kèm `event.error` |
  | `impression` | **Ad thật sự được nhìn thấy.** `ShowAdMobNativeAd()` resolve chỉ nghĩa là view đã gắn — view nằm ngoài viewport, bị che, hoặc cao 0 vẫn resolve `true` |
  | `clicked` | User bấm ad và đang rời app sang advertiser — dùng để pause app và hoãn full-screen ad kế tiếp |
  | `paid` | Doanh thu của một impression: `value` (đơn vị tiền của `currencyCode`), `currencyCode`, `precision` |

  ```ts
  const off = ALF.Instance.Ads.SetOnNativeAdEventHandler((e) => {
    if (e.type === 'clicked') pauseGame()
    if (e.type === 'paid') reportAdRevenue(e.value, e.currencyCode)
  })
  ```

  Listener native được gắn ở handler đầu tiên và dọn trong `ALF.Ads.destroy()`. No-op trên web.
- **Native video.** Creative video phát trong `MediaView` của template `medium` (không cần code thêm
  để hiển thị). Bổ sung để tùy chỉnh và theo dõi:
  - `ShowAdMobNativeAd` / `LoadAdMobNativeAd` nhận `video: { startMuted?, customControlsRequested?,
    clickToExpandRequested? }` (`startMuted` mặc định `true`) và `mediaAspectRatio:
    'any' | 'landscape' | 'portrait' | 'square'`. Các option này **chốt lúc load** — ad đã cache giữ
    option cũ, muốn đổi thì `DestroyAdMobNativeAd()` trước.
  - Event `{ type: 'video', state }` trong `SetOnNativeAdEventHandler`, `state` =
    `start` (chỉ Android) / `play` / `pause` / `end` / `mute` / `unmute` — `unmute` là lúc nên hạ
    nhạc nền của app.
  - `PlayAdMobNativeAdVideo()`, `PauseAdMobNativeAdVideo()`, `SetAdMobNativeAdVideoMuted(muted)` —
    chỉ chắc chắn có tác dụng khi custom controls được SDK cấp (chỉ publisher được allowlist).
  - `NativeAdData` thêm `mediaAspectRatio`, `videoDuration`, `videoCustomControlsEnabled`.
  - Dev mode: truyền `video` → dùng test unit **native video** của Google (luôn trả creative video).

### Fixed

- **Native ad không còn im lặng.** Android bỏ trống `onAdImpression` / `onAdClicked` của
  `AdListener`, iOS thì không implement `NativeAdDelegate` — nên impression và click của native ad
  không bao giờ tới được app. Cả hai nền tảng giờ đều forward qua event ở trên.
- **Doanh thu native ad không còn bị mất.** Thêm `setOnPaidEventListener` (Android) và
  `paidEventHandler` (iOS) → `paid` event, để app gửi được ad revenue cho attribution SDK
  (AppsFlyer/Firebase). Trước đây mọi format khác gửi được, riêng native thì không, làm ROAS thiếu.
- **Android giải phóng ad khi Activity bị hủy.** Thêm `handleOnDestroy()` cho plugin AdMob: destroy
  `NativeAdView` + `NativeAd` + `AdView` (banner) đang giữ. Trước đó chúng chỉ được huỷ khi JS gọi
  `DestroyAdMobNativeAd()` / `ALF.Ads.destroy()`, mà WebView chết cùng Activity nên JS không kịp
  chạy — rotate màn hình liên tục là trường hợp nặng nhất.
- iOS giải phóng `AdLoader` sau khi load xong thay vì giữ lại tới lúc destroy.
- iOS: bỏ optional chaining / `if let` trên `NativeAd.mediaContent` — property này non-optional trong
  Google Mobile Ads SDK 12, nên code cũ không compile được. `MediaView` giờ luôn có trong template
  `medium`.

### Deprecated

- `LoadAdMobNativeAd()` và `GetCachedNativeAd()` — chỉ còn dùng để preview/debug asset, không dùng
  để hiển thị.

### Migration

```ts
// Trước — không ghi impression, click chết
const ad = await ALF.Instance.Ads.LoadAdMobNativeAd()
if (ad) {
  el.innerHTML = `<img src="${ad.iconUrl}"><h3>${ad.headline}</h3>
                  <button>${ad.callToAction}</button>`
  el.querySelector('button').onclick = () => ALF.Instance.Ads.ReportAdMobNativeAdClick()
}

// Sau — NativeAdView thật, đè lên placeholder
const r = placeholder.getBoundingClientRect()
await ALF.Instance.Ads.ShowAdMobNativeAd({
  template: 'medium',
  rect: { x: r.x, y: r.y, width: r.width, height: r.height },
  style: { background: '#FFFFFF', textColor: '#111111', cornerRadius: 12 },
})

// Ad view không cuộn theo trang — phải sync lại khi scroll/resize
const sync = () => {
  const r = placeholder.getBoundingClientRect()
  ALF.Instance.Ads.UpdateAdMobNativeAdRect({ x: r.x, y: r.y, width: r.width, height: r.height })
}
window.addEventListener('scroll', sync, { passive: true, capture: true })
window.addEventListener('resize', sync, { passive: true })

// Rời trang / đóng màn hình
await ALF.Instance.Ads.DestroyAdMobNativeAd()
```

Placeholder trong HTML nên giữ đúng chiều cao của template (`small` ~80dp, `medium` ~300dp) để
layout không nhảy khi ad view xuất hiện.

### Hạn chế đã biết (chưa làm trong bản này)

- **Ad view không thuộc DOM.** `NativeAdView` được gắn vào window content (Android) / root view
  (iOS), **không** vào WebView — nên đổi route bằng Vue Router **không** gỡ nó đi. Ad của trang cũ sẽ
  đè lên trang mới. App phải tự gọi `DestroyAdMobNativeAd()` (hoặc `HideAdMobNativeAd()`) trong
  `onBeforeUnmount`; SDK chưa tự hook vào router.
- **iOS không có hook lifecycle tương đương `handleOnDestroy`** — `CAPPlugin` không có callback đó,
  và plugin sống cùng app nên iOS thu hồi khi process kết thúc. Nếu cần chủ động thì vẫn phải gọi
  `DestroyAdMobNativeAd()` từ JS.
- **Chưa xử lý `handleOnPause` / `handleOnResume`** cho native ad video — về lý thuyết Google SDK tự
  quản, cần verify trên device thật xem video có tiếp tục phát tiếng khi app xuống background.
- **AppLovin MAX không có native ad**, chỉ AdMob.
