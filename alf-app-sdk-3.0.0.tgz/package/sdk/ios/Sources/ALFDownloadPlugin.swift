import Foundation
import Capacitor

@objc(ALFDownloadPlugin)
public class ALFDownloadPlugin: CAPPlugin, URLSessionDownloadDelegate {

  private var session: URLSession!
  private var activeCalls: [Int: CAPPluginCall] = [:]
  private var activeTargets: [Int: URL] = [:]

  override public func load() {
    let config = URLSessionConfiguration.default
    config.timeoutIntervalForRequest = 60
    config.timeoutIntervalForResource = 60 * 60
    session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
  }

  // ── Download to app private storage ───────────────────────────────────

  @objc func downloadToApp(_ call: CAPPluginCall) {
    guard let urlString = call.getString("url"), let relativePath = call.getString("relativePath"),
          !urlString.isEmpty, !relativePath.isEmpty else {
      call.reject("url and relativePath are required")
      return
    }
    guard let url = URL(string: urlString) else {
      call.reject("Invalid url")
      return
    }
    guard let baseDir = appStorageDirectory() else {
      call.reject("Cannot resolve app storage directory")
      return
    }
    guard let target = resolveWithin(baseDir, relativePath) else {
      call.reject("relativePath must stay inside app storage")
      return
    }
    startDownload(url, to: target, call: call)
  }

  // ── Download to device (app Documents — iOS has no writable system Download) ──

  @objc func downloadToDevice(_ call: CAPPluginCall) {
    guard let urlString = call.getString("url"), let targetPath = call.getString("targetPath"),
          !urlString.isEmpty, !targetPath.isEmpty else {
      call.reject("url and targetPath are required")
      return
    }
    guard let url = URL(string: urlString) else {
      call.reject("Invalid url")
      return
    }
    let baseDir = documentsDirectory()
    guard let target = resolveWithin(baseDir, targetPath) else {
      call.reject("targetPath must stay inside Documents")
      return
    }
    startDownload(url, to: target, call: call)
  }

  // ── App storage helpers ───────────────────────────────────────────────

  @objc func getAppPath(_ call: CAPPluginCall) {
    guard let relativePath = call.getString("relativePath"), !relativePath.isEmpty else {
      call.reject("relativePath is required")
      return
    }
    guard let baseDir = appStorageDirectory(),
          let resolved = resolveWithin(baseDir, relativePath) else {
      call.reject("relativePath must stay inside app storage")
      return
    }
    var result = JSObject()
    result["path"] = resolved.path
    call.resolve(result)
  }

  @objc func isAppFileExists(_ call: CAPPluginCall) {
    guard let relativePath = call.getString("relativePath"), !relativePath.isEmpty else {
      call.reject("relativePath is required")
      return
    }
    guard let baseDir = appStorageDirectory(),
          let resolved = resolveWithin(baseDir, relativePath) else {
      call.reject("relativePath must stay inside app storage")
      return
    }
    var result = JSObject()
    result["exists"] = FileManager.default.fileExists(atPath: resolved.path)
    call.resolve(result)
  }

  // ── Engine ────────────────────────────────────────────────────────────

  private func startDownload(_ url: URL, to target: URL, call: CAPPluginCall) {
    let task = session.downloadTask(with: url)
    activeCalls[task.taskIdentifier] = call
    activeTargets[task.taskIdentifier] = target
    task.resume()
  }

  private func resolveWithin(_ base: URL, _ relativePath: String) -> URL? {
    let resolved = base.appendingPathComponent(relativePath)
    let basePath = base.standardizedFileURL.path
    let resolvedPath = resolved.standardizedFileURL.path
    guard resolvedPath == basePath || resolvedPath.hasPrefix(basePath + "/") else {
      return nil
    }
    return resolved
  }

  private func appStorageDirectory() -> URL? {
    let fm = FileManager.default
    return try? fm.url(for: .applicationSupportDirectory, in: .userDomainMask,
                       appropriateFor: nil, create: true)
  }

  private func documentsDirectory() -> URL {
    return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
  }

  // MARK: - URLSessionDownloadDelegate

  public func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                         didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                         totalBytesExpectedToWrite: Int64) {
    let url = downloadTask.originalRequest?.url?.absoluteString ?? ""
    var data = JSObject()
    data["url"] = url
    data["receivedBytes"] = totalBytesWritten
    data["totalBytes"] = totalBytesExpectedToWrite >= 0 ? totalBytesExpectedToWrite : 0
    data["progress"] = totalBytesExpectedToWrite > 0
      ? Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
      : 0.0
    notifyListeners("OnDownloadProgress", data: data)
  }

  public func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                         didFinishDownloadingTo location: URL) {
    let id = downloadTask.taskIdentifier
    guard let call = activeCalls.removeValue(forKey: id),
          let target = activeTargets.removeValue(forKey: id) else {
      return
    }
    let fm = FileManager.default
    do {
      try fm.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
      if fm.fileExists(atPath: target.path) {
        try fm.removeItem(at: target)
      }
      try fm.moveItem(at: location, to: target)
      var result = JSObject()
      result["path"] = target.path
      DispatchQueue.main.async {
        call.resolve(result)
      }
    } catch {
      DispatchQueue.main.async {
        call.reject("Download failed: \(error.localizedDescription)")
      }
    }
  }

  public func urlSession(_ session: URLSession, task: URLSessionTask,
                         didCompleteWithError error: Error?) {
    if let error = error {
      let id = task.taskIdentifier
      if let call = activeCalls.removeValue(forKey: id) {
        activeTargets.removeValue(forKey: id)
        DispatchQueue.main.async {
          call.reject("Download failed: \(error.localizedDescription)")
        }
      }
    }
  }
}
