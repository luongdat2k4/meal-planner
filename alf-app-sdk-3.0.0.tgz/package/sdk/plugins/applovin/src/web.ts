import type {
  ALFAppLovinMAXPlugin,
  InitializeOptions,
  InitializeResult,
  AdUnitOptions,
  AdUnitPositionOptions,
  IsReadyResult,
  IsTabletResult,
  MRecAdUnitOptions,
  UpdateMRecRectOptions,
  RewardEvent,
  PluginListenerHandle,
} from './definitions'

export class ALFAppLovinMAXWeb implements ALFAppLovinMAXPlugin {
  async initialize(_options: InitializeOptions): Promise<InitializeResult> {
    console.warn('[ALFAppLovinMAX] Web: initialize is a no-op')
    return { initialized: false }
  }

  async isTablet(): Promise<IsTabletResult> {
    return { isTablet: false }
  }

  async createBanner(_options: AdUnitPositionOptions): Promise<void> {
    console.warn('[ALFAppLovinMAX] Web: createBanner is a no-op')
  }

  async showBanner(_options: AdUnitOptions): Promise<void> {}

  async hideBanner(_options: AdUnitOptions): Promise<void> {}

  async destroyBanner(_options: AdUnitOptions): Promise<void> {}

  async createMRec(_options: MRecAdUnitOptions): Promise<void> {
    console.warn('[ALFAppLovinMAX] Web: createMRec is a no-op')
  }

  async updateMRecRect(_options: UpdateMRecRectOptions): Promise<void> {}

  async showMRec(_options: AdUnitOptions): Promise<void> {}

  async hideMRec(_options: AdUnitOptions): Promise<void> {}

  async destroyMRec(_options: AdUnitOptions): Promise<void> {}

  async loadInterstitial(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAppLovinMAX] Web: loadInterstitial is a no-op')
  }

  async isInterstitialReady(_options: AdUnitOptions): Promise<IsReadyResult> {
    return { ready: false }
  }

  async showInterstitial(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAppLovinMAX] Web: showInterstitial is a no-op')
  }

  async loadRewardedAd(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAppLovinMAX] Web: loadRewardedAd is a no-op')
  }

  async isRewardedAdReady(_options: AdUnitOptions): Promise<IsReadyResult> {
    return { ready: false }
  }

  async showRewardedAd(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAppLovinMAX] Web: showRewardedAd is a no-op')
  }

  async loadAppOpenAd(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAppLovinMAX] Web: loadAppOpenAd is a no-op')
  }

  async isAppOpenAdReady(_options: AdUnitOptions): Promise<IsReadyResult> {
    return { ready: false }
  }

  async showAppOpenAd(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAppLovinMAX] Web: showAppOpenAd is a no-op')
  }

  async addListener(
    _eventName: string,
    _listener: (event: RewardEvent & { error: string }) => void,
  ): Promise<PluginListenerHandle> {
    return { remove: () => {} }
  }

  async removeAllListeners(): Promise<void> {}
}
