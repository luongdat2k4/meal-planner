# IAPController — In-App Purchase & Subscription

**Scope:** Quản lý In-App Purchase (IAP) cho cả Android (Google Play) và iOS (App Store).

**Access:** `ALF.Instance.IAP`

---

## 1. Mục đích

`IAPController` là đầu mối duy nhất để thực hiện mọi thao tác liên quan đến mua hàng trong ứng dụng:

- Load sản phẩm từ store (Google Play + App Store)
- Mua hàng (consumable, non-consumable, subscription)
- Restore purchases đã mua trước đó
- Kiểm tra quyền lợi (entitlement) của user
- Quản lý subscription (huỷ, gia hạn)
- Hỗ trợ server-side validation qua receipt (iOS) / purchaseToken (Android)

---

## 2. Native Plugin

`IAPController` sử dụng **`@capgo/native-purchases`** làm native bridge:

| Platform | Native API | Version |
|---|---|---|
| Android | Google Play Billing 7.x | ✅ |
| iOS | StoreKit 2 | ✅ (iOS 15+) |

Plugin này là open-source (MPL-2.0), miễn phí, và được bảo trì tích cực.

---

## 3. Cấu hình

### 3.1. Config `keys.iap`

IAP products được định nghĩa trong config dưới `keys.iap`:

```json
{
  "keys": {
    "iap": {
      "enable": true,
      "products": [
        {
          "id": "remove_ads",
          "type": "non_consumable",
          "removesAds": true,
          "skus": {
            "android": "com.alf.remove_ads",
            "ios": "com.alf.remove_ads"
          }
        },
        {
          "id": "coins_100",
          "type": "consumable",
          "skus": {
            "android": "com.alf.coins_100",
            "ios": "com.alf.coins_100"
          }
        },
        {
          "id": "pro_monthly",
          "type": "auto_renewable",
          "period": "monthly",
          "skus": {
            "android": "com.alf.pro.monthly",
            "ios": "com.alf.pro.monthly"
          }
        }
      ]
    }
  }
}
```

### 3.2. Product Config Fields

| Field | Type | Bắt buộc | Mô tả |
|---|---|---|---|
| `id` | `string` | ✅ | Logical product ID, dùng trong code để tham chiếu |
| `type` | `IAPProductType` | ✅ | `consumable`, `non_consumable`, `auto_renewable`, `non_renewing` |
| `period` | `IAPSubscriptionPeriod` | (nếu là sub) | `free_trial`, `weekly`, `monthly`, `quarterly`, `semi_annual`, `annual`, `lifetime` |
| `skus.android` | `string` | ✅ | Product ID trên Google Play Console |
| `skus.ios` | `string` | ✅ | Product ID trên App Store Connect |
| `removesAds` | `boolean` | | Sở hữu sản phẩm này thì tắt banner, MREC, native, interstitial, app open (rewarded vẫn chạy) |

### 3.3. Product Types

| Type | Ý nghĩa | Ví dụ | Mua lại được? |
|---|---|---|---|
| `consumable` | Mua nhiều lần, dùng rồi hết | Coin, gem, vật phẩm | ✅ Có |
| `non_consumable` | Mua một lần, mở vĩnh viễn | Xoá quảng cáo, premium | ❌ (chỉ 1 lần) |
| `auto_renewable` | Subscription tự động gia hạn | Pro Monthly, Pro Yearly | ❌ (quản lý qua subscription) |
| `non_renewing` | Subscription không tự gia hạn | Gói 7 ngày | ✅ Có, mua lại khi hết hạn |

---

## 4. API

### 4.1. Products

```typescript
// Lấy tất cả sản phẩm (tự động fetch từ store nếu chưa load)
const products = await ALF.Instance.IAP.getProducts()
// => IAPProduct[]

// Lấy 1 sản phẩm theo logical ID
const product = await ALF.Instance.IAP.getProduct('pro_monthly')
// => IAPProduct | undefined

// Refresh metadata từ store (giá, tên, mô tả)
await ALF.Instance.IAP.refreshProducts()
```

### 4.2. Purchase

**Consumable phải đi qua grant handler.** Đăng ký một lần, ngay sau khi `initSDK()` xong:

```typescript
ALF.Instance.IAP.setGrantHandler(async (grant) => {
  // grant: { productId, nativeProductId, transactionId, quantity, source: 'purchase' | 'reconcile' }
  if (grant.productId === 'coins_100') await addCoins(100 * grant.quantity)
})
```

Thứ tự: giao hàng (handler) → ghi `transactionId` xuống máy → consume (Android) / finish (iOS).
App chết giữa chừng thì lần reconcile sau giao lại (chưa ghi) hoặc chỉ consume (đã ghi) — không
mất hàng, không giao hai lần. Handler throw thì purchase còn mở, lần reconcile sau thử lại.
Handler chạy bên trong `reconcile()`, nên không được `await` `reconcile()` / `getEntitlements()` /
`hasEntitlement()` / `refreshEntitlements()` trong đó.

Không đăng ký handler thì `purchase()` consume ngay trước khi trả về (cách cũ, không an toàn khi
crash) và consumable còn mở không được giao lại.

```typescript
// Mua sản phẩm
const result = await ALF.Instance.IAP.purchase('coins_100')
// => IAPPurchaseResult

// Mua với options
const result = await ALF.Instance.IAP.purchase('pro_monthly', {
  appAccountToken: 'user-uu-id',    // Mã định danh user (chống gian lận)
  billingPlanType: 'monthly',       // iOS: monthly commitment
  autoAcknowledge: true,            // Tự động acknowledge
})
// => IAPPurchaseResult
```

`IAPPurchaseResult`:

| Field | Type | Mô tả |
|---|---|---|
| `transactionId` | `string` | Unique ID của giao dịch |
| `productId` | `string` | Logical product ID (từ config) |
| `nativeProductId` | `string` | Product ID trên store |
| `purchaseDate` | `string` | Ngày mua (ISO 8601) |
| `verificationToken` | `string?` | iOS: receipt / Android: purchaseToken |
| `orderId` | `string?` | Android: Google Play order ID |
| `isAcknowledged` | `boolean` | Đã acknowledge chưa |
| `isRenewal` | `boolean?` | Có phải renewal không |
| `environment` | `string?` | `Sandbox` / `Production` / `Xcode` |

Lỗi có `error.code` (`IAPError`): `cancelled` (iOS huỷ), `pending` (chưa thanh toán xong — giao
sau qua reconcile), `not_purchased` (Android: huỷ hoặc lỗi, Google Play không phân biệt),
`unavailable`, `product_not_found`, `failed`.

### 4.3. Consume & Acknowledge

Purchase qua `purchase()` được consume/acknowledge tự động. Chỉ dùng các hàm dưới cho purchase xử
lý ngoài SDK.

```typescript
// Consume purchase (Android)
await ALF.Instance.IAP.consumePurchase('purchase-token')

// Acknowledge thủ công (khi autoAcknowledge = false)
await ALF.Instance.IAP.acknowledgePurchase('transaction-id')
```

> **Lưu ý:** Mặc định `autoAcknowledge = true`. Trên Android, purchase phải được acknowledge trong vòng 3 ngày nếu không sẽ bị Google Play tự động refund.

### 4.4. Restore

```typescript
// Restore purchases đã mua trước đó
const entitlements = await ALF.Instance.IAP.restore()
// => IAPEntitlement[]
```

### 4.5. Entitlements

```typescript
// Kiểm tra user có quyền với sản phẩm không
const hasPro = await ALF.Instance.IAP.hasEntitlement('pro_monthly')
// => boolean (với subscription: kiểm tra isActive)

// Lấy danh sách tất cả entitlements
const entitlements = await ALF.Instance.IAP.getEntitlements()
// => IAPEntitlement[]

// Refresh entitlements từ store
await ALF.Instance.IAP.refreshEntitlements()

// Sản phẩm đang sở hữu (cache trên máy — đúng cả khi offline)
const owned = await ALF.Instance.IAP.getOwnedProductIds()
const unsub = ALF.Instance.IAP.onEntitlementsChanged((ids) => { /* cập nhật UI */ })

// Remove ads
const removed = await ALF.Instance.Ads.IsAdsRemoved()
```

Sản phẩm đã sở hữu được lưu ở `iap-data.json`; cache chỉ bỏ một sản phẩm khi store trả lời mà
không có nó (mất mạng thì giữ nguyên).

### 4.5b. Reconcile

`reconcile()` đối chiếu với danh sách mua của store: giao consumable còn mở, acknowledge
non-consumable / subscription chưa acknowledge (thanh toán pending đã xong), cập nhật cache sở hữu.
Tự chạy khi init và mỗi lần app quay lại foreground.

### 4.5c. Revenue

Mỗi giao dịch mới log một event Firebase `iap_purchase` (`product_id`, `product_type`,
`quantity`, `transaction_id`, `value`, `currency`). Renewal không log. Không dùng
`purchase` / `in_app_purchase` để khỏi đếm doanh thu hai lần với event Firebase tự log. Muốn thấy
`value` trong báo cáo GA4 thì đăng ký nó là custom metric.

`IAPEntitlement`:

| Field | Type | Mô tả |
|---|---|---|
| `transactionId` | `string` | Transaction ID |
| `productId` | `string` | Logical product ID |
| `purchaseDate` | `string` | Ngày mua |
| `expirationDate` | `string?` | Ngày hết hạn (subscription) |
| `isActive` | `boolean` | Subscription còn hiệu lực? |
| `willCancel` | `boolean` | Sẽ huỷ ở cuối chu kỳ? |
| `subscriptionState` | `string?` | iOS: `subscribed`, `expired`, `revoked`, `inGracePeriod`, `inBillingRetryPeriod` |
| `isTrialPeriod` | `boolean?` | Đang trong trial? |
| `isInIntroPricePeriod` | `boolean?` | Đang trong intro pricing? |
| `orderId` | `string?` | Android order ID |
| `verificationToken` | `string?` | Dùng cho server-side validation |

### 4.6. Subscription Management

```typescript
// Mở trang quản lý subscription native (Google Play / App Store)
await ALF.Instance.IAP.manageSubscriptions()
```

### 4.7. Utilities

```typescript
// Kiểm tra thiết bị hỗ trợ IAP không
const supported = await ALF.Instance.IAP.isBillingSupported()

// Lấy version của native plugin
const version = await ALF.Instance.IAP.getPluginVersion()
```

---

## 5. Server-side Validation

### 5.1. iOS (App Store)

Sau khi purchase thành công, `result.verificationToken` chứa **base64 receipt**. Gửi lên backend để verify với Apple:

```typescript
const result = await ALF.Instance.IAP.purchase('pro_monthly')

// Gửi receipt lên backend
await fetch('/api/validate-receipt', {
  method: 'POST',
  body: JSON.stringify({ receipt: result.verificationToken })
})
```

**Endpoints:**
- Production: `https://buy.itunes.apple.com/verifyReceipt`
- Sandbox: `https://sandbox.itunes.apple.com/verifyReceipt`

> Apple khuyến nghị migration sang **App Store Server API v2** với JWS representation.

### 5.2. Android (Google Play)

`result.verificationToken` chứa **purchaseToken**. Gửi lên backend để verify với Google:

```typescript
const result = await ALF.Instance.IAP.purchase('coins_100')

// Gửi purchaseToken lên backend
await fetch('/api/validate-purchase', {
  method: 'POST',
  body: JSON.stringify({
    purchaseToken: result.verificationToken,
    productId: result.nativeProductId,
  })
})
```

**API:** `androidpublisher.purchases.products.get()` hoặc `purchases.subscriptions.get()` (v3)

---

## 6. Luồng sử dụng điển hình

### 6.1. Load products & hiển thị store

```typescript
// Trong view component
const products = ref<IAPProduct[]>([])

onMounted(async () => {
  products.value = await ALF.Instance.IAP.getProducts()
})
```

### 6.2. Mua hàng

```typescript
// Coin được cộng trong grant handler (4.2), không cộng ở đây.
async function buyCoins() {
  try {
    await ALF.Instance.IAP.purchase('coins_100')
    toast.success('Mua thành công!')
  } catch (e: any) {
    if (e.code === 'cancelled' || e.code === 'not_purchased') {
      toast.info('Chưa mua')
    } else if (e.code === 'pending') {
      toast.info('Đang chờ thanh toán — coin sẽ được cộng khi xong')
    } else {
      toast.error('Mua thất bại: ' + e.message)
    }
  }
}
```

### 6.3. Kiểm tra subscription khi vào app

```typescript
// Trong main.ts hoặc App.vue boot
const isPro = await ALF.Instance.IAP.hasEntitlement('pro_monthly')
if (!isPro) {
  // Hiển thị paywall
}
```

### 6.4. Restore purchases

```typescript
async function restorePurchases() {
  try {
    const entitlements = await ALF.Instance.IAP.restore()
    toast.success(`Đã khôi phục ${entitlements.length} giao dịch`)
  } catch (e) {
    toast.error('Không thể khôi phục')
  }
}
```

---

## 7. Testing

### 7.1. Sandbox Testing

**iOS:**
1. Tạo **Sandbox Tester** trong App Store Connect
2. Build app bằng Xcode với scheme Release
3. Đăng nhập bằng sandbox account khi được hỏi

**Android:**
1. Upload app lên **Internal Testing Track** trên Google Play Console
2. Thêm email tester vào danh sách
3. Cài app từ Internal Testing link
4. Thanh toán tự động dùng license test — không mất tiền thật

### 7.2. Kiểm tra purchase state

```typescript
// Dev tool: log tất cả entitlements
const ents = await ALF.Instance.IAP.getEntitlements()
console.table(ents.map(e => ({
  product: e.productId,
  active: e.isActive,
  state: e.subscriptionState,
  expires: e.expirationDate,
  trial: e.isTrialPeriod,
})))
```

---

## 8. Troubleshooting

### `@capgo/native-purchases not installed`

Cài native plugin:

```bash
npm install @capgo/native-purchases
npx cap sync
```

### Purchase fails silently / `PURCHASE_CANCELLED`

- Trên iOS Simulator: IAP không hoạt động, cần device thật
- Trên Android Emulator: Cần Google Play services, dùng device có Google Play

### `isBillingSupported() = false`

- iOS: IAP Capability chưa được bật trong Xcode
- Android: Thiết bị không hỗ trợ Google Play hoặc chưa đăng nhập tài khoản Google

### Entitlements không đúng

Gọi `refreshEntitlements()` để force refresh từ store:

```typescript
await ALF.Instance.IAP.refreshEntitlements()
```

### Receipt validation failed (iOS)

- Sandbox receipt gửi lên production endpoint → fail
- Phải thử cả production trước, fallback về sandbox

---

## 9. Tham khảo

- [Apple In-App Purchase](https://developer.apple.com/in-app-purchase/)
- [Apple Receipt Validation](https://developer.apple.com/documentation/appstorereceipts)
- [Google Play Billing](https://developer.android.com/google/play/billing)
- [Google Play Developer API v3](https://developer.android.com/google/play/developer-api)
- [@capgo/native-purchases](https://capgo.app/docs/plugins/native-purchases/)
- [Capgo native-purchases GitHub](https://github.com/Cap-go/native-purchases)
