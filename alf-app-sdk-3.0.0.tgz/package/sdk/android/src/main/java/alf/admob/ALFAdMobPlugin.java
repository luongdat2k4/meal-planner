package alf.admob;

import alf.ALFTrace;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.alf.appsdk.R;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdValue;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.appopen.AppOpenAd;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.MediaContent;
import com.google.android.gms.ads.nativead.MediaView;
import com.google.android.gms.ads.nativead.NativeAd;
import com.google.android.gms.ads.nativead.NativeAdOptions;
import com.google.android.gms.ads.nativead.NativeAdView;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "ALFAdMob")
public class ALFAdMobPlugin extends Plugin {

  private static final String TAG = "ALFAdMob";

  private boolean isSdkInitialized = false;

  // Ad instances cache
  // Concurrent: load callbacks write these on the main thread while
  // isXxxReady()/showXxx() read them on the plugin thread.
  private final Map<String, InterstitialAd> interstitials = new ConcurrentHashMap<>();
  private final Map<String, RewardedAd> rewardedAds = new ConcurrentHashMap<>();
  private final Map<String, AppOpenAd> openAppAds = new HashMap<>();
  // Native ads are keyed by SLOT, not by ad unit: one unit may back two places
  // on screen at once (e.g. a bottom native and an MREC-sized native sharing one
  // Meta bidding unit). A call without `slot` uses its ad unit as the slot —
  // exactly the old one-ad-per-unit behaviour.
  private final Map<String, NativeAd> nativeAds = new HashMap<>();
  // Rendered native ad views, keyed by slot — the NativeAdView is what makes
  // the ad a real ad: it records the impression and owns the click handling.
  private final Map<String, NativeAdView> nativeAdViews = new HashMap<>();
  // Controls drawn over a rect-mode native ad (label + close button), keyed by
  // slot. Touched on the UI thread only.
  private final Map<String, NativeAdOverlay> nativeAdOverlays = new HashMap<>();
  // Ad unit currently loaded (or loading) in each slot, so events can name both.
  private final Map<String, String> nativeSlotUnits = new ConcurrentHashMap<>();
  // Latest load per slot. A load that finishes after a newer load — or a
  // destroy — for the same slot is thrown away, so the slow first unit of a
  // fallback chain cannot land on top of the unit that replaced it.
  private final Map<String, Object> nativeLoadTokens = new ConcurrentHashMap<>();
  // Concurrent: written on the plugin thread, iterated by the lifecycle
  // callbacks and pruned by load failures on the main thread.
  private final Map<String, AdView> banners = new ConcurrentHashMap<>();
  // A hidden banner is paused: a GONE AdView keeps refreshing and rendering its
  // WebView otherwise. Both touched on the UI thread only.
  //   bannersLoaded — first load done. Never paused before that, so a banner
  //                   hidden while loading still delivers its first onAdLoaded.
  //   bannersPaused — pause() was called and not undone by resume().
  private final Set<AdView> bannersLoaded = new HashSet<>();
  private final Set<AdView> bannersPaused = new HashSet<>();
  // Between handleOnPause and handleOnResume. UI thread only.
  private boolean activityPaused = false;

  // Rewarded state
  private final Map<String, Boolean> rewardedGranted = new ConcurrentHashMap<>();

  // ── Initialize ──────────────────────────────────
  @PluginMethod
  public void initialize(PluginCall call) {
    String appId = call.getString("appId");
    if (appId == null || appId.isEmpty()) {
      call.reject("appId is required");
      return;
    }

    MobileAds.initialize(
      getContext(),
      new OnInitializationCompleteListener() {
        @Override
        public void onInitializationComplete(InitializationStatus status) {
          isSdkInitialized = true;
          JSObject result = new JSObject();
          result.put("initialized", true);
          call.resolve(result);
          Log.i(TAG, "MobileAds initialized");
        }
      }
    );
  }

  // ── Banner ──────────────────────────────────────
  /**
   * Create and load a banner ad, then attach it to the window.
   * Resolves with the loaded banner size (dp) once the ad finishes loading.
   */
  @PluginMethod
  public void createBanner(PluginCall call) {
    ALFTrace.run("ALF.createBanner", () -> createBannerImpl(call));
  }

  private void createBannerImpl(final PluginCall call) {
    if (!requireSdk(call)) return;
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null || adUnitId.isEmpty()) {
      call.reject("adUnitId is required");
      return;
    }

    String position = call.getString("position", "BOTTOM_CENTER");
    String collapsible = call.getString("collapsible");

    // Replace any existing banner for this unit
    AdView existing = banners.remove(adUnitId);
    if (existing != null) {
      getActivity().runOnUiThread(() -> {
        removeFromContainer(existing);
        forgetBannerState(existing);
        existing.destroy();
      });
    }

    final AdView adView = new AdView(getContext());
    adView.setAdUnitId(adUnitId);
    adView.setAdSize(parseAdSize(call));

    final boolean bottom = position.equals("BOTTOM_CENTER");
    final AtomicBoolean loadCallCompleted = new AtomicBoolean(false);
    adView.setAdListener(new AdListener() {
      @Override
      public void onAdLoaded() {
        // Main thread. Hidden (or app paused) before the first load finished:
        // pause now that it is safe to.
        bannersLoaded.add(adView);
        if (adView.getVisibility() != View.VISIBLE || activityPaused) pauseBanner(adView);
        if (loadCallCompleted.compareAndSet(false, true)) {
          JSObject result = new JSObject();
          AdSize size = adView.getAdSize();
          if (size != null) {
            result.put("width", toDp(size.getWidthInPixels(getContext())));
            result.put("height", toDp(size.getHeightInPixels(getContext())));
          } else {
            result.put("width", 0);
            result.put("height", 0);
          }
          call.resolve(result);
        }
      }

      @Override
      public void onAdFailedToLoad(LoadAdError loadAdError) {
        if (loadCallCompleted.compareAndSet(false, true)) {
          // Two-arg remove: a newer banner for this unit stays.
          banners.remove(adUnitId, adView);
          call.reject(loadAdError.getMessage());
        }
      }
    });

    getActivity().runOnUiThread(() -> {
      FrameLayout.LayoutParams params = bannerLayoutParams(adView, bottom);
      getAdContainer().addView(adView, params);
      if (bottom) applyBottomInset(adView);
      // loadAd() must be called on the main thread.
      adView.loadAd(buildBannerRequest(collapsible));
    });

    banners.put(adUnitId, adView);
  }

  @PluginMethod
  public void showBanner(PluginCall call) {
    ALFTrace.run("ALF.showBanner", () -> showBannerImpl(call));
  }

  private void showBannerImpl(final PluginCall call) {
    String adUnitId = call.getString("adUnitId");
    // Concurrent map: get(null) would throw.
    AdView adView = adUnitId != null ? banners.get(adUnitId) : null;
    if (adView == null) {
      call.reject("Banner not found");
      return;
    }
    getActivity().runOnUiThread(() -> {
      // In the background handleOnResume resumes it instead.
      if (!activityPaused) resumeBanner(adView);
      adView.setVisibility(View.VISIBLE);
    });
    call.resolve();
  }

  @PluginMethod
  public void hideBanner(PluginCall call) {
    String adUnitId = call.getString("adUnitId");
    // Concurrent map: get(null) would throw.
    AdView adView = adUnitId != null ? banners.get(adUnitId) : null;
    if (adView == null) {
      call.reject("Banner not found");
      return;
    }
    getActivity().runOnUiThread(() -> {
      adView.setVisibility(View.GONE);
      // Still on its first load: onAdLoaded pauses it instead.
      if (bannersLoaded.contains(adView)) pauseBanner(adView);
    });
    call.resolve();
  }

  @PluginMethod
  public void destroyBanner(PluginCall call) {
    String adUnitId = call.getString("adUnitId");
    AdView adView = adUnitId != null ? banners.remove(adUnitId) : null;
    if (adView == null) {
      call.reject("Banner not found");
      return;
    }
    getActivity().runOnUiThread(() -> {
      removeFromContainer(adView);
      forgetBannerState(adView);
      adView.destroy();
    });
    call.resolve();
  }

  // UI thread only (see bannersLoaded). pause()/resume() are paired through
  // bannersPaused so neither runs twice in a row.
  private void pauseBanner(AdView adView) {
    if (bannersPaused.add(adView)) adView.pause();
  }

  private void resumeBanner(AdView adView) {
    if (bannersPaused.remove(adView)) adView.resume();
  }

  private void forgetBannerState(AdView adView) {
    bannersLoaded.remove(adView);
    bannersPaused.remove(adView);
  }

  // ── Interstitial ────────────────────────────────
  //
  // Each ad unit is cached and reported separately, so an app can chain several
  // units (e.g. an image unit, then a video unit) and tell their events apart.
  // Every event carries `adUnitId`:
  //   OnInterstitialAdShowedEvent       — the ad took over the screen
  //   OnInterstitialAdFailedToShowEvent — show() was accepted but the ad never
  //                                       appeared (`message`); the app may move on
  //   OnInterstitialAdDismissedEvent    — the user closed the ad
  //   OnInterstitialAdPaidEvent         — revenue of the impression, same shape
  //                                       as OnNativeAdPaidEvent
  @PluginMethod
  public void loadInterstitial(PluginCall call) {
    ALFTrace.run("ALF.loadInterstitial", () -> loadInterstitialImpl(call));
  }

  private void loadInterstitialImpl(final PluginCall call) {
    if (!requireSdk(call)) return;
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    final AtomicBoolean resolved = new AtomicBoolean(false);
    // InterstitialAd.load() must run on the main UI thread. From the plugin
    // thread it throws IllegalStateException "#008 Must be called on the main
    // UI thread", which nothing catches and the app dies.
    getActivity().runOnUiThread(() -> InterstitialAd.load(
      getContext(), adUnitId, new AdRequest.Builder().build(),
      new InterstitialAdLoadCallback() {
        @Override
        public void onAdLoaded(InterstitialAd interstitialAd) {
          if (resolved.getAndSet(true)) return;
          interstitialAd.setOnPaidEventListener(
            adValue -> notifyAdPaid("OnInterstitialAdPaidEvent", adUnitId, adValue));
          interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdShowedFullScreenContent() {
              notifyAdUnitEvent("OnInterstitialAdShowedEvent", adUnitId);
            }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError adError) {
              // The ad is spent either way; only remove it if it is still ours.
              interstitials.remove(adUnitId, interstitialAd);
              JSObject event = new JSObject();
              event.put("adUnitId", adUnitId);
              event.put("message", adError.getMessage());
              notifyListeners("OnInterstitialAdFailedToShowEvent", event);
            }

            @Override
            public void onAdDismissedFullScreenContent() {
              interstitials.remove(adUnitId, interstitialAd);
              notifyAdUnitEvent("OnInterstitialAdDismissedEvent", adUnitId);
            }
          });
          interstitials.put(adUnitId, interstitialAd);
          call.resolve();
        }

        @Override
        public void onAdFailedToLoad(LoadAdError loadAdError) {
          if (resolved.getAndSet(true)) return;
          interstitials.remove(adUnitId);
          call.reject(loadAdError.getMessage());
        }
      }
    ));
  }

  @PluginMethod
  public void isInterstitialReady(PluginCall call) {
    if (!requireSdk(call)) return;
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    JSObject result = new JSObject();
    result.put("ready", interstitials.containsKey(adUnitId));
    call.resolve(result);
  }

  /**
   * Resolves once show() has been handed to the ad, not when it is visible or
   * closed — follow OnInterstitialAdShowedEvent / FailedToShow / Dismissed.
   * The ad leaves the cache as soon as it is shown: an interstitial plays once,
   * so isInterstitialReady() turns false and a second showInterstitial() for
   * the same unit is rejected instead of replaying it.
   */
  @PluginMethod
  public void showInterstitial(PluginCall call) {
    ALFTrace.run("ALF.showInterstitial", () -> showInterstitialImpl(call));
  }

  private void showInterstitialImpl(final PluginCall call) {
    if (!requireSdk(call)) return;
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    InterstitialAd interstitialAd = interstitials.remove(adUnitId);
    if (interstitialAd != null) {
      // show() must be called on the main UI thread.
      getActivity().runOnUiThread(() -> interstitialAd.show(getActivity()));
      call.resolve();
    } else {
      call.reject("Interstitial not ready");
    }
  }

  // ── Rewarded ────────────────────────────────────
  @PluginMethod
  public void loadRewardedAd(PluginCall call) {
    ALFTrace.run("ALF.loadRewardedAd", () -> loadRewardedAdImpl(call));
  }

  private void loadRewardedAdImpl(final PluginCall call) {
    requireSdk(call);
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    final AtomicBoolean resolved = new AtomicBoolean(false);
    // Same main-thread rule as InterstitialAd.load() — see loadInterstitial().
    getActivity().runOnUiThread(() -> RewardedAd.load(
      getContext(), adUnitId, new AdRequest.Builder().build(),
      new RewardedAdLoadCallback() {
        @Override
        public void onAdLoaded(RewardedAd rewardedAd) {
          if (resolved.getAndSet(true)) return;
          rewardedAds.put(adUnitId, rewardedAd);
          rewardedGranted.put(adUnitId, false);
          rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
              if (!Boolean.TRUE.equals(rewardedGranted.getOrDefault(adUnitId, false))) {
                JSObject event = new JSObject();
                event.put("adUnitId", adUnitId);
                notifyListeners("OnRewardedAdSkippedEvent", event);
              }
              rewardedAds.remove(adUnitId);
              rewardedGranted.remove(adUnitId);
              notifyAdUnitEvent("OnRewardedAdDismissedEvent", adUnitId);
            }
          });
          call.resolve();
        }

        @Override
        public void onAdFailedToLoad(LoadAdError loadAdError) {
          if (resolved.getAndSet(true)) return;
          rewardedAds.remove(adUnitId);
          call.reject(loadAdError.getMessage());
        }
      }
    ));
  }

  @PluginMethod
  public void isRewardedAdReady(PluginCall call) {
    requireSdk(call);
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    JSObject result = new JSObject();
    result.put("ready", rewardedAds.containsKey(adUnitId));
    call.resolve(result);
  }

  @PluginMethod
  public void showRewardedAd(PluginCall call) {
    ALFTrace.run("ALF.showRewardedAd", () -> showRewardedAdImpl(call));
  }

  private void showRewardedAdImpl(final PluginCall call) {
    requireSdk(call);
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    RewardedAd rewardedAd = rewardedAds.get(adUnitId);
    if (rewardedAd != null) {
      // show() must be called on the main UI thread.
      getActivity().runOnUiThread(() -> {
        rewardedAd.show(
          getActivity(),
          new OnUserEarnedRewardListener() {
            @Override
            public void onUserEarnedReward(RewardItem rewardItem) {
              rewardedGranted.put(adUnitId, true);
              JSObject event = new JSObject();
              event.put("adUnitId", adUnitId);
              event.put("amount", rewardItem.getAmount());
              notifyListeners("OnRewardedAdReceivedRewardEvent", event);
            }
          }
        );
      });
      call.resolve();
    } else {
      call.reject("Rewarded ad not ready");
    }
  }

  // ── Open App ────────────────────────────────────
  @PluginMethod
  public void loadOpenAppAd(PluginCall call) {
    ALFTrace.run("ALF.loadOpenAppAd", () -> loadOpenAppAdImpl(call));
  }

  private void loadOpenAppAdImpl(final PluginCall call) {
    requireSdk(call);
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    final AtomicBoolean resolved = new AtomicBoolean(false);
    // AppOpenAd.load() must be called on the main UI thread, unlike interstitial/rewarded loads.
    getActivity().runOnUiThread(() -> {
      AppOpenAd.load(
        getContext(), adUnitId, new AdRequest.Builder().build(),
        new AppOpenAd.AppOpenAdLoadCallback() {
          @Override
          public void onAdLoaded(AppOpenAd appOpenAd) {
            if (resolved.getAndSet(true)) return;
            openAppAds.put(adUnitId, appOpenAd);
            appOpenAd.setFullScreenContentCallback(new FullScreenContentCallback() {
              @Override
              public void onAdDismissedFullScreenContent() {
                openAppAds.remove(adUnitId);
                notifyAdUnitEvent("OnOpenAppAdDismissedEvent", adUnitId);
              }
            });
            call.resolve();
          }

          @Override
          public void onAdFailedToLoad(LoadAdError loadAdError) {
            if (resolved.getAndSet(true)) return;
            openAppAds.remove(adUnitId);
            call.reject(loadAdError.getMessage());
          }
        }
      );
    });
  }

  @PluginMethod
  public void isOpenAppAdReady(PluginCall call) {
    requireSdk(call);
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    JSObject result = new JSObject();
    result.put("ready", openAppAds.containsKey(adUnitId));
    call.resolve(result);
  }

  @PluginMethod
  public void showOpenAppAd(PluginCall call) {
    ALFTrace.run("ALF.showOpenAppAd", () -> showOpenAppAdImpl(call));
  }

  private void showOpenAppAdImpl(final PluginCall call) {
    requireSdk(call);
    String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }

    AppOpenAd appOpenAd = openAppAds.get(adUnitId);
    if (appOpenAd != null) {
      // show() must be called on the main UI thread.
      getActivity().runOnUiThread(() -> appOpenAd.show(getActivity()));
      call.resolve();
    } else {
      call.reject("Open app ad not ready");
    }
  }

  // ── Native Ad ───────────────────────────────────
  /** Notified once a native ad load finishes, either way. */
  private interface NativeAdLoadCallback {
    void onLoaded(NativeAd nativeAd);
    void onFailed(String error);
  }

  /** The slot a native call acts on: its `slot`, or its ad unit when it has none. */
  private String nativeSlot(PluginCall call) {
    String slot = call.getString("slot");
    return slot != null && !slot.isEmpty() ? slot : call.getString("adUnitId");
  }

  /**
   * Load a native ad for the unit into the slot, replacing whatever the slot
   * held. Shared by loadNativeAd() (assets to JS) and showNativeAd() (real
   * rendering). The call's `video` / `mediaAspectRatio` go into the request —
   * the SDK fixes them at load time, so they cannot be changed for an ad once
   * it is cached.
   */
  private void loadNativeAdInternal(
    final String adUnitId,
    final String slot,
    final PluginCall call,
    final NativeAdLoadCallback callback
  ) {
    // Drop any previously loaded ad — and the view rendering it, which now
    // points at an ad that is about to be destroyed.
    destroyNativeAdView(slot);
    NativeAd existing = nativeAds.remove(slot);
    if (existing != null) existing.destroy();

    final Object token = new Object();
    nativeLoadTokens.put(slot, token);
    nativeSlotUnits.put(slot, adUnitId);

    final AtomicBoolean resolved = new AtomicBoolean(false);
    AdLoader adLoader = new AdLoader.Builder(getContext(), adUnitId)
      .forNativeAd(new NativeAd.OnNativeAdLoadedListener() {
        @Override
        public void onNativeAdLoaded(NativeAd nativeAd) {
          if (resolved.getAndSet(true)) return;
          if (nativeLoadTokens.get(slot) != token) {
            // A newer load or a destroy took the slot while this one was out.
            nativeAd.destroy();
            callback.onFailed("Native ad load for slot " + slot + " was superseded");
            return;
          }
          nativeAds.put(slot, nativeAd);
          // Set before the caller can show the ad: the paid event fires off the
          // impression, which happens as soon as the view goes on screen.
          nativeAd.setOnPaidEventListener(adValue -> notifyAdPaid("OnNativeAdPaidEvent", adUnitId, slot, adValue));
          attachVideoLifecycle(adUnitId, slot, nativeAd);
          notifyListeners("OnNativeAdLoadedEvent", nativeAdToJson(adUnitId, slot, nativeAd));
          callback.onLoaded(nativeAd);
        }
      })
      // For native ads the SDK reports impressions and clicks through this
      // listener — they are the only truthful signal that the NativeAdView was
      // seen and tapped, so they are forwarded to JS rather than dropped.
      .withAdListener(new AdListener() {
        @Override
        public void onAdFailedToLoad(LoadAdError adError) {
          if (resolved.getAndSet(true)) return;
          if (nativeLoadTokens.get(slot) != token) {
            // Stale: the slot moved on, so its listeners must not hear about it.
            callback.onFailed("Native ad load for slot " + slot + " was superseded");
            return;
          }
          nativeAds.remove(slot);
          JSObject event = nativeEvent(adUnitId, slot);
          event.put("error", adError.getMessage());
          notifyListeners("OnNativeAdFailedToLoadEvent", event);
          callback.onFailed(adError.getMessage());
        }

        @Override
        public void onAdImpression() {
          notifyListeners("OnNativeAdImpressionEvent", nativeEvent(adUnitId, slot));
        }

        @Override
        public void onAdClicked() {
          notifyListeners("OnNativeAdClickedEvent", nativeEvent(adUnitId, slot));
        }
      })
      // Leave setReturnUrlsForImageAssets at its default (false): the SDK then
      // downloads the assets and populates both the Drawable and the URI. The
      // Drawable is what the NativeAdView needs, so turning URLs on would strip
      // the icon out of the rendered ad to benefit only the deprecated JS path.
      .withNativeAdOptions(buildNativeAdOptions(call))
      .build();

    adLoader.loadAd(new AdRequest.Builder().build());
  }

  /**
   * Load a native ad and return its assets to JavaScript.
   *
   * @deprecated for display. These assets are for preview and debugging only —
   * rendering them in the web view records no impression and leaves clicks
   * inert. Use showNativeAd() to display the ad.
   */
  @PluginMethod
  public void loadNativeAd(PluginCall call) {
    ALFTrace.run("ALF.loadNativeAd", () -> loadNativeAdImpl(call));
  }

  private void loadNativeAdImpl(final PluginCall call) {
    requireSdk(call);
    final String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }
    final String slot = nativeSlot(call);

    loadNativeAdInternal(adUnitId, slot, call, new NativeAdLoadCallback() {
      @Override
      public void onLoaded(NativeAd nativeAd) {
        call.resolve(nativeAdToJson(adUnitId, slot, nativeAd));
      }

      @Override
      public void onFailed(String error) {
        call.reject(error);
      }
    });
  }

  @PluginMethod
  public void isNativeAdReady(PluginCall call) {
    String slot = nativeSlot(call);
    if (slot == null) { call.reject("adUnitId or slot is required"); return; }
    // With both given, the slot must hold an ad of THAT unit: a fallback chain
    // asks about one unit while the slot may still hold another.
    String adUnitId = call.getString("adUnitId");
    boolean ready = nativeAds.containsKey(slot)
      && (adUnitId == null || adUnitId.equals(nativeSlotUnits.get(slot)));
    JSObject result = new JSObject();
    result.put("ready", ready);
    call.resolve(result);
  }

  /**
   * Render the native ad in a real NativeAdView laid over the web view.
   *
   * This is the only path that displays a native ad for real: binding the
   * assets and calling setNativeAd() is what makes the SDK record the
   * impression and take over click handling.
   */
  @PluginMethod
  public void showNativeAd(PluginCall call) {
    ALFTrace.run("ALF.showNativeAd", () -> showNativeAdImpl(call));
  }

  private void showNativeAdImpl(final PluginCall call) {
    // Unlike requireSdk(), this actually stops — resolving a call that was
    // already rejected for an uninitialised SDK would be a bridge error.
    if (!isSdkInitialized) {
      call.reject("MobileAds not initialized. Call initialize() first.");
      return;
    }
    final String adUnitId = call.getString("adUnitId");
    if (adUnitId == null) { call.reject("adUnitId is required"); return; }
    final String slot = nativeSlot(call);
    // What the slot holds only counts when it is an ad of the unit asked for —
    // otherwise the load below replaces it.
    final boolean sameUnit = adUnitId.equals(nativeSlotUnits.get(slot));

    // Re-show a view we already built rather than registering the same NativeAd
    // on a fresh NativeAdView, which would record a second impression for one ad.
    final NativeAdView existingView = sameUnit ? nativeAdViews.get(slot) : null;
    if (existingView != null) {
      final JSObject rect = call.getObject("rect");
      final JSObject overlay = call.getObject("overlay");
      getActivity().runOnUiThread(() -> {
        if (rect != null) moveNativeAdView(existingView, rectLayoutParams(rect));
        existingView.setVisibility(View.VISIBLE);
        if (overlay != null) applyNativeAdOverlay(slot, existingView, overlay);
        layoutNativeAdOverlay(slot);
      });
      call.resolve();
      return;
    }

    NativeAd cached = sameUnit ? nativeAds.get(slot) : null;
    if (cached != null) {
      renderNativeAd(call, slot, cached);
      return;
    }

    loadNativeAdInternal(adUnitId, slot, call, new NativeAdLoadCallback() {
      @Override
      public void onLoaded(NativeAd nativeAd) {
        renderNativeAd(call, slot, nativeAd);
      }

      @Override
      public void onFailed(String error) {
        call.reject(error);
      }
    });
  }

  /** Move an ad shown in rect mode. Called from JS on scroll and resize. */
  @PluginMethod
  public void updateNativeAdRect(PluginCall call) {
    ALFTrace.run("ALF.updateNativeAdRect", () -> updateNativeAdRectImpl(call));
  }

  private void updateNativeAdRectImpl(final PluginCall call) {
    final String slot = nativeSlot(call);
    if (slot == null) { call.reject("adUnitId or slot is required"); return; }

    final NativeAdView adView = nativeAdViews.get(slot);
    if (adView == null) { call.reject("Native ad view not found"); return; }

    JSObject rect = call.getObject("rect");
    if (rect == null) { call.reject("rect is required"); return; }

    final FrameLayout.LayoutParams params = rectLayoutParams(rect);
    getActivity().runOnUiThread(ALFTrace.wrap("ALF.updateNativeAdRect.ui", () -> {
      if (moveNativeAdView(adView, params)) layoutNativeAdOverlay(slot);
    }));
    call.resolve();
  }

  /**
   * Put a rect-mode ad at `params`. A pure move (same size, already laid out
   * TOP|START) only shifts the view's translation off its laid-out margins,
   * which needs no layout pass; a size change sets new LayoutParams and drops
   * the translation. Returns false when the ad is already exactly there.
   * UI thread.
   */
  private boolean moveNativeAdView(View adView, FrameLayout.LayoutParams params) {
    ViewGroup.LayoutParams current = adView.getLayoutParams();
    if (current instanceof FrameLayout.LayoutParams) {
      FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) current;
      if (lp.width == params.width && lp.height == params.height && lp.gravity == params.gravity) {
        float dx = params.leftMargin - lp.leftMargin;
        float dy = params.topMargin - lp.topMargin;
        if (adView.getTranslationX() == dx && adView.getTranslationY() == dy) return false;
        adView.setTranslationX(dx);
        adView.setTranslationY(dy);
        return true;
      }
    }
    adView.setTranslationX(0f);
    adView.setTranslationY(0f);
    adView.setLayoutParams(params);
    return true;
  }

  /**
   * Change the controls drawn over a rect-mode native ad — e.g. tick the close
   * button's countdown, then enable it. Adds the overlay if the ad has none.
   */
  @PluginMethod
  public void updateNativeAdOverlay(PluginCall call) {
    final String slot = nativeSlot(call);
    if (slot == null) { call.reject("adUnitId or slot is required"); return; }

    final NativeAdView adView = nativeAdViews.get(slot);
    if (adView == null) { call.reject("Native ad view not found"); return; }

    final JSObject overlay = call.getObject("overlay");
    if (overlay == null) { call.reject("overlay is required"); return; }

    getActivity().runOnUiThread(() -> {
      applyNativeAdOverlay(slot, adView, overlay);
      layoutNativeAdOverlay(slot);
    });
    call.resolve();
  }

  /**
   * Take the overlay off a native ad and give the content back its padding.
   * No-op when the ad has none.
   */
  @PluginMethod
  public void removeNativeAdOverlay(PluginCall call) {
    final String slot = nativeSlot(call);
    if (slot == null) { call.reject("adUnitId or slot is required"); return; }

    final NativeAdView adView = nativeAdViews.get(slot);
    if (adView == null) { call.reject("Native ad view not found"); return; }

    getActivity().runOnUiThread(() -> {
      NativeAdOverlay overlay = nativeAdOverlays.remove(slot);
      if (overlay == null) return;
      removeFromContainer(overlay.root);
      View content = adView.findViewById(R.id.alf_native_root);
      if (content != null) {
        content.setPadding(
          content.getPaddingLeft(), overlay.baseTop, content.getPaddingRight(), overlay.baseBottom);
      }
    });
    call.resolve();
  }

  @PluginMethod
  public void hideNativeAd(PluginCall call) {
    final String slot = nativeSlot(call);
    if (slot == null) { call.reject("adUnitId or slot is required"); return; }

    final NativeAdView adView = nativeAdViews.get(slot);
    if (adView == null) { call.reject("Native ad view not found"); return; }

    getActivity().runOnUiThread(() -> {
      adView.setVisibility(View.GONE);
      NativeAdOverlay overlay = nativeAdOverlays.get(slot);
      if (overlay != null) overlay.root.setVisibility(View.GONE);
    });
    call.resolve();
  }

  @PluginMethod
  public void destroyNativeAd(PluginCall call) {
    String slot = nativeSlot(call);
    if (slot == null) { call.reject("adUnitId or slot is required"); return; }

    // Also cancels a load still in flight for the slot: it finds its token gone.
    nativeLoadTokens.remove(slot);
    nativeSlotUnits.remove(slot);
    destroyNativeAdView(slot);
    NativeAd nativeAd = nativeAds.remove(slot);
    if (nativeAd != null) {
      nativeAd.destroy();
    }
    call.resolve();
  }

  // ── Native video ────────────────────────────────
  // While the SDK's own controls are in charge (custom controls not granted),
  // the player may ignore these — the app is expected to leave it alone then.

  @PluginMethod
  public void playNativeAdVideo(PluginCall call) {
    final VideoController controller = videoControllerFor(call);
    if (controller == null) return;
    getActivity().runOnUiThread(controller::play);
    call.resolve();
  }

  @PluginMethod
  public void pauseNativeAdVideo(PluginCall call) {
    final VideoController controller = videoControllerFor(call);
    if (controller == null) return;
    getActivity().runOnUiThread(controller::pause);
    call.resolve();
  }

  @PluginMethod
  public void muteNativeAdVideo(PluginCall call) {
    final Boolean muted = call.getBoolean("muted");
    if (muted == null) { call.reject("muted is required"); return; }
    final VideoController controller = videoControllerFor(call);
    if (controller == null) return;
    getActivity().runOnUiThread(() -> controller.mute(muted));
    call.resolve();
  }

  /** The video controller of the slot's ad, or null after rejecting the call. */
  private VideoController videoControllerFor(PluginCall call) {
    String slot = nativeSlot(call);
    if (slot == null) { call.reject("adUnitId or slot is required"); return null; }

    NativeAd nativeAd = nativeAds.get(slot);
    if (nativeAd == null) { call.reject("Native ad not loaded"); return null; }

    MediaContent media = nativeAd.getMediaContent();
    if (media == null || !media.hasVideoContent()) {
      call.reject("Native ad has no video content");
      return null;
    }
    return media.getVideoController();
  }

  /**
   * @deprecated Always rejects. The SDK registers clicks itself through the
   * NativeAdView built by showNativeAd(); there is no supported way to report
   * a click by hand, and pretending otherwise hid the fact that ads rendered
   * in the web view were never clickable at all.
   */
  @PluginMethod
  public void reportNativeAdClick(PluginCall call) {
    call.reject(
      "reportNativeAdClick is not supported. AdMob registers clicks through the "
        + "NativeAdView created by showNativeAd() — call that to display the ad."
    );
  }

  // ── Native ad events ───────────────────────────
  /** Map a loaded ad's assets to the shape JS expects (NativeAdData). */
  private JSObject nativeAdToJson(String adUnitId, String slot, NativeAd nativeAd) {
    JSObject result = nativeEvent(adUnitId, slot);
    result.put("headline", nativeAd.getHeadline() != null ? nativeAd.getHeadline() : "");
    result.put("body", nativeAd.getBody() != null ? nativeAd.getBody() : "");
    result.put("callToAction", nativeAd.getCallToAction() != null ? nativeAd.getCallToAction() : "");

    // Icon
    if (nativeAd.getIcon() != null && nativeAd.getIcon().getUri() != null) {
      result.put("iconUrl", nativeAd.getIcon().getUri().toString());
    } else {
      result.put("iconUrl", "");
    }

    // Images (first image if available)
    if (nativeAd.getImages() != null && !nativeAd.getImages().isEmpty()
      && nativeAd.getImages().get(0).getUri() != null) {
      result.put("imageUrl", nativeAd.getImages().get(0).getUri().toString());
    } else {
      result.put("imageUrl", "");
    }

    // Media content is a Drawable or a video stream owned by the SDK — there
    // is no URL to hand out, so describe it instead.
    MediaContent media = nativeAd.getMediaContent();
    boolean hasVideo = media != null && media.hasVideoContent();
    result.put("hasVideoContent", hasVideo);
    result.put("mediaAspectRatio", media != null ? (double) media.getAspectRatio() : 0d);
    result.put("videoDuration", hasVideo ? (double) media.getDuration() : 0d);
    result.put("videoCustomControlsEnabled",
      hasVideo && media.getVideoController().isCustomControlsEnabled());

    result.put("price", nativeAd.getPrice() != null ? nativeAd.getPrice() : "");
    result.put("store", nativeAd.getStore() != null ? nativeAd.getStore() : "");
    result.put("starRating", nativeAd.getStarRating() != null ? nativeAd.getStarRating().doubleValue() : 0.0);
    result.put("advertiser", nativeAd.getAdvertiser() != null ? nativeAd.getAdvertiser() : "");
    return result;
  }

  /**
   * Request options from the caller. Video starts muted unless told otherwise —
   * the SDK default too, and what AdMob recommends for ads that autoplay in feed.
   */
  private NativeAdOptions buildNativeAdOptions(PluginCall call) {
    JSObject video = call.getObject("video");
    boolean startMuted = true;
    boolean customControls = false;
    boolean clickToExpand = false;
    if (video != null) {
      startMuted = video.optBoolean("startMuted", true);
      customControls = video.optBoolean("customControlsRequested", false);
      clickToExpand = video.optBoolean("clickToExpandRequested", false);
    }

    VideoOptions videoOptions = new VideoOptions.Builder()
      .setStartMuted(startMuted)
      .setCustomControlsRequested(customControls)
      .setClickToExpandRequested(clickToExpand)
      .build();

    return new NativeAdOptions.Builder()
      .setVideoOptions(videoOptions)
      .setMediaAspectRatio(mediaAspectRatio(call.getString("mediaAspectRatio")))
      .build();
  }

  private int mediaAspectRatio(String value) {
    if (value == null) return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_ANY;
    switch (value) {
      case "landscape":
        return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_LANDSCAPE;
      case "portrait":
        return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_PORTRAIT;
      case "square":
        return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_SQUARE;
      case "any":
      default:
        return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_ANY;
    }
  }

  /**
   * Forward the video player's state to JS. The app needs it to duck its own
   * audio when the user unmutes the ad, and to tell a video that ran from one
   * that never started.
   */
  private void attachVideoLifecycle(final String adUnitId, final String slot, NativeAd nativeAd) {
    MediaContent media = nativeAd.getMediaContent();
    if (media == null || !media.hasVideoContent()) return;

    media.getVideoController().setVideoLifecycleCallbacks(
      new VideoController.VideoLifecycleCallbacks() {
        @Override
        public void onVideoStart() {
          notifyNativeAdVideo(adUnitId, slot, "start");
        }

        @Override
        public void onVideoPlay() {
          notifyNativeAdVideo(adUnitId, slot, "play");
        }

        @Override
        public void onVideoPause() {
          notifyNativeAdVideo(adUnitId, slot, "pause");
        }

        @Override
        public void onVideoEnd() {
          notifyNativeAdVideo(adUnitId, slot, "end");
        }

        @Override
        public void onVideoMute(boolean isMuted) {
          notifyNativeAdVideo(adUnitId, slot, isMuted ? "mute" : "unmute");
        }
      }
    );
  }

  private void notifyNativeAdVideo(String adUnitId, String slot, String state) {
    JSObject event = nativeEvent(adUnitId, slot);
    event.put("state", state);
    notifyListeners("OnNativeAdVideoEvent", event);
  }

  /** Payload of every native ad event: the ad unit, and the slot it lives in. */
  private JSObject nativeEvent(String adUnitId, String slot) {
    JSObject event = new JSObject();
    event.put("adUnitId", adUnitId);
    event.put("slot", slot);
    return event;
  }

  private void notifyAdUnitEvent(String eventName, String adUnitId) {
    JSObject event = new JSObject();
    event.put("adUnitId", adUnitId);
    notifyListeners(eventName, event);
  }

  /**
   * Forward ad revenue to JS so the app can report it to its attribution SDK.
   * Values arrive in micros; JS gets whole currency units so both platforms agree.
   */
  private void notifyAdPaid(String eventName, String adUnitId, AdValue adValue) {
    notifyAdPaid(eventName, adUnitId, null, adValue);
  }

  private void notifyAdPaid(String eventName, String adUnitId, String slot, AdValue adValue) {
    JSObject event = new JSObject();
    event.put("adUnitId", adUnitId);
    if (slot != null) event.put("slot", slot);
    event.put("value", adValue.getValueMicros() / 1_000_000d);
    event.put("currencyCode", adValue.getCurrencyCode());
    event.put("precision", precisionName(adValue.getPrecisionType()));
    notifyListeners(eventName, event);
  }

  private String precisionName(int precisionType) {
    switch (precisionType) {
      case AdValue.PrecisionType.ESTIMATED:
        return "estimated";
      case AdValue.PrecisionType.PUBLISHER_PROVIDED:
        return "publisherProvided";
      case AdValue.PrecisionType.PRECISE:
        return "precise";
      case AdValue.PrecisionType.UNKNOWN:
      default:
        return "unknown";
    }
  }

  // ── Native ad rendering ─────────────────────────
  /** Inflate the template, bind every asset, then hand the ad to the SDK. */
  private void renderNativeAd(final PluginCall call, final String slot, final NativeAd nativeAd) {
    final String template = call.getString("template", "medium");
    final JSObject style = call.getObject("style");
    final JSObject rect = call.getObject("rect");
    final String position = call.getString("position", "BOTTOM_CENTER");
    final Integer height = call.getInt("height");
    final JSObject overlay = call.getObject("overlay");

    getActivity().runOnUiThread(ALFTrace.wrap("ALF.renderNativeAd", () -> {
      try {
        destroyNativeAdView(slot);

        int layoutRes = "small".equals(template)
          ? R.layout.alf_native_ad_small
          : "mrec".equals(template)
            ? R.layout.alf_native_ad_mrec
            : R.layout.alf_native_ad_medium;
        NativeAdView adView =
          (NativeAdView) LayoutInflater.from(getContext()).inflate(layoutRes, null);

        bindNativeAssets(adView, nativeAd);
        applyNativeAdStyle(adView, style);

        // Registers the impression and wires up the clickable asset views.
        adView.setNativeAd(nativeAd);

        FrameLayout.LayoutParams params;
        boolean bottom = false;
        if (rect != null) {
          params = rectLayoutParams(rect);
        } else {
          bottom = "BOTTOM_CENTER".equals(position);
          int heightPx = height != null && height > 0
            ? Math.round(height * density())
            : FrameLayout.LayoutParams.WRAP_CONTENT;
          params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, heightPx);
          params.gravity = (bottom ? Gravity.BOTTOM : Gravity.TOP) | Gravity.CENTER_HORIZONTAL;
        }

        getAdContainer().addView(adView, params);
        if (bottom) applyBottomInset(adView);

        nativeAdViews.put(slot, adView);
        if (overlay != null && rect != null) {
          applyNativeAdOverlay(slot, adView, overlay);
          layoutNativeAdOverlay(slot);
        }
        call.resolve();
      } catch (Exception e) {
        Log.e(TAG, "showNativeAd failed", e);
        call.reject("Failed to render native ad: " + e.getMessage());
      }
    }));
  }

  /**
   * Point each asset view at its NativeAd field and register it on the ad view.
   * Both templates share these ids; assets a template omits are simply skipped.
   */
  private void bindNativeAssets(NativeAdView adView, NativeAd nativeAd) {
    TextView headline = adView.findViewById(R.id.alf_native_headline);
    if (headline != null) {
      headline.setText(nativeAd.getHeadline());
      adView.setHeadlineView(headline);
    }

    TextView body = adView.findViewById(R.id.alf_native_body);
    if (body != null) {
      if (nativeAd.getBody() != null) {
        body.setText(nativeAd.getBody());
        body.setVisibility(View.VISIBLE);
        adView.setBodyView(body);
      } else {
        body.setVisibility(View.GONE);
      }
    }

    Button cta = adView.findViewById(R.id.alf_native_cta);
    if (cta != null) {
      if (nativeAd.getCallToAction() != null) {
        cta.setText(nativeAd.getCallToAction());
        cta.setVisibility(View.VISIBLE);
        adView.setCallToActionView(cta);
      } else {
        cta.setVisibility(View.GONE);
      }
    }

    ImageView icon = adView.findViewById(R.id.alf_native_icon);
    if (icon != null) {
      Drawable iconDrawable = nativeAd.getIcon() != null ? nativeAd.getIcon().getDrawable() : null;
      if (iconDrawable != null) {
        icon.setImageDrawable(iconDrawable);
        icon.setVisibility(View.VISIBLE);
        adView.setIconView(icon);
      } else {
        icon.setVisibility(View.GONE);
      }
    }

    TextView advertiser = adView.findViewById(R.id.alf_native_advertiser);
    if (advertiser != null) {
      if (nativeAd.getAdvertiser() != null) {
        advertiser.setText(nativeAd.getAdvertiser());
        advertiser.setVisibility(View.VISIBLE);
        adView.setAdvertiserView(advertiser);
      } else {
        advertiser.setVisibility(View.GONE);
      }
    }

    RatingBar rating = adView.findViewById(R.id.alf_native_rating);
    if (rating != null) {
      if (nativeAd.getStarRating() != null) {
        rating.setRating(nativeAd.getStarRating().floatValue());
        rating.setVisibility(View.VISIBLE);
        adView.setStarRatingView(rating);
      } else {
        rating.setVisibility(View.GONE);
      }
    }

    MediaView media = adView.findViewById(R.id.alf_native_media);
    if (media != null) {
      if (nativeAd.getMediaContent() != null) {
        media.setMediaContent(nativeAd.getMediaContent());
        media.setVisibility(View.VISIBLE);
        adView.setMediaView(media);
      } else {
        media.setVisibility(View.GONE);
      }
    }
  }

  /** Apply the caller's colors so the ad can match the app's theme. */
  private void applyNativeAdStyle(NativeAdView adView, JSObject style) {
    int background = parseColor(style, "background", Color.WHITE);
    int textColor = parseColor(style, "textColor", Color.BLACK);
    int secondary = parseColor(style, "secondaryTextColor", Color.DKGRAY);
    int ctaBackground = parseColor(style, "ctaBackground", Color.parseColor("#1A73E8"));
    int ctaTextColor = parseColor(style, "ctaTextColor", Color.WHITE);
    int cornerRadius = style != null && style.getInteger("cornerRadius") != null
      ? style.getInteger("cornerRadius") : 0;

    View root = adView.findViewById(R.id.alf_native_root);
    if (root != null) {
      GradientDrawable bg = new GradientDrawable();
      bg.setColor(background);
      bg.setCornerRadius(cornerRadius * density());
      root.setBackground(bg);
    }

    TextView headline = adView.findViewById(R.id.alf_native_headline);
    if (headline != null) headline.setTextColor(textColor);

    TextView body = adView.findViewById(R.id.alf_native_body);
    if (body != null) body.setTextColor(secondary);

    TextView advertiser = adView.findViewById(R.id.alf_native_advertiser);
    if (advertiser != null) advertiser.setTextColor(secondary);

    TextView badge = adView.findViewById(R.id.alf_native_ad_badge);
    if (badge != null) {
      badge.setTextColor(background);
      GradientDrawable badgeBg = new GradientDrawable();
      badgeBg.setColor(ctaBackground);
      badgeBg.setCornerRadius(2 * density());
      badge.setBackground(badgeBg);
    }

    Button cta = adView.findViewById(R.id.alf_native_cta);
    if (cta != null) {
      cta.setTextColor(ctaTextColor);
      GradientDrawable ctaBg = new GradientDrawable();
      ctaBg.setColor(ctaBackground);
      ctaBg.setCornerRadius((cornerRadius > 0 ? cornerRadius : 6) * density());
      cta.setBackground(ctaBg);
    }
  }

  private int parseColor(JSObject style, String key, int fallback) {
    if (style == null) return fallback;
    String value = style.getString(key);
    if (value == null || value.isEmpty()) return fallback;
    try {
      return Color.parseColor(value);
    } catch (IllegalArgumentException e) {
      Log.w(TAG, "Invalid color for " + key + ": " + value);
      return fallback;
    }
  }

  /** Convert a CSS-pixel rect from the web view into container layout params. */
  private FrameLayout.LayoutParams rectLayoutParams(JSObject rect) {
    float d = density();
    int width = Math.round(numberOrZero(rect, "width") * d);
    int height = Math.round(numberOrZero(rect, "height") * d);
    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(width, height);
    params.gravity = Gravity.TOP | Gravity.START;
    params.leftMargin = Math.round(numberOrZero(rect, "x") * d);
    params.topMargin = Math.round(numberOrZero(rect, "y") * d);
    return params;
  }

  private float numberOrZero(JSObject obj, String key) {
    // optDouble rather than getDouble: a missing key must default, not throw.
    return (float) obj.optDouble(key, 0d);
  }

  /** Detach and release the rendered view for a slot, if there is one. */
  private void destroyNativeAdView(String slot) {
    final NativeAdView adView = nativeAdViews.remove(slot);
    if (adView == null) return;
    getActivity().runOnUiThread(() -> {
      NativeAdOverlay overlay = nativeAdOverlays.remove(slot);
      if (overlay != null) removeFromContainer(overlay.root);
      removeFromContainer(adView);
      adView.destroy();
    });
  }

  // ── Native ad overlay ───────────────────────────
  // A label and a close button drawn by the plugin ABOVE a rect-mode native ad,
  // so an app can run the ad full screen as an interstitial: anything the web
  // view draws sits under the ad view and could never be tapped.
  //
  // The overlay is a sibling of the NativeAdView, not a child — it is not part
  // of the ad. Its empty area is not clickable, so touches fall through to the
  // ad; only the close button takes them, and it takes them even while
  // disabled, so a tap on a locked button is not turned into an ad click.
  //
  // Nothing of the ad may sit under the controls or the system bars (AdMob
  // policy: the "Ad" badge, assets and CTA must stay visible). The template's
  // content is padded down below the controls and up off the navigation bar;
  // only the ad's background reaches the screen edges.

  private static final int OVERLAY_DEFAULT_SIZE_DP = 40;
  private static final int OVERLAY_MARGIN_DP = 10;

  private static final class NativeAdOverlay {
    final LinearLayout root;
    final TextView label;
    final TextView close;
    final GradientDrawable closeBg;
    // Template padding before the overlay pushed the content in.
    final int baseTop;
    final int baseBottom;
    int sizePx;

    NativeAdOverlay(LinearLayout root, TextView label, TextView close, GradientDrawable closeBg,
                    int baseTop, int baseBottom) {
      this.root = root;
      this.label = label;
      this.close = close;
      this.closeBg = closeBg;
      this.baseTop = baseTop;
      this.baseBottom = baseBottom;
    }
  }

  /** Create the slot's overlay if needed and apply the options to it. UI thread. */
  private void applyNativeAdOverlay(final String slot, NativeAdView adView, JSObject options) {
    NativeAdOverlay overlay = nativeAdOverlays.get(slot);
    if (overlay == null) {
      overlay = createNativeAdOverlay(slot, adView);
      nativeAdOverlays.put(slot, overlay);
    }

    String label = options.getString("label");
    overlay.label.setText(label != null ? label : "");
    overlay.label.setVisibility(label != null && !label.isEmpty() ? View.VISIBLE : View.INVISIBLE);

    String closeText = options.getString("closeText");
    overlay.close.setText(closeText != null && !closeText.isEmpty() ? closeText : "✕");

    boolean enabled = options.optBoolean("closeEnabled", true);
    overlay.close.setEnabled(enabled);
    overlay.close.setTextColor(enabled ? Color.WHITE : Color.argb(180, 255, 255, 255));
    overlay.closeBg.setStroke(
      Math.round(1.5f * density()),
      enabled ? Color.argb(140, 255, 255, 255) : Color.argb(64, 255, 255, 255));

    Integer size = options.getInteger("size");
    int sizePx = Math.round((size != null && size > 0 ? size : OVERLAY_DEFAULT_SIZE_DP) * density());
    if (sizePx != overlay.sizePx) {
      overlay.sizePx = sizePx;
      LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(sizePx, sizePx);
      overlay.close.setLayoutParams(lp);
      overlay.close.setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx * 0.42f);
      overlay.root.getLayoutParams().height = sizePx;
    }

    overlay.root.setVisibility(adView.getVisibility());
  }

  private NativeAdOverlay createNativeAdOverlay(final String slot, NativeAdView adView) {
    float d = density();

    LinearLayout root = new LinearLayout(getContext());
    root.setOrientation(LinearLayout.HORIZONTAL);
    root.setGravity(Gravity.CENTER_VERTICAL);

    TextView label = new TextView(getContext());
    label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
    label.setTypeface(Typeface.DEFAULT_BOLD);
    label.setLetterSpacing(0.08f);
    label.setTextColor(Color.parseColor("#0B0F14"));
    label.setPadding(Math.round(8 * d), Math.round(3 * d), Math.round(8 * d), Math.round(3 * d));
    GradientDrawable labelBg = new GradientDrawable();
    labelBg.setColor(Color.parseColor("#C9D3DE"));
    labelBg.setCornerRadius(4 * d);
    label.setBackground(labelBg);
    root.addView(label, new LinearLayout.LayoutParams(
      LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

    View spacer = new View(getContext());
    root.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

    TextView close = new TextView(getContext());
    close.setGravity(Gravity.CENTER);
    close.setTypeface(Typeface.DEFAULT_BOLD);
    close.setIncludeFontPadding(false);
    GradientDrawable closeBg = new GradientDrawable();
    closeBg.setShape(GradientDrawable.OVAL);
    closeBg.setColor(Color.argb(150, 0, 0, 0));
    close.setBackground(closeBg);
    close.setClickable(true);
    close.setOnClickListener((v) -> {
      if (!v.isEnabled()) return;
      String unit = nativeSlotUnits.get(slot);
      notifyListeners("OnNativeAdOverlayCloseEvent", nativeEvent(unit != null ? unit : slot, slot));
    });
    root.addView(close, new LinearLayout.LayoutParams(0, 0));

    FrameLayout.LayoutParams rootParams = new FrameLayout.LayoutParams(0, 0);
    rootParams.gravity = Gravity.TOP | Gravity.START;
    // Added after the ad view, so it draws — and takes touches — above it.
    getAdContainer().addView(root, rootParams);

    View content = adView.findViewById(R.id.alf_native_root);
    int baseTop = content != null ? content.getPaddingTop() : 0;
    int baseBottom = content != null ? content.getPaddingBottom() : 0;
    return new NativeAdOverlay(root, label, close, closeBg, baseTop, baseBottom);
  }

  /**
   * Put the slot's overlay at the top of its ad, below any system bar the ad
   * reaches under, and pad the ad's content clear of both. UI thread; call
   * whenever the ad's rect changes.
   */
  private void layoutNativeAdOverlay(String slot) {
    NativeAdOverlay overlay = nativeAdOverlays.get(slot);
    NativeAdView adView = nativeAdViews.get(slot);
    if (overlay == null || adView == null) return;
    if (!(adView.getLayoutParams() instanceof FrameLayout.LayoutParams)) return;

    FrameLayout.LayoutParams ad = (FrameLayout.LayoutParams) adView.getLayoutParams();
    float d = density();
    int margin = Math.round(OVERLAY_MARGIN_DP * d);

    // System bars and cutout, in the container's coordinates.
    FrameLayout container = getAdContainer();
    Insets bars = Insets.NONE;
    WindowInsetsCompat windowInsets = ViewCompat.getRootWindowInsets(container);
    if (windowInsets != null) {
      bars = windowInsets.getInsets(
        WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
    }
    int[] origin = new int[2];
    container.getLocationInWindow(origin);
    View window = container.getRootView();
    int barsTop = Math.max(0, bars.top - origin[1]);
    int barsLeft = Math.max(0, bars.left - origin[0]);
    int navTop = window.getHeight() - bars.bottom - origin[1];
    int barsRight = window.getWidth() - bars.right - origin[0];

    // Where the ad is drawn: its margins plus any translation a pure move
    // (moveNativeAdView) left on it.
    int adLeft = ad.leftMargin + Math.round(adView.getTranslationX());
    int adTop = ad.topMargin + Math.round(adView.getTranslationY());

    // How far each system bar reaches into the ad.
    int adRight = adLeft + ad.width;
    int adBottom = adTop + ad.height;
    int coverTop = Math.max(0, barsTop - adTop);
    int coverLeft = Math.max(0, barsLeft - adLeft);
    // Window not measured yet (0×0): no bar can be told apart on those sides.
    int coverRight = window.getWidth() > 0 ? Math.max(0, adRight - barsRight) : 0;
    int coverBottom = window.getHeight() > 0 ? Math.max(0, adBottom - navTop) : 0;

    FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) overlay.root.getLayoutParams();
    lp.width = Math.max(0, ad.width - coverLeft - coverRight - 2 * margin);
    lp.height = overlay.sizePx;
    lp.leftMargin = adLeft + coverLeft + margin;
    lp.topMargin = adTop + coverTop + margin;
    overlay.root.setLayoutParams(lp);
    // Follows the ad: showNativeAd() re-showing a hidden ad brings it back too.
    overlay.root.setVisibility(adView.getVisibility());

    View content = adView.findViewById(R.id.alf_native_root);
    if (content != null) {
      content.setPadding(
        content.getPaddingLeft(),
        coverTop + margin + overlay.sizePx + overlay.baseTop,
        content.getPaddingRight(),
        coverBottom + overlay.baseBottom);
    }
  }

  // ── Helpers ─────────────────────────────────────
  // Rejects the call when the SDK is not up. Returns whether the caller may go
  // on — callers that ignore it run on and settle the call a second time.
  private boolean requireSdk(PluginCall call) {
    if (!isSdkInitialized) {
      call.reject("MobileAds not initialized. Call initialize() first.");
      return false;
    }
    return true;
  }

  // ── Banner helpers ──────────────────────────────
  /**
   * Resolve the AdSize for createBanner:
   * - custom `{ width, height }` (dp) when the size option is an object
   * - named fixed sizes (BANNER, LARGE_BANNER, ...)
   * - anchored adaptive banner (default) filling the screen width
   */
  private AdSize parseAdSize(PluginCall call) {
    JSObject size = call.getObject("size");
    if (size != null) {
      Integer width = size.getInteger("width");
      Integer height = size.getInteger("height");
      if (width != null && height != null && width > 0 && height > 0) {
        return new AdSize(width, height);
      }
    }

    String sizeName = call.getString("size", "ADAPTIVE");
    switch (sizeName) {
      case "BANNER":
        return AdSize.BANNER;
      case "LARGE_BANNER":
        return AdSize.LARGE_BANNER;
      case "MEDIUM_RECTANGLE":
        return AdSize.MEDIUM_RECTANGLE;
      case "FULL_BANNER":
        return AdSize.FULL_BANNER;
      case "LEADERBOARD":
        return AdSize.LEADERBOARD;
      case "ADAPTIVE":
      default:
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(getContext(), screenWidthDp());
    }
  }

  /** Build an AdRequest, adding the collapsible placement extras when requested. */
  private AdRequest buildBannerRequest(String collapsible) {
    AdRequest.Builder builder = new AdRequest.Builder();
    if (collapsible != null && (collapsible.equals("top") || collapsible.equals("bottom"))) {
      Bundle extras = new Bundle();
      extras.putString("collapsible", collapsible);
      builder.addNetworkExtrasBundle(AdMobAdapter.class, extras);
    }
    return builder.build();
  }

  private FrameLayout.LayoutParams bannerLayoutParams(AdView adView, boolean bottom) {
    AdSize size = adView.getAdSize();
    int widthPx;
    int heightPx;
    if (size != null && size.isFullWidth()) {
      // Anchored adaptive banner — spans the screen width, height matches the ad.
      widthPx = FrameLayout.LayoutParams.MATCH_PARENT;
      heightPx = size.getHeightInPixels(getContext());
    } else {
      widthPx = size != null ? size.getWidthInPixels(getContext()) : (int) (320 * density());
      heightPx = size != null ? size.getHeightInPixels(getContext()) : (int) (50 * density());
    }
    FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(widthPx, heightPx);
    params.gravity = bottom ? Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL : Gravity.TOP | Gravity.CENTER_HORIZONTAL;
    return params;
  }

  private float density() {
    return getContext().getResources().getDisplayMetrics().density;
  }

  private int screenWidthDp() {
    DisplayMetrics metrics = getContext().getResources().getDisplayMetrics();
    return Math.round(metrics.widthPixels / metrics.density);
  }

  private int toDp(int px) {
    return Math.round(px / density());
  }

  // Native ad views must be added to the window content FrameLayout, NOT the WebView.
  // The Capacitor WebView is AbsoluteLayout-derived and ignores FrameLayout gravity,
  // which made banners always render at the top regardless of position.
  private FrameLayout getAdContainer() {
    return (FrameLayout) getActivity().findViewById(android.R.id.content);
  }

  private void removeFromContainer(View view) {
    ViewGroup parent = (ViewGroup) view.getParent();
    if (parent != null) parent.removeView(view);
  }

  // ── Lifecycle ───────────────────────────────────
  // Pause/resume every shown banner with the activity, as the AdMob docs ask.
  // Main thread. A banner the app hid stays paused across a resume.
  @Override
  public void handleOnPause() {
    activityPaused = true;
    for (AdView banner : banners.values()) {
      // Still on its first load: onAdLoaded pauses it (activityPaused).
      if (bannersLoaded.contains(banner)) pauseBanner(banner);
    }
    super.handleOnPause();
  }

  @Override
  public void handleOnResume() {
    activityPaused = false;
    for (AdView banner : banners.values()) {
      if (banner.getVisibility() == View.VISIBLE) resumeBanner(banner);
    }
    super.handleOnResume();
  }

  /**
   * Release every ad the plugin still holds when the activity goes away.
   *
   * JS normally tears these down through ALF.Ads.destroy(), but the web view
   * dies with the activity, so on a real activity destroy — back out of the app,
   * a configuration change the app does not handle, or the system reclaiming the
   * task — that JS never runs. NativeAd and AdView both require an explicit
   * destroy(), and an ad view left attached to the window outlives its activity.
   *
   * Runs on the main thread (it is an activity lifecycle callback), so the views
   * are touched directly rather than posted — a post could land after the
   * activity is gone.
   */
  @Override
  public void handleOnDestroy() {
    for (NativeAdOverlay overlay : nativeAdOverlays.values()) {
      removeFromContainer(overlay.root);
    }
    nativeAdOverlays.clear();

    for (NativeAdView adView : nativeAdViews.values()) {
      removeFromContainer(adView);
      adView.destroy();
    }
    nativeAdViews.clear();

    for (NativeAd nativeAd : nativeAds.values()) {
      nativeAd.destroy();
    }
    nativeAds.clear();
    // Loads still in flight find their token gone and destroy what they get.
    nativeLoadTokens.clear();
    nativeSlotUnits.clear();

    for (AdView banner : banners.values()) {
      removeFromContainer(banner);
      banner.destroy();
    }
    banners.clear();
    bannersLoaded.clear();
    bannersPaused.clear();

    // Full-screen formats have no destroy() — dropping the references is all
    // the SDK asks for, and it keeps a stale ad from being shown after restart.
    interstitials.clear();
    rewardedAds.clear();
    openAppAds.clear();
    rewardedGranted.clear();

    super.handleOnDestroy();
  }

  // Keeps bottom-anchored ads above the navigation bar on edge-to-edge Android 15+.
  private void applyBottomInset(final View view) {
    view.setOnApplyWindowInsetsListener((v, insets) -> {
      FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
      if (lp != null) {
        lp.bottomMargin = insets.getSystemWindowInsetBottom();
        v.setLayoutParams(lp);
      }
      return insets;
    });
    view.requestApplyInsets();
  }
}
