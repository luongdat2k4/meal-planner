# `AdController` — Quảng cáo (AppLovin MAX + AdMob)

## Vai trò

Quản lý toàn bộ logic quảng cáo với **hai provider song song**: **AppLovin MAX** (plugin `ALFAppLovinMAX`) và **AdMob** (plugin `ALFAdMob`). Giao tiếp với native qua Capacitor plugin bridge.

| Chức năng | AppLovin MAX | AdMob |
|---|---|---|
| Init | `init()` | `initAdMob()` |
| Banner | Fallback khi AdMob fail | **Ưu tiên** (`LoadBannerAd` / `ShowBannerAd`) |
| MREC | ✅ | — |
| Interstitial | ✅ | — (native đã có, controller chưa expose) |
| Rewarded | ✅ | — (native đã có, controller chưa expose) |
| App Open | ✅ | ✅ |
| Native Ad | — | ✅ |

> Trên **web**: mọi method đều no-op (web implementation trả warning). `init()`/`initAdMob()` bỏ qua trên web.

## Config keys

```
keys.applovin.{android|ios}.{sdkKey, banner, mrec, interstitial, rewarded, appOpen}
keys.admob.{android|ios}.{appId, banner, interstitial, rewarded, openApp, native}
settings.testAds → mọi ad là test ad (mặc định = settings.dev). Chỉ đọc lúc initSDK.
```

> **Test ad units (Google)**: banner / bannerFixed / collapsibleBanner / interstitial / rewarded / openApp / native — toàn bộ là `ca-app-pub-3940256099942544/...`. Từ 1.9.0, khi `testAds` bật, áp dụng cho **mọi** đường AdMob, kể cả `getAdMobBannerId()`.

## Test ads (`settings.testAds`, 1.9.0)

`isTestAds()` = `settings.testAds ?? settings.dev`. Khi bật:

| Nguồn | Cách ra test ad |
|---|---|
| AdMob (banner, native, interstitial, rewarded, open app) | Unit test của Google, đè cả `adUnitId` do app truyền |
| AppLovin MAX — **A** | `initialize({ testMode: true })`: Android đọc GAID và đăng ký máy là MAX test device (`setTestDeviceAdvertisingIds`) trước init. Trả `testDevice: true` |
| AppLovin MAX — **B** (khi `testDevice` false: iOS, Ad ID tắt/zero) | `useAdMobForMax()`: interstitial / rewarded / app open chạy unit test AdMob; MREC = banner AdMob `MEDIUM_RECTANGLE`; banner fallback bỏ qua bước AppLovin |
| Doanh thu | Android MAX không log `ad_impression` lên Firebase; event native `paid` có `isTest: true` |

- `Ads.IsTestMode()` cho app hiện badge. `initSDK` luôn `logger.warn` khi test ads bật (cả production).
- Nhánh B dùng 2 event AdMob mới: `OnRewardedAdDismissedEvent`, `OnOpenAppAdDismissedEvent`.
- iOS chưa có nhánh A: MAX iOS luôn đi nhánh B khi test.

## Luồng Init

```mermaid
flowchart TD
    subgraph AppLovin["init()"]
        A1{"Config.isReady()?"} -->|No| A2["Return"]
        A1 -->|Yes| A3{"platform === 'web'?"} -->|Yes| A4["Return<br/>(ads disabled)"]
        A3 -->|No| A5["getSdkKeyFromConfig()<br/>keys.applovin.{platform}.sdkKey"]
        A5 --> A6{"sdkKey empty?"} -->|Yes| A7["Throw: cannot initialize AppLovin"]
        A6 -->|No| A8["ALFAppLovinMAX.initialize({sdkKey})"]
        A8 --> A9["this.initialized = true"]
    end

    subgraph AdMob["initAdMob()"]
        B1{"Config.isReady()?"} -->|No| B2["Return"]
        B1 -->|Yes| B3{"platform === 'web'?"} -->|Yes| B4["Return"]
        B3 -->|No| B5["getAdMobAppId()<br/>keys.admob.{platform}.appId"]
        B5 --> B6{"appId empty?"} -->|Yes| B7["Throw: cannot initialize AdMob"]
        B6 -->|No| B8["ALFAdMob.initialize({appId})"]
        B8 --> B9["this.admobInitialized = true"]
    end
```

## Luồng Banner

### LoadBannerAd — Preload (tạo banner, giữ ẩn)

```mermaid
flowchart TD
    A["LoadBannerAd(options)"] --> A1{"web?"} -->|Yes| A2["Return"]
    A1 -->|No| B["destroyActiveBanner()<br/>bannerOptions = options<br/>admobBannerAttempted = false"]
    B --> C["getAdMobBannerId(options)<br/>(unit config; testAds → unit test)"]
    C --> C1{"empty?"} -->|Yes| C2["Return"]
    C1 -->|No| D["admobBannerAttempted = true<br/>ALFAdMob.createBanner({adUnitId, position, size, collapsible})"]
    D --> E["ALFAdMob.hideBanner()<br/>(giữ ẩn đến khi Show)"]
    E --> F["activeBannerAdUnitId = id<br/>bannerProvider = 'admob'"]
    D -. "fail" .-> G["Reset activeBannerAdUnitId / bannerProvider<br/>(show sẽ thử lại)"]
```

### ShowBannerAd — Chuỗi fallback

```mermaid
flowchart TD
    S["ShowBannerAd()"] --> S1{"web?"} -->|Yes| S2["Return"]
    S1 -->|No| A{"activeBannerAdUnitId<br/>(AdMob đã preload)?"}
    A -->|Yes| B["ALFAdMob.showBanner() → Return"]
    A -->|No| C{"admobBannerAttempted?"}
    C -->|No| D["ALFAdMob.createBanner + showBanner"]
    D --> D1{"ok?"} -->|Yes| D2["activeBannerAdUnitId = id<br/>bannerProvider='admob' → Return"]
    D1 -->|No| E
    C -->|Yes| E["Fallback AppLovin:<br/>getAdUnitId('banner')"]
    E --> E1{"empty?"} -->|No| F["destroyActiveBanner()<br/>ALFAppLovinMAX.createBanner + showBanner"]
    F --> F1{"ok?"} -->|Yes| F2["appLovinBannerAdUnitId = id<br/>bannerProvider='applovin' → Return"]
    F1 -->|No| G
    E1 -->|Yes| G["Last resort:<br/>getAdMobTestBannerId(size, collapsible)"]
    G --> H["destroyActiveBanner()<br/>ALFAdMob.createBanner(test unit) + showBanner"]
    H --> I["bannerProvider = 'admob-test'"]
```

- **Thứ tự ưu tiên**: AdMob real → AppLovin MAX → AdMob test (luôn có fill).
- `InitBannerAd(options)` = `LoadBannerAd(options)` + `ShowBannerAd()` — wrapper gọi nhanh.
- `HideBannerAd()` — ẩn theo provider đang sở hữu banner (`applovin` → `ALFAppLovinMAX.hideBanner`, ngược lại → `ALFAdMob.hideBanner`).
- `DestroyBannerAd()` → `destroyActiveBanner()` — hủy view + reset toàn bộ state banner.

```mermaid
flowchart LR
    subgraph HideBannerAd
        H1{"bannerProvider === 'applovin'?"} -->|Yes| H2["ALFAppLovinMAX.hideBanner"]
        H1 -->|No| H3["getActiveAdMobBannerId() → ALFAdMob.hideBanner"]
    end

    subgraph destroyActiveBanner
        D1{"bannerProvider === 'applovin'?"} -->|Yes| D2["ALFAppLovinMAX.destroyBanner"]
        D1 -->|No| D3["getActiveAdMobBannerId() → ALFAdMob.destroyBanner"]
        D2 --> D4["Reset: appLovinBannerAdUnitId / activeBannerAdUnitId / bannerProvider / admobBannerAttempted"]
        D3 --> D4
    end
```

> **Banner size (AppLovin)**: 50px phone, 90px tablet. AdMob hỗ trợ thêm `size` (`ADAPTIVE` | `BANNER` | `LARGE_BANNER` | `MEDIUM_RECTANGLE` | `FULL_BANNER` | `LEADERBOARD` | `{width,height}`) và `collapsible` (`top`/`bottom`) — **chỉ có hiệu lực trên Android**.

## Luồng MREC (AppLovin)

```mermaid
flowchart TD
    InitMREC --> A{"web?"} -->|Yes| B["Return"]
    A -->|No| C["getAdUnitId('mrec')"]
    C --> C1{"empty?"} -->|Yes| C2["Return"]
    C1 -->|No| D["ALFAppLovinMAX.createMRec({adUnitId, position})<br/>mặc định TOP_CENTER"]
    HideMREC --> E["getAdUnitId('mrec') → ALFAppLovinMAX.hideMRec"]
    DestroyMREC --> F["getAdUnitId('mrec') → ALFAppLovinMAX.destroyMRec"]
```

- Vị trí MREC (`AdViewPosition`): `TOP_CENTER` | `BOTTOM_CENTER` | `TOP_LEFT` | `TOP_RIGHT` | `BOTTOM_LEFT` | `BOTTOM_RIGHT` | `CENTER`. Native map sang gravity/constraints tương ứng.

## Luồng Interstitial (AppLovin)

```mermaid
flowchart TD
    LoadInter --> A["getAdUnitId('interstitial')"]
    A --> A1{"empty?"} -->|No| A2["ALFAppLovinMAX.loadInterstitial({adUnitId})"]

    ShowInter --> B["getAdUnitId('interstitial')"]
    B --> B1{"empty?"} -->|No| C{"isInterstitialReady?"}
    C -->|Yes| D["addListener('OnInterstitialAdHiddenEvent')"]
    D --> E["ALFAppLovinMAX.showInterstitial({adUnitId})"]
    E -. "ad đóng" .-> F["remove listener<br/>emitAdClosed({format:'interstitial'}) + onClose?.()"]
    C -->|No| G["Return"]
```

> `ShowInterstitial(onClose?)` chỉ show khi ad đã ready; nếu chưa ready thì **return im lặng** (không load lại).

## Luồng Rewarded Video (AppLovin)

```mermaid
flowchart TD
    LoadRewarded --> A["getAdUnitId('rewarded')"]
    A --> A1{"empty?"} -->|No| A2["ALFAppLovinMAX.loadRewardedAd({adUnitId})"]

    ShowRewarded --> B{"web?"} -->|Yes| B1["Return"]
    B -->|No| C["getAdUnitId('rewarded')"]
    C --> C1{"empty?"} -->|No| D{"isRewardedAdReady?"}
    D -->|Yes| E["listen 'OnRewardedAdReceivedRewardEvent' → result='rewarded'<br/>listen 'OnRewardedAdSkippedEvent' → result='skipped'<br/>listen 'OnRewardedAdHiddenEvent' → remove hết listeners"]
    E --> F["ALFAppLovinMAX.showRewardedAd({adUnitId})"]
    F -. "ad đóng" .-> G["emitAdClosed({format:'rewarded', result}) + onClose(result)"]
    D -->|No| H["LoadRewardedVideo()<br/>(load lại)"]
```

> Phân biệt **close có thưởng** (`OnRewardedAdReceivedRewardEvent` → `result='rewarded'`) và **close không thưởng** (`OnRewardedAdSkippedEvent` → `result='skipped'`). Native tự quyết định skip: khi ad đóng mà chưa grant reward thì emit `OnRewardedAdSkippedEvent`.

## Luồng App Open

AppLovin (có onClose):

```mermaid
flowchart TD
    A["LoadAppOpenAd() → loadAppOpenAd({adUnitId})"] --> B["IsAppOpenAdReady() → isAppOpenAdReady"]
    B --> C["ShowAppOpenAd(onClose?)"]
    C --> C1{"ready?"} -->|No| C2["Return"]
    C1 -->|Yes| D["addListener('OnAppOpenAdHiddenEvent')"]
    D --> E["ALFAppLovinMAX.showAppOpenAd({adUnitId})"]
    E -. "ad đóng" .-> F["remove listener<br/>emitAdClosed({format:'openApp'}) + onClose?.()"]
```

AdMob (không có onClose):

```mermaid
flowchart TD
    A["LoadAdMobAppOpenAd() → ALFAdMob.loadOpenAppAd"] --> B["IsAdMobAppOpenAdReady() → isOpenAppAdReady"]
    B --> C["ShowAdMobAppOpenAd() → ALFAdMob.showOpenAppAd"]
```

## Luồng Native Ad (AdMob)

Native ad được **render bằng view native** (`NativeAdView`) đè lên WebView. Đó là điều kiện bắt buộc để AdMob ghi impression và xử lý click — xem [native-code-ad.md §2.1b](../native-code-ad.md).

| Hàm | Chức năng |
|---|---|
| `ShowAdMobNativeAd(options?)` | `ALFAdMob.showNativeAd` — tự load nếu chưa có ad, dựng `NativeAdView`, gắn lên màn hình. Trả `boolean` |
| `UpdateAdMobNativeAdRect(rect)` | Dời ad ở rect mode — gọi khi scroll/resize |
| `HideAdMobNativeAd()` | Ẩn view, không hủy ad |
| `IsAdMobNativeAdReady()` | `isNativeAdReady` → có ad đã load |
| `DestroyAdMobNativeAd()` | `destroyNativeAd` + gỡ view + xóa cache |
| `SetOnNativeAdEventHandler(handler)` | Nhận event do Google SDK báo — trả unsubscribe fn |
| `PlayAdMobNativeAdVideo()` / `PauseAdMobNativeAdVideo()` / `SetAdMobNativeAdVideoMuted(muted)` | Điều khiển video của native ad. Trả `boolean` (`false` khi không có ad video) |

### Event native ad

```ts
type NativeAdEvent =
  | { type: 'loaded';     adUnitId: string; ad: NativeAdData }
  | { type: 'failed';     adUnitId: string; error: string }
  | { type: 'impression'; adUnitId: string }
  | { type: 'clicked';    adUnitId: string }
  | { type: 'paid';       adUnitId: string; value: number; currencyCode: string; precision: AdValuePrecision }
  | { type: 'video';      adUnitId: string; state: 'start' | 'play' | 'pause' | 'end' | 'mute' | 'unmute' }
```

- **`impression` là tín hiệu duy nhất đáng tin rằng ad đã hiện thật.** `ShowAdMobNativeAd()` trả `true` ngay khi view được attach — rect nằm ngoài viewport, bị che, hoặc `height: 0` vẫn `true`.
- **`clicked`** → user đang rời app sang advertiser: dùng để pause app/audio và hoãn interstitial kế tiếp (tránh 2 ad liên tiếp khi user quay lại).
- **`paid`** → gửi cho attribution SDK (AppsFlyer/Firebase), nếu không thì doanh thu native ad bị thiếu khỏi ROAS. `value` là đơn vị tiền tệ nguyên ở cả 2 nền tảng.
- Listener plugin được gắn **lazy** ở handler đầu tiên (`nativeAdListenerPromise` chống gắn trùng khi gọi song song) và dọn trong `destroy()`. No-op trên web.
- ⚠️ 2 event cũ `OnAdLoadedEvent` / `OnAdFailedToLoadEvent` đã bị xóa ở 1.2.0 — khai báo trong TS nhưng native chưa bao giờ emit.

`NativeAdInitOptions`: `template` (`'small' \| 'medium'`, mặc định `medium`), `position` + `height` (anchor mode), `rect` (rect mode, CSS px — ưu tiên hơn `position`), `style` (`background`, `textColor`, `secondaryTextColor`, `ctaBackground`, `ctaTextColor`, `cornerRadius`), cộng các field của `NativeAdLoadOptions` ở mục Native video.

```ts
const r = placeholder.getBoundingClientRect()
await ALF.Instance.Ads.ShowAdMobNativeAd({
  template: 'medium',
  rect: { x: r.x, y: r.y, width: r.width, height: r.height },
})
// ad view nằm trên WebView, không tự cuộn theo trang:
window.addEventListener('scroll', () => {
  const r = placeholder.getBoundingClientRect()
  ALF.Instance.Ads.UpdateAdMobNativeAdRect({ x: r.x, y: r.y, width: r.width, height: r.height })
}, { passive: true, capture: true })
```

### Native video

Video phát trong `MediaView` của template **`medium`** (template `small` không có media view — creative video vẫn hiện, nhưng chỉ icon/text). Hiển thị không cần gọi gì thêm; phần dưới để **tùy chỉnh request** và **theo dõi / điều khiển player**.

`NativeAdLoadOptions` (nhận bởi `ShowAdMobNativeAd` và `LoadAdMobNativeAd`):

| Field | Mặc định | Ý nghĩa |
|---|---|---|
| `video.startMuted` | `true` | Video bắt đầu tắt tiếng (AdMob khuyến nghị cho ad tự phát trong feed) |
| `video.customControlsRequested` | `false` | App tự vẽ control, SDK ẩn control của nó. **Chỉ publisher được allowlist** mới được cấp — xem `NativeAdData.videoCustomControlsEnabled` |
| `video.clickToExpandRequested` | `false` | Tap vào video mở full screen thay vì đi thẳng tới advertiser |
| `mediaAspectRatio` | `'any'` | `'landscape'` / `'portrait'` / `'square'` — lọc creative theo tỉ lệ media |

- **Option chốt lúc load.** SDK đưa chúng vào ad request, nên ad đã nằm trong cache giữ nguyên option cũ. Muốn đổi → `DestroyAdMobNativeAd()` rồi show lại.
- **Dev mode:** truyền `video` sẽ chuyển sang test unit **native video** của Google (luôn trả creative video). Test unit native giờ tách theo nền tảng — trước đây iOS dùng nhầm id Android. Production vẫn dùng một unit `keys.admob.{platform}.native`; AdMob phục vụ video từ unit đó nếu unit bật video.
- **Đổi unit:** vì dev mode có thể chọn unit khác, controller giữ `nativeAdActiveAdUnitId`. Request sang unit khác sẽ destroy ad của unit cũ trước. Request **không** có `video` giữ unit hiện tại, để `ShowAdMobNativeAd()` trơn vẫn hiện lại được ad video đã ẩn.
- **Event `video`**: `unmute` nghĩa là ad đang phát tiếng → hạ nhạc nền của app. `start` chỉ có trên Android; iOS báo frame đầu là `play`.
- **Play/Pause/Mute** chỉ chắc chắn có hiệu lực khi custom controls được cấp; khi SDK tự quản control, player có thể bỏ qua lệnh.

```ts
await ALF.Instance.Ads.ShowAdMobNativeAd({
  template: 'medium',
  rect,
  video: { startMuted: true },
  mediaAspectRatio: 'landscape',
})
ALF.Instance.Ads.SetOnNativeAdEventHandler((e) => {
  if (e.type === 'video' && e.state === 'unmute') bgm.duck()
  if (e.type === 'video' && e.state === 'mute') bgm.restore()
})
```

**Deprecated — chỉ để preview/debug:**

| Hàm | Ghi chú |
|---|---|
| `LoadAdMobNativeAd()` | Trả `NativeAdData` để xem asset. Vẽ bằng HTML **không** tính impression, click chết, vi phạm policy |
| `GetCachedNativeAd()` | Trả `NativeAdData` từ cache (sync) |
| `ReportAdMobNativeAdClick()` | Luôn fail — không có cách hợp lệ để báo click thủ công |

`NativeAdData` gồm: `adUnitId, headline, body, callToAction, iconUrl, imageUrl, hasVideoContent, mediaAspectRatio, videoDuration, videoCustomControlsEnabled, price, store, starRating, advertiser`. `mediaAspectRatio` (rộng/cao, `0` nếu không rõ) dùng để đặt chiều cao placeholder ở rect mode.

> **Migration từ cách render bằng HTML (≤ 1.1.31):** `mediaUrl` đã bị bỏ (thay bằng `hasVideoContent`) và `ReportAdMobNativeAdClick()` giờ luôn reject — xem hướng dẫn chuyển đổi kèm code trong [CHANGELOG.md](../../../../CHANGELOG.md#migration).

> `getAdMobNativeAdUnitId(video)` — dev mode trả test unit **theo nền tảng** (Android `…/2247696110`, iOS `…/3986624511`; video: Android `…/1044960115`, iOS `…/2521693316`), nên native ad luôn fill được khi test. Trước đây iOS dùng id test của Android.

## Luồng Ad close → Cooldown

```mermaid
flowchart LR
    A["Ad đóng (interstitial / rewarded / app open)"] --> B["emitAdClosed(event)"]
    B --> C["Global handler:<br/>SetOnAdCloseHandler(handler)"]
    C --> D["App thực hiện cooldown<br/>(vd: 30s chưa show interstitial lại)"]
```

```ts
type AdClosedEvent =
  | { format: 'interstitial'; result?: undefined }
  | { format: 'rewarded';      result: 'rewarded' | 'skipped' }
  | { format: 'openApp';       result?: undefined }
```

- `SetOnAdCloseHandler(handler)` trả về **unsubscribe fn**. Nhiều handler có thể đăng ký cùng lúc.
- `emitAdClosed` catch lỗi từng handler, không để crash lẫn nhau.

## Utility

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `GetAdHeight(kind)` | `'banner'` / `'mrec'` | `Promise<number>` | Chiều cao banner: MREC=250, tablet=90, phone=50 (qua `ALFAppLovinMAX.isTablet()`) |

## Public API

| Loại | Hàm | Mô tả |
|---|---|---|
| Init | `ALF.Ads.Init()` | Init AppLovin MAX |
| Init | `ALF.Ads.InitAdMob()` | Init AdMob |
| Banner | `ALF.Ads.LoadBannerAd(options?)` | Preload banner AdMob, giữ ẩn |
| Banner | `ALF.Ads.ShowBannerAd()` | Show banner — chuỗi fallback AdMob → AppLovin → AdMob test |
| Banner | `ALF.Ads.InitBannerAd(options?)` | Load + Show trong 1 lần gọi |
| Banner | `ALF.Ads.HideBannerAd()` / `ALF.Ads.DestroyBannerAd()` | Ẩn / hủy banner |
| MREC | `ALF.Ads.InitMRECAd(position?)` | Tạo + show MREC (mặc định `TOP_CENTER`) |
| MREC | `ALF.Ads.HideMRECAd()` / `ALF.Ads.DestroyMRECAd()` | Ẩn / hủy MREC |
| Interstitial | `ALF.Ads.LoadInterstitial()` | Preload interstitial |
| Interstitial | `ALF.Ads.ShowInterstitial(onClose?)` | Show interstitial; `onClose` khi đóng |
| Rewarded | `ALF.Ads.LoadRewardedVideo()` | Preload rewarded |
| Rewarded | `ALF.Ads.ShowRewardedVideo(onClose)` | Show rewarded; `onClose('rewarded' \| 'skipped')` khi đóng |
| App Open | `ALF.Ads.LoadAppOpenAd()` / `IsAppOpenAdReady()` / `ShowAppOpenAd(onClose?)` | AppLovin App Open |
| App Open | `ALF.Ads.LoadAdMobAppOpenAd()` / `IsAdMobAppOpenAdReady()` / `ShowAdMobAppOpenAd()` | AdMob App Open |
| Native | `ALF.Ads.ShowAdMobNativeAd()` / `UpdateAdMobNativeAdRect()` / `HideAdMobNativeAd()` / `IsAdMobNativeAdReady()` / `DestroyAdMobNativeAd()` | AdMob native ad (render bằng `NativeAdView`) |
| Native | `ALF.Ads.SetOnNativeAdEventHandler(handler)` | Event native ad từ Google SDK: `loaded` / `failed` / `impression` / `clicked` / `paid` / `video` |
| Native | `ALF.Ads.PlayAdMobNativeAdVideo()` / `PauseAdMobNativeAdVideo()` / `SetAdMobNativeAdVideoMuted(muted)` | Điều khiển video của native ad |
| Close tracking | `ALF.Ads.SetOnAdCloseHandler(handler)` | Đăng ký handler global khi full-screen ad đóng — dùng cho cooldown |
| Utility | `ALF.Ads.GetAdHeight(kind)` | Chiều cao banner theo loại |
| Cleanup | `ALF.Ads.destroy()` | Remove listeners, destroy banner/MREC/native, reset state |

`BannerInitOptions`: `{ position?: BannerPosition, size?: BannerSize, collapsible?: BannerCollapsible }` — mặc định `BOTTOM_CENTER`, AdMob Android only cho `size`/`collapsible`.

## State nội bộ

| Biến | Ý nghĩa |
|---|---|
| `initialized` / `admobInitialized` | Trạng thái init từng SDK |
| `bannerProvider` | `'admob' \| 'applovin' \| 'admob-test'` — provider đang sở hữu banner |
| `activeBannerAdUnitId` | AdMob banner unit đang tạo (có thể là test unit) |
| `appLovinBannerAdUnitId` | AppLovin banner unit đang tạo |
| `bannerOptions` | Options từ lần `LoadBannerAd` gần nhất, dùng lại khi show |
| `admobBannerAttempted` | Đã thử AdMob banner chưa (tránh retry) |
| `nativeAdCache` | `Map<adUnitId, NativeAdData>` — cache native ad |
| `adCloseHandlers` | Danh sách handler `SetOnAdCloseHandler` |
| `rewardListeners` | Danh sách listener rewarded đang active (cleanup khi destroy) |
| `nativeAdEventHandlers` | Danh sách handler `SetOnNativeAdEventHandler` |
| `nativeAdListeners` | Unsubscribe fn của 6 listener plugin native ad (cleanup khi destroy) |
| `nativeAdActiveAdUnitId` | Unit của native ad load/show gần nhất — dev mode có thể là test unit video, nên destroy và điều khiển video đi theo field này thay vì config |
| `nativeAdListenerPromise` | In-flight guard: gắn listener là async, chống gắn trùng khi nhiều handler đăng ký cùng lúc |

## Private helpers

| Hàm | Chức năng |
|---|---|
| `isDevMode()` | `settings.dev === true` |
| `getSdkKeyFromConfig()` | Đọc `keys.applovin.{platform}.sdkKey` |
| `getAdUnitId(type)` | Đọc `keys.applovin.{platform}.{type}` |
| `getAdMobAppId()` | Đọc `keys.admob.{platform}.appId` |
| `getAdMobAdUnitId(type)` | Đọc `keys.admob.{platform}.{type}` — Android dev mode trả test unit |
| `getAdMobBannerId()` | Đọc `keys.admob.{platform}.banner` — **luôn real, không test** |
| `getAdMobTestBannerId(size, collapsible)` | Chọn test unit theo options: collapsible → collapsible banner; fixed size → bannerFixed; ngược lại → adaptive banner |
| `getActiveAdMobBannerId()` | Trả `activeBannerAdUnitId` |
| `destroyActiveBanner()` | Hủy banner theo provider + reset state |
| `emitAdClosed(event)` | Gọi toàn bộ `adCloseHandlers`, catch lỗi từng handler |

## Dependencies

- **ALFAppLovinMAX plugin** (`sdk/plugins/applovin`) — banner, MREC, interstitial, rewarded, app open, `isTablet`
- **ALFAdMob plugin** (`sdk/plugins/admob`) — banner, interstitial, rewarded, app open, native ad
- **ConfigManager** (`af.Config`) — đọc sdkKey, appId, adUnitId, `settings.dev`
- **Utils** — `getPlatform()`, `logger`
- **Types** — `ad.types.ts` (`AdViewPosition`, `BannerInitOptions`, `AdClosedEvent`, `AdCloseHandler`, `RewardResult`, `RewardCallback`)
