/**
 * ALF Firebase Capacitor plugin — merged into the ALF SDK.
 *
 * Native code lives in sdk/android (alf.firebase.ALFFirebasePlugin). Shipping it
 * inside the SDK means `cap sync` registers it through `alf-app-sdk`; a nested
 * npm Firebase plugin would never be registered in the host app.
 *
 * Use it through `ALF.Instance.FirebaseAnalytics`, not directly.
 */
export * from './src'
