# `AnalyticsController` — Analytics (AppsFlyer)

## Vai trò

Quản lý SDK **AppsFlyer** — theo dõi cài đặt, session, deep link, sự kiện in-app. Dùng plugin `appsflyer-capacitor-plugin`.

---

## Luồng Init

```mermaid
flowchart TD
    A["init()"] --> B{"Config.isReady()?"}
    B -->|No| C["Return"]
    B -->|Yes| D{"isNativePlatform()?"}
    D -->|No| E["Return"]
    D -->|Yes| F["this.af.Config.get('keys.appsflyer.devKey')"]
    F --> G["this.af.Config.get('keys.appsflyer.iosAppId')"]
    G --> H["this.af.Config.get('settings.dev')<br/><i>→ isDev</i>"]
    
    H --> I{"devKey empty?"}
    I -->|Yes| J["Return"]
    I -->|No| K{"platform === 'ios'<br/>AND iosAppId empty?"}
    K -->|Yes| L["Return"]
    K -->|No| M["Cấu hình AppsFlyer:<br/>appID, devKey, isDebug=isDev<br/>waitForATT=10, ..."]
    
    M --> N["TRY: AppsFlyer.initSDK(afConfig)"]
    N --> O{"Thành công?"}
    O -->|Yes| P["this.initialized = true"]
    O -->|No| Q["LOG error<br/>(non-fatal)"]
```

## Tham số AppsFlyer config

```mermaid
flowchart LR
    A["afConfig"] --> B["appID: iosAppId"]
    A --> C["devKey: devKey"]
    A --> D["isDebug: settings.dev"]
    A --> E["waitForATTUserAuthorization: 10"]
    A --> F["minTimeBetweenSessions: 6"]
    A --> G["registerOnDeepLink: true"]
    A --> H["registerConversionListener: true"]
    A --> I["useReceiptValidationSandbox: settings.dev"]
    A --> J["useUninstallSandbox: settings.dev"]
```

## Luồng Log Event

```mermaid
flowchart TD
    A["LogEvent(eventName, eventParams?)"] --> B{"this.initialized?"}
    B -->|No| C["Return"]
    B -->|Yes| D["TRY: AppsFlyer.logEvent(eventName, eventParams)"]
    D --> E{"Lỗi?"}
    E -->|Yes| F["LOG error"]
    E -->|No| G["OK"]
```

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Khởi tạo AppsFlyer SDK với devKey từ ConfigManager. Dùng `settings.dev` cho debug/sandbox mode. |
| `LogEvent(eventName, eventParams?)` | string, object | `Promise<void>` | Ghi lại sự kiện người dùng (purchase, level_up, ...) |
| `SetUserId(userId)` | string | `Promise<void>` | Gán user ID để match dữ liệu bên ngoài |
| `SetUserEmail(email)` | string | `Promise<void>` | Gán email (hash) cho user matching |

## Dependencies

- **ConfigManager**: `get('keys.appsflyer')`, `get('settings.dev')`
- **PermissionController**: `RequestTracking()` trước khi init (ATT iOS)

## Cách dùng

```mermaid
flowchart LR
    A["ALF.Analytics.LogEvent('purchase_completed', { product_id, price })"]
    B["ALF.Analytics.SetUserId('user_abc_123')"]
```
