import Foundation
import Capacitor
import AppLovinSDK

@objc(ALFAppLovinMAXPlugin)
public class ALFAppLovinMAXPlugin: CAPPlugin {

    // Capacitor calls plugin methods on a background queue; MAX and UIKit want
    // the main thread. Every method that touches an ad hops there, and the MAX
    // delegates already call back there, so these maps are main-thread only.
    private var banners: [String: MAAdView] = [:]
    private var pendingBannerLoads: [String: CAPPluginCall] = [:]
    private var mrecs: [String: MAAdView] = [:]
    // ONE instance per ad unit for interstitial / app open, reloaded with
    // load() (as MAX asks) rather than a new instance per load.
    private var interstitials: [String: MAInterstitialAd] = [:]
    private var rewardedAds: [String: MARewardedAd] = [:]
    private var rewardListeners: [String: (MARewardedAd) -> Void] = [:]
    private var rewardedGranted: [String: Bool] = [:]
    private var appOpenAds: [String: MAAppOpenAd] = [:]

    // MARK: - Initialize

    @objc func initialize(_ call: CAPPluginCall) {
        guard let sdkKey = call.getString("sdkKey"), !sdkKey.isEmpty else {
            call.reject("sdkKey is required")
            return
        }

        let settings = ALSdkSettings()
        let sdk = ALSdk.initialize(sdkKey: sdkKey, settings: settings) { configuration in
            call.resolve([
                "initialized": true
            ])
        }
    }

    @objc func isTablet(_ call: CAPPluginCall) {
        let isTablet = UIDevice.current.userInterfaceIdiom == .pad
        call.resolve([
            "isTablet": isTablet
        ])
    }

    // MARK: - Banner

    @objc func createBanner(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        let position = call.getString("position") ?? "BOTTOM_CENTER"

        DispatchQueue.main.async {
            // Remove existing banner if any
            if let existing = self.banners[adUnitId] {
                existing.removeFromSuperview()
                self.banners.removeValue(forKey: adUnitId)
            }

            let adView = MAAdView(adUnitIdentifier: adUnitId)
            adView.delegate = self
            adView.backgroundColor = .black

            guard let rootView = self.bridge?.viewController?.view else {
                call.reject("No root view controller")
                return
            }

            rootView.addSubview(adView)
            adView.translatesAutoresizingMaskIntoConstraints = false

            let isBottom = position == "BOTTOM_CENTER"

            NSLayoutConstraint.activate([
                adView.leadingAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.leadingAnchor),
                adView.trailingAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.trailingAnchor),
                isBottom
                    ? adView.bottomAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.bottomAnchor)
                    : adView.topAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.topAnchor)
            ])

            // Set fixed height based on device type
            let height: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 90 : 50
            adView.heightAnchor.constraint(equalToConstant: height).isActive = true

            // Start loading
            adView.loadAd()

            self.banners[adUnitId] = adView
            self.pendingBannerLoads[adUnitId] = call
        }
    }

    @objc func showBanner(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let adUnitId = call.getString("adUnitId"), let adView = self.banners[adUnitId] else {
                call.reject("Banner not found for adUnitId")
                return
            }
            adView.isHidden = false
            call.resolve()
        }
    }

    @objc func hideBanner(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let adUnitId = call.getString("adUnitId"), let adView = self.banners[adUnitId] else {
                call.reject("Banner not found for adUnitId")
                return
            }
            adView.isHidden = true
            call.resolve()
        }
    }

    @objc func destroyBanner(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let adUnitId = call.getString("adUnitId"), let adView = self.banners[adUnitId] else {
                call.reject("Banner not found for adUnitId")
                return
            }
            adView.removeFromSuperview()
            self.banners.removeValue(forKey: adUnitId)
            call.resolve()
        }
    }

    // MARK: - MREC

    @objc func createMRec(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        let position = call.getString("position") ?? "TOP_CENTER"

        DispatchQueue.main.async {
            // Remove existing MREC if any
            if let existing = self.mrecs[adUnitId] {
                existing.removeFromSuperview()
                self.mrecs.removeValue(forKey: adUnitId)
            }

            let adView = MAAdView(adUnitIdentifier: adUnitId, adFormat: .mrec)
            adView.delegate = self
            adView.backgroundColor = .black

            guard let rootView = self.bridge?.viewController?.view else {
                call.reject("No root view controller")
                return
            }

            rootView.addSubview(adView)
            adView.translatesAutoresizingMaskIntoConstraints = false

            var constraints: [NSLayoutConstraint] = [
                adView.widthAnchor.constraint(equalToConstant: 300),
                adView.heightAnchor.constraint(equalToConstant: 250)
            ]

            switch position {
            case "TOP_LEFT", "BOTTOM_LEFT":
                constraints.append(adView.leadingAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.leadingAnchor))
            case "TOP_RIGHT", "BOTTOM_RIGHT":
                constraints.append(adView.trailingAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.trailingAnchor))
            default:
                constraints.append(adView.centerXAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.centerXAnchor))
            }

            switch position {
            case "TOP_LEFT", "TOP_CENTER", "TOP_RIGHT":
                constraints.append(adView.topAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.topAnchor))
            case "BOTTOM_LEFT", "BOTTOM_CENTER", "BOTTOM_RIGHT":
                constraints.append(adView.bottomAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.bottomAnchor))
            default:
                constraints.append(adView.centerYAnchor.constraint(equalTo: rootView.safeAreaLayoutGuide.centerYAnchor))
            }

            NSLayoutConstraint.activate(constraints)

            adView.loadAd()

            self.mrecs[adUnitId] = adView
            call.resolve()
        }
    }

    @objc func showMRec(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let adUnitId = call.getString("adUnitId"), let adView = self.mrecs[adUnitId] else {
                call.reject("MREC not found for adUnitId")
                return
            }
            adView.isHidden = false
            call.resolve()
        }
    }

    @objc func hideMRec(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let adUnitId = call.getString("adUnitId"), let adView = self.mrecs[adUnitId] else {
                call.reject("MREC not found for adUnitId")
                return
            }
            adView.isHidden = true
            call.resolve()
        }
    }

    @objc func destroyMRec(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard let adUnitId = call.getString("adUnitId"), let adView = self.mrecs[adUnitId] else {
                call.reject("MREC not found for adUnitId")
                return
            }
            adView.removeFromSuperview()
            self.mrecs.removeValue(forKey: adUnitId)
            call.resolve()
        }
    }

    // MARK: - Interstitial

    @objc func loadInterstitial(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            let interstitial: MAInterstitialAd
            if let existing = self.interstitials[adUnitId] {
                interstitial = existing
            } else {
                interstitial = MAInterstitialAd(adUnitIdentifier: adUnitId)
                interstitial.delegate = self
                self.interstitials[adUnitId] = interstitial
            }
            // Already holds a loaded ad: nothing to load.
            if !interstitial.isReady { interstitial.load() }
            call.resolve()
        }
    }

    @objc func isInterstitialReady(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            let ready = self.interstitials[adUnitId]?.isReady ?? false
            call.resolve([
                "ready": ready
            ])
        }
    }

    @objc func showInterstitial(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            guard let interstitial = self.interstitials[adUnitId], interstitial.isReady else {
                call.reject("Interstitial ad is not ready")
                return
            }

            interstitial.show()
            call.resolve()
        }
    }

    // MARK: - Rewarded

    @objc func loadRewardedAd(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            // shared(withAdUnitIdentifier:) is already one instance per unit.
            let rewarded = MARewardedAd.shared(withAdUnitIdentifier: adUnitId)
            rewarded.delegate = self
            self.rewardedAds[adUnitId] = rewarded
            rewarded.load()

            call.resolve()
        }
    }

    @objc func isRewardedAdReady(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            let ready = self.rewardedAds[adUnitId]?.isReady ?? false
            call.resolve([
                "ready": ready
            ])
        }
    }

    @objc func showRewardedAd(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            guard let rewarded = self.rewardedAds[adUnitId], rewarded.isReady else {
                call.reject("Rewarded ad is not ready")
                return
            }

            rewarded.show()
            call.resolve()
        }
    }

    // MARK: - App Open

    @objc func loadAppOpenAd(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId"), !adUnitId.isEmpty else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            let appOpenAd: MAAppOpenAd
            if let existing = self.appOpenAds[adUnitId] {
                appOpenAd = existing
            } else {
                appOpenAd = MAAppOpenAd(adUnitIdentifier: adUnitId)
                appOpenAd.delegate = self
                self.appOpenAds[adUnitId] = appOpenAd
            }
            // Already holds a loaded ad: nothing to load.
            if !appOpenAd.isReady { appOpenAd.load() }
            call.resolve()
        }
    }

    @objc func isAppOpenAdReady(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            let ready = self.appOpenAds[adUnitId]?.isReady ?? false
            call.resolve([
                "ready": ready
            ])
        }
    }

    @objc func showAppOpenAd(_ call: CAPPluginCall) {
        guard let adUnitId = call.getString("adUnitId") else {
            call.reject("adUnitId is required")
            return
        }

        DispatchQueue.main.async {
            guard let appOpenAd = self.appOpenAds[adUnitId], appOpenAd.isReady else {
                call.reject("App open ad is not ready")
                return
            }

            appOpenAd.show()
            call.resolve()
        }
    }
}

// MARK: - MAAdViewAdDelegate

extension ALFAppLovinMAXPlugin: MAAdViewAdDelegate {
    public func didLoad(_ ad: MAAd) {
        if let call = pendingBannerLoads.removeValue(forKey: ad.adUnitIdentifier) {
            call.resolve()
        }
    }
    public func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Failed to load ad for \(adUnitIdentifier): \(error.message)")
        if let call = pendingBannerLoads.removeValue(forKey: adUnitIdentifier) {
            call.reject("Banner failed to load (adUnitId=\(adUnitIdentifier), code=\(error.code)): \(error.message)")
        }
    }
    public func didDisplay(_ ad: MAAd) {}
    public func didHide(_ ad: MAAd) {}
    public func didClick(_ ad: MAAd) {}
    public func didFail(toDisplay ad: MAAd, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Failed to display ad: \(error.message)")
    }
}

// MARK: - MAInterstitialAdDelegate

extension ALFAppLovinMAXPlugin: MAInterstitialAdDelegate {
    public func didLoad(_ ad: MAAd) {}
    public func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Interstitial failed to load for \(adUnitIdentifier): \(error.message)")
    }
    public func didDisplay(_ ad: MAAd) {}
    public func didHide(_ ad: MAAd) {
        notifyListeners("OnInterstitialAdHiddenEvent", data: [
            "adUnitId": ad.adUnitIdentifier
        ])
    }
    public func didClick(_ ad: MAAd) {}
    public func didFail(toDisplay ad: MAAd, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Interstitial failed to display: \(error.message)")
        notifyListeners("OnInterstitialAdDisplayFailedEvent", data: ["adUnitId": ad.adUnitIdentifier, "error": error.message])
    }
}

// MARK: - MARewardedAdDelegate

extension ALFAppLovinMAXPlugin: MARewardedAdDelegate {
    public func didLoad(_ ad: MAAd) {
        rewardedGranted[ad.adUnitIdentifier] = false
    }
    public func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Rewarded failed to load for \(adUnitIdentifier): \(error.message)")
    }
    public func didDisplay(_ ad: MAAd) {}
    public func didHide(_ ad: MAAd) {
        notifyListeners("OnRewardedAdHiddenEvent", data: [
            "adUnitId": ad.adUnitIdentifier
        ])

        if rewardedGranted[ad.adUnitIdentifier] != true {
            notifyListeners("OnRewardedAdSkippedEvent", data: [
                "adUnitId": ad.adUnitIdentifier
            ])
        }
    }
    public func didClick(_ ad: MAAd) {}
    public func didStartRewardedAd(for ad: MAAd) {
        NSLog("[ALFAppLovinMAX] Rewarded video started")
    }
    public func didCompleteRewardedVideo(for ad: MAAd) {
        NSLog("[ALFAppLovinMAX] Rewarded video completed")
    }
    public func didRewardUser(for ad: MAAd, with reward: MAReward) {
        rewardedGranted[ad.adUnitIdentifier] = true
        notifyListeners("OnRewardedAdReceivedRewardEvent", data: [
            "adUnitId": ad.adUnitIdentifier,
            "amount": reward.amount
        ])
    }
    public func didFail(toDisplay ad: MAAd, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] Rewarded failed to display: \(error.message)")
        notifyListeners("OnRewardedAdDisplayFailedEvent", data: ["adUnitId": ad.adUnitIdentifier, "error": error.message])
    }
}

// MARK: - MAAppOpenAdDelegate

extension ALFAppLovinMAXPlugin: MAAppOpenAdDelegate {
    public func didLoad(_ ad: MAAd) {
        NSLog("[ALFAppLovinMAX] App open ad loaded for \(ad.adUnitIdentifier)")
    }
    public func didFailToLoadAd(forAdUnitIdentifier adUnitIdentifier: String, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] App open failed to load for \(adUnitIdentifier): \(error.message)")
    }
    public func didDisplay(_ ad: MAAd) {}
    public func didHide(_ ad: MAAd) {
        notifyListeners("OnAppOpenAdHiddenEvent", data: [
            "adUnitId": ad.adUnitIdentifier
        ])
    }
    public func didClick(_ ad: MAAd) {}
    public func didFail(toDisplay ad: MAAd, withError error: MAError) {
        NSLog("[ALFAppLovinMAX] App open failed to display: \(error.message)")
        notifyListeners("OnAppOpenAdDisplayFailedEvent", data: ["adUnitId": ad.adUnitIdentifier, "error": error.message])
    }
}
