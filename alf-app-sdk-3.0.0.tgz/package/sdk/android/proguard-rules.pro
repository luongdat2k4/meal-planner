# AppLovin MAX SDK + AdMob mediation adapter ProGuard rules.
# AppLovin MIX adapter AARs ship their own rules; these are defensive fallbacks.

-keep class com.applovin.mediation.** { *; }
-keep class com.applovin.sdk.** { *; }
-keep class com.google.android.gms.ads.** { *; }
-keep class com.google.android.gms.common.** { *; }
-dontwarn com.google.android.gms.ads.**
