#import <Capacitor/Capacitor.h>

CAP_PLUGIN(ALFAppLovinMAXPlugin, "ALFAppLovinMAX",
    CAP_PLUGIN_METHOD(initialize, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(isTablet, CAPPluginReturnPromise);

    CAP_PLUGIN_METHOD(createBanner, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(showBanner, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(hideBanner, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(destroyBanner, CAPPluginReturnPromise);

    CAP_PLUGIN_METHOD(createMRec, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(showMRec, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(hideMRec, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(destroyMRec, CAPPluginReturnPromise);

    CAP_PLUGIN_METHOD(loadInterstitial, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(isInterstitialReady, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(showInterstitial, CAPPluginReturnPromise);

    CAP_PLUGIN_METHOD(loadRewardedAd, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(isRewardedAdReady, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(showRewardedAd, CAPPluginReturnPromise);

    CAP_PLUGIN_METHOD(loadAppOpenAd, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(isAppOpenAdReady, CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(showAppOpenAd, CAPPluginReturnPromise);
)
