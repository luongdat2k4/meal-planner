# Analytics + doanh thu quảng cáo không tới được AppsFlyer

**Ngày:** 2026-09-24 · **SDK:** 1.2.0 · **App phát hiện:** AutoBattler (Android, Capacitor 7) ·
**Liên quan:** [2026-09-24-native-video-ad.md](2026-09-24-native-video-ad.md)

Khi nối native ad 1.2.0 vào AutoBattler, event `paid` (doanh thu một impression native) đến được
app nhưng **không có chỗ nào để gửi đi**. Lần theo thì thấy cả đường analytics của app đang chết im
lặng. Note này ghi lại **đã kiểm chứng gì**, **vì sao hỏng**, và **kế hoạch sửa**. Chưa sửa gì.

## ✅ Quyết định (2026-09-24): HOÃN

AutoBattler **chưa chạy UA**, hiện chỉ cần biết quảng cáo ra bao nhiêu tiền. Việc đó AdMob / AppLovin
MAX dashboard tự làm, theo App ID và ad unit ID, khi Google/MAX SDK ghi được impression. Không cần
gửi gì từ app. Vì vậy **chưa làm** kế hoạch bên dưới.

- Việc làm ra tiền thật là **native render bằng `NativeAdView`** (SDK 1.2.0). Bản HTML cũ không ghi
  impression nên doanh thu native trên AdMob ≈ 0. Việc này **vẫn làm**, xem
  [2026-09-24-native-video-ad.md](2026-09-24-native-video-ad.md).
- `paid` tiếp tục chỉ `console.info` trong `AdsService` để đối chiếu với AdMob dashboard.

**Mở lại note này khi:** bắt đầu chạy UA trả phí (cần ROAS/LTV theo campaign → AppsFlyer phải chạy
thật), hoặc cần product analytics (retention, funnel). Chạy UA bằng Google Ads thì cân nhắc nối
AdMob ↔ Firebase Analytics thay cho AppsFlyer. Nếu AppsFlyer có tích hợp ad revenue phía server với
network thì **không** gửi thêm `logAdRevenue` từ client, để tránh đếm trùng.

Việc nhỏ nên làm dù hoãn: bước 3 (SDK warn rõ khi AppsFlyer init fail). Không thì ai đọc code cũng
tưởng đang có số liệu.

---

## Triệu chứng

| Hiện tượng | Bằng chứng |
|---|---|
| Mọi `logEvent` của game không rời máy | Không throw, không log, không warning — từ phía game trông như gửi thành công |
| Doanh thu native (`paid`) không gửi được | `AdsService._onNativeEvent` chỉ `console.info` event `paid` — cố ý, vì không có đường gửi |
| Comment có sẵn trong `AdsService.js` (trên `logEvent`) đã ghi nhận từ 11/08/2026 | "hiện tại hàm này KHÔNG gửi được gì cả" |

## Nguyên nhân — chuỗi đứt ở 3 chỗ

```
adsService.logEvent()
  → ALF.Instance.Analytics.LogEvent()      (SDK — AnalyticsController)
    → AppsFlyer.logEvent()                  (appsflyer-capacitor-plugin — native)
```

### 1. Plugin AppsFlyer không được build vào APK

- `appsflyer-capacitor-plugin` là dependency của **SDK**, không phải của app. npm cài nó **lồng**
  trong `node_modules/@alf/app-sdk/node_modules/appsflyer-capacitor-plugin`, không ở
  `node_modules/` gốc.
- `npx cap sync` chỉ đăng ký plugin nằm trong `dependencies` của **chính app**.
- Kiểm chứng trên AutoBattler sau `cap sync`:
  - `android/capacitor.settings.gradle`: chỉ `capacitor-android`, `alf-app-sdk`, `capacitor-community-keep-awake`.
  - `capacitor.plugins.json`: chỉ `ALFDownloadPlugin`, `ALFAppLovinMAXPlugin`, `ALFAdMobPlugin`, `KeepAwakePlugin`.
  - → Phần JS của AppsFlyer có trong bundle, phần native **không có** trong APK.

### 2. Init thất bại và bị nuốt lỗi

`AnalyticsController.init()` gọi `AppsFlyer.initSDK()` → bridge báo plugin không tồn tại → lỗi bị
`catch`, `initialized` ở lại `false`. Không có warning nào đủ rõ để ai nhận ra.

### 3. `LogEvent` âm thầm return

```ts
async LogEvent(eventName, eventParams) {
  if (!this.initialized) return        // AnalyticsController.ts:56
  ...
}
```

→ Mọi event rơi vào hư không, **kể cả khi plugin chỉ thiếu vì cấu hình**.

## Lỗ thứ hai — SDK không có API doanh thu quảng cáo

Kể cả khi sửa xong 3 chỗ trên, `AnalyticsController` chỉ có `LogEvent`, `SetUserId`,
`SetUserEmail`. **Không có hàm gửi ad revenue.** Gửi doanh thu bằng `LogEvent` thường là sai —
AppsFlyer không tính vào ROAS/ad revenue.

Plugin đã có API đúng (kiểm chứng trong `dist/esm/definitions.d.ts` của cả 6.17.9 lẫn 6.18.0):

```ts
logAdRevenue(data: AFAdRevenueData): Promise<void>

interface AFAdRevenueData {
  monetizationNetwork: string          // vd 'admob'
  mediationNetwork: MediationNetwork   // GOOGLE_ADMOB = 'google_admob', APPLOVIN_MAX = 'applovin_max', ...
  currencyIso4217Code: string          // = NativeAdPaidEvent.currencyCode
  revenue: number                      // = NativeAdPaidEvent.value (đơn vị tiền nguyên — SDK đã chia micros)
  additionalParameters?: StringMap     // có thể gửi adUnitId, ad format, precision
}
```

## ⚠️ Bẫy phiên bản

| | Version | `@capacitor/core` peer |
|---|---|---|
| SDK khai | `^6.17.8` | — |
| npm thực tế resolve (đang nằm trong AutoBattler) | **6.18.0** | **`>=8.0.0`** |
| Bản cuối còn nhận Capacitor 7 | **6.17.9** | `>=7.0.0` |

AutoBattler dùng **Capacitor 7** (`@capacitor/android ^7.6.7`). `^6.17.8` kéo về 6.18.0 — bản đòi
Capacitor 8. Chỉ thêm dependency vào app thôi là **chưa đủ**: phải ghim đúng `6.17.9`, nếu không
`cap sync`/Gradle có thể build ra plugin native không tương thích.

SDK (`app-framework`) tự nó đang dùng `@capacitor/core ^8.0.0` → `src-dev` không gặp bẫy này, app
Capacitor 7 thì gặp. Cần quyết định SDK hỗ trợ Capacitor 7 tới đâu.

---

## Kế hoạch sửa

| # | Ở đâu | Việc | Kết quả |
|---|---|---|---|
| 1 | AutoBattler | Thêm `"appsflyer-capacitor-plugin": "6.17.9"` (ghim chính xác) vào `dependencies`, `npm install`, `npx cap sync android` | Plugin native vào APK → `LogEvent` hiện có bắt đầu gửi được |
| 2 | SDK | `AnalyticsController.LogAdRevenue({ network, mediation, value, currencyCode, params })` bọc `AppsFlyer.logAdRevenue` | Có đường gửi doanh thu |
| 3 | SDK | `init()` fail → `logger.warn` rõ ràng (tên plugin + gợi ý "thêm vào dependencies của app rồi cap sync"); `LogEvent` khi chưa init → warn **một lần** thay vì return im lặng | Lần sau không mất dữ liệu mà không ai biết |
| 4 | SDK (tùy chọn) | `AdController` tự forward `OnNativeAdPaidEvent` sang `LogAdRevenue` khi Analytics đã init — app khỏi phải tự nối | Mọi app dùng native đều có revenue, không phụ thuộc app nhớ nối |
| 5 | AutoBattler | Đổi `console.info` của `paid` trong `AdsService._onNativeEvent` thành `LogAdRevenue` (bỏ nếu làm bước 4) | Doanh thu native lên AppsFlyer |
| 6 | Tài liệu | README/sdk-guide: app **phải** tự khai `appsflyer-capacitor-plugin` (đúng bản theo Capacitor) trong `dependencies` | Tránh lặp lại ở app khác |

Bước 1 độc lập, làm trước được và có tác dụng ngay với các event hiện có.

## Câu hỏi còn mở

- **Doanh thu các format khác** (banner/interstitial/rewarded qua AppLovin MAX, AdMob) có đang được
  forward không? **Chưa kiểm tra.** Nếu chưa, bước 2 dùng chung cho tất cả — `MediationNetwork.APPLOVIN_MAX`
  cho format đi qua MAX.
- AppsFlyer có **tự** thu ad revenue qua tích hợp AdMob/MAX phía server (ad revenue connector) không?
  Nếu dashboard đã bật thì gửi thêm từ client có thể **đếm trùng** — phải hỏi người quản lý
  AppsFlyer trước khi bật bước 4/5.
- SDK có tiếp tục hỗ trợ app Capacitor 7 không (xem Bẫy phiên bản)?
- Bước 1 cũng áp dụng cho các plugin khác mà SDK kéo theo nhưng app không khai — cần rà
  `dependencies` của SDK xem còn plugin native nào bị bỏ sót khi `cap sync`.

## Kiểm chứng sau khi sửa

1. `cap sync` xong: `capacitor.plugins.json` có class AppsFlyer; `capacitor.settings.gradle` có
   `appsflyer-capacitor-plugin`.
2. Logcat lúc boot: `[AnalyticsController] AppsFlyer initialized` (không còn im lặng).
3. AppsFlyer dashboard → SDK Integration Tests / Event log: thấy event game và `af_ad_revenue`.
4. Test unit của Google thường trả `value = 0` — kiểm tra event **có tới** với `currency` đúng,
   đừng chờ số tiền thật.
