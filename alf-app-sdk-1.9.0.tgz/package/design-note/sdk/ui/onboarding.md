# Onboarding Screen

## Layout

```
┌──────────────────────────────┐
│                    [Skip]    │  ← absolute top-right
├──────────────────────────────┤
│                              │
│         Full-width           │
│         Image                │  ← aspect-ratio 16/9
│                              │
│        ● ● ○ ○ ○            │  ← dots overlay (bottom of image)
│                              │
├──────────────────────────────┤
│                              │
│    Step Title                │  ← text area, center aligned
│    Description               │
│                              │
├──────────────────────────────┤
│        [Next / Get Started]  │  ← button
├──────────────────────────────┤
│                              │
│     Native Ad Container      │  ← 30% height
│                              │
└──────────────────────────────┘
```

- **70% top**: Content area (image + text + button)
- **30% bottom**: Native ad container

## Config (`config.json` → `settings.onboarding`)

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `enable` | boolean | `false` | Bật/tắt onboarding trong project |
| `page_count` | number | `3` | Số lượng trang onboarding |
| `image_paths` | string[] | `[]` | Path ảnh cho từng trang (relative to `resources/src/asset/`) |
| `text_color` | string | `"#000000"` | Màu chữ hex |
| `background_color` | string | `"#ffffff"` | Màu nền hex |

### Ví dụ

```json
{
  "settings": {
    "onboarding": {
      "enable": true,
      "page_count": 3,
      "image_paths": [
        "onboarding/welcome.png",
        "onboarding/personalize.png",
        "onboarding/ready.png"
      ],
      "text_color": "#000000",
      "background_color": "#ffffff"
    }
  }
}
```

## Props (injected từ `main.ts`)

OnboardingView nhận `onboardingConfig` qua Vue `provide/inject`:

```typescript
import type { OnboardingConfig } from '@/alf'

const onboardingConfig = inject<Ref<OnboardingConfig>>('onboardingConfig')!
```

## Key behaviors

1. **Page count**: `onboarding.page_count` quyết định số dots và số lần next. Nếu `page_count = 3`, sẽ có 3 dots, 3 lần next trước khi "Get Started".
2. **Images**: `onboarding.image_paths[i]` là path tương ứng trang thứ `i`. Nếu không có ảnh, fallback hiển thị placeholder.
3. **Dots overlay**: Nằm ở bottom của image area, có background semi-transparent + blur.
4. **Skip button**: Absolute top-right, luôn visible.
5. **Native ad**: 30% bottom, placeholder hiện tại, sau này sẽ thay bằng AdController.
6. **Persistence**: `ALF.Instance.Data.completeOnboarding()` được gọi khi user nhấn "Get Started" hoặc "Skip".
