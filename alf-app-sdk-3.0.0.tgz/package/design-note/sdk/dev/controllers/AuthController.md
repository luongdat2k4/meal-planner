# `AuthController` — Xác thực

## Vai trò

Quản lý chu kỳ sống của **session/token**: lưu trữ, refresh, clear. Token được lưu trong **Capacitor Storage** (thay vì StorageController thông thường) để đảm bảo an toàn.

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Khôi phục session từ secure storage |
| `setSession(session)` | `AuthSession` | `Promise<void>` | Lưu session mới + start refresh timer |
| `setUser(user)` | `AuthUser` | `Promise<void>` | Lưu thông tin user |
| `refreshToken()` | — | `Promise<boolean>` | Refresh access token (cần override) |
| `clearSession()` | — | `Promise<void>` | Xoá session + user (logout) |
| `isExpired()` | — | `boolean` | Kiểm tra token hết hạn chưa |
| `isAuthenticated()` | — | `boolean` | Kiểm tra đã auth + token còn hạn |

---

## Luồng Init

```mermaid
flowchart TD
    A["init()"] --> B["Đọc từ secure storage"]
    B --> C{"Có session?"}
    C -->|No| D["status = unauthenticated"]
    C -->|Yes| E{"expiresAt > now?"}
    E -->|Yes| F["Khôi phục session + start refresh timer"]
    E -->|No| G["status = expired"]
```

---

## Luồng Refresh Token

```mermaid
flowchart TD
    A["setInterval trước expiry 1 phút"] --> B["refreshToken()"]
    B --> C{"Thành công?"}
    C -->|Yes| D["Cập nhật session + reset timer"]
    C -->|No| E["clearSession()"]
```

---

## Cấu trúc dữ liệu

```typescript
interface AuthSession {
  accessToken: string
  refreshToken: string
  expiresAt: number      // unix ms
  tokenType: string
}

interface AuthUser {
  id: string
  email: string
  displayName: string
  photoUrl?: string
}

type AuthStatus = 'authenticated' | 'unauthenticated' | 'expired' | 'loading'
```

## Dependencies

- `Capacitor.Plugins.Storage` — lưu session (thay thế bằng `@capacitor/preferences` hoặc Secure Storage plugin)

## Lưu ý

- `refreshToken()` mặc định trả `false` — consuming project cần **override** logic refresh thực tế
- Session được lưu qua `Capacitor.Storage` (không dùng `AppDataController` để tránh lộ token)
- Tự động refresh 1 phút trước khi token hết hạn
