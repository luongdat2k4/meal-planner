# Hiệu năng quảng cáo: bớt giật khi khởi động và khi hiện ad

**Ngày:** 2026-11-03 · **SDK hiện tại:** 2.0.0 → dự kiến **3.0.0** (big update) · **Trạng thái:** ĐÃ CODE
3.1–3.4 (2026-11-03), CHƯA ĐO LẠI. Còn 3.5 (chờ quyết định) và bump 3.0.0.

Mục tiêu: game không còn giật khi ad hiện, khi chuyển màn và khi đóng interstitial; boot nhanh
hơn. Doanh thu giữ nguyên: không bớt format, không bớt impression. Chỉ sắp lại **lúc nào** ad
được nạp/vẽ và **cách** plugin native làm việc đó.

---

## 1. Bằng chứng (log thật, 2026-11-03)

Máy Samsung SM-A166P (Android 16), game `com.zl.auto.brawl.rogue.clash`, chạy từ 15:06:26 đến
khoảng 15:09:30. Build dev, **`TEST ADS ON`**. Log đã lọc theo pid của game (pid 744).

> ⚠ Ad test của Google (nhất là native video) có thể nặng/nhẹ khác ad thật. Log cho biết lag xảy
> ra **lúc nào**, chưa phải mức lag ở production. Phải đo lại bằng unit thật (mục 7).

### 1.1. Các lần giật khớp với sự kiện ads

| Lúc | Choreographer | Ngay trước đó |
|---|---|---|
| 06:37.9 và 06:38.3 | Skipped 33 và 31 frame | 2 `native_small` hiện cách nhau 0,7s, kèm 2 impression; banner AppLovin hiện lúc 38.7 |
| 06:48.6 và 06:49.0 | Skipped 42 và 34 frame | Interstitial AppLovin mở (`AppLovinFullscreenActivity`), GC dừng 36ms lúc 48.4 |
| **07:31.7** | **Skipped 68 frame; Davey 764ms và 849ms** | Vừa đóng interstitial (07:27.5); pool nạp lại 2 native cùng lúc (29.4, 29.5); tạo decoder VP9; game dựng màn prologue |
| 07:43.4 | Skipped 40 frame | Chuyển sang gameplay; `native_bottom` hiện lúc 44.0 |
| 09:28.0 và 09:28.4 | Skipped 32 và 32 frame | Về Home: `native_small` và `native_bottom` hiện cùng lúc. Cả hai "có sẵn trong kho" nhưng mất 902ms / 607ms mới lên |

Frame 764ms kẹt ở `SwapBuffers` (khoảng 735ms): GPU/compositor bị nghẽn, không phải JS chạy lâu.

### 1.2. Những gì log cho thấy

1. **Mỗi lần show native, AdMob dựng thêm một WebView trong cửa sổ riêng.** Mỗi lần có một
   `WindowManagerGlobal#addView ty=2 view=com.google.android.gms.ads.internal.webview.ab` (900×435),
   thường kèm một decoder `c2.mtk.vp9.decoder` của Chromium (`cr_MediaCodecBridge`). Trong 3 phút có
   13 cửa sổ như vậy và 16 decoder VP9. Nhiều màn hiện 2 native trong cùng một khung hình, nên chi
   phí này nhân đôi đúng lúc chuyển màn.
2. **Pool `small` của game xin native video** (unit test `1044960115` = Native Video), nhưng
   template `small` không có `MediaView` (`alf_native_ad_small.xml`). App tải và giải mã video mà
   người dùng không thấy.
3. **Rác Java dồn dập lúc khởi động.** Từ 06:28 đến 06:52 có GC khoảng 2s một lần, mỗi lần dọn
   30–55MB. Sau 07:31 thì GC thưa hẳn (7–30s một lần). Nghi do adapter mediation init và các load
   ad chồng nhau. Chưa chỉ ra được SDK nào; cần Memory Profiler.
4. **`initSDK` mất 14,2s, riêng AppsFlyer chiếm khoảng 10s** (06:31.9 → 06:42.0). MAX và AdMob
   init khoảng 2s. Ads đã chạy từ 06:31 nhờ `InitAdMobEarly`, nên toàn bộ native, banner và video
   load trong lúc người chơi còn ở màn boot.
5. **Đóng interstitial = nạp lại pool + dựng màn mới cùng lúc.** Đây là lần giật nặng nhất.

Log gốc: `scratchpad/device.log` của phiên phân tích (không commit; quá 10MB).

---

## 2. Nguyên nhân trong code SDK (đã kiểm)

| # | Chỗ | Vấn đề |
|---|---|---|
| C1 | `initSDK` ([index.ts:262](../../../sdk/alf/index.ts)) | Mọi bước `await` nối tiếp: MAX → AdMob → AppsFlyer → Firebase → RemoteConfig (mạng) → Storage → IAP → Payment → khoảng 15 controller. Bước chậm nhất chặn tất cả |
| C2 | `WhenStartupStage` ([AdController.ts:233](../../../sdk/alf/controllers/AdController.ts)) | Mốc tính từ lúc AdMob sẵn sàng, không phải từ màn hình đầu. Boot lâu hơn 5s thì mọi stage đã trôi qua và tất cả ad load cùng lúc khi Home hiện |
| C3 | `NativeAdPool.Acquire` ([NativeAdPool.ts:191](../../../sdk/alf/controllers/NativeAdPool.ts)) | Lấy ad ra là gọi `Fill()` ngay: một lượt load mới chạy đúng lúc chuyển màn |
| C4 | `NativeAdPool` | Không giới hạn số load đồng thời giữa các pool; không biết fullscreen ad đang mở hay vừa đóng |
| C5 | SDK (chung) | Không có gì ngăn 2 native được vẽ trong cùng một khung hình |
| C6 | `ALFAdMobPlugin.hideBanner` + preload ẩn ([AdController.ts:745](../../../sdk/alf/controllers/AdController.ts)) | Banner AdMob chỉ `GONE`, không `pause()`, nên vẫn refresh và render WebView. Plugin AdMob không có `handleOnPause`/`handleOnResume` |
| C7 | `ALFAppLovinMAXPlugin` | `new MaxAdView`, `adView.loadAd()`, `showAd()` chạy trên plugin thread của Capacitor, không phải main thread. `loadInterstitial`/`loadAppOpenAd` tạo instance mới mỗi lần, không `destroy()` cái cũ |
| C8 | `updateNativeAdRect` (Android + iOS) | Gọi qua bridge mỗi sự kiện scroll; Android đổi `LayoutParams`, nên cả cây view phải layout lại |
| C9 | `sdk/android/build.gradle` | 10 adapter MAX khai báo version `+`: build không lặp lại được, adapter mới có thể init nặng hơn mà không ai biết |

---

## 3. Thiết kế 3.0.0

### 3.1. Đo trước khi sửa (làm đầu tiên)

- `initSDK` ghi thời gian từng bước, `logger.info('[initSDK] applovin 1840ms')`, và trả thêm
  `status.timings: Record<string, number>`.
- Plugin Android: bọc các method nặng (`showNativeAd`, `renderNativeAd`, `createBanner`, `load*`,
  `show*`) bằng `android.os.Trace.beginSection("ALF.<method>")` để chúng hiện tên trong Perfetto.
- Dev app: bật `StrictMode.ThreadPolicy` `detectAll().penaltyLog()` trong `MainActivity` bản debug.
- `Ads.GetPerfStats()`: số load đang chạy, số native đang hiện, lần show/load gần nhất. Dùng cho
  màn debug của game.

### 3.2. Khởi động (C1, C2)

- **`initSDK` chạy song song** các nhóm không phụ thuộc nhau:
  - Nhóm ads: MAX ∥ AdMob.
  - Nhóm dữ liệu: Firebase/RemoteConfig ∥ Storage ∥ IAP ∥ Payment.
  - Nhóm analytics (AppsFlyer): **không chặn** `initSDK`. Chạy nền, trả `status.appsflyer = 'pending'`
    rồi cập nhật khi xong.
  - Thứ tự bắt buộc giữ nguyên: Firebase Analytics trước, ATT (iOS) trước mọi SDK tracking/ads.
- **Mốc khởi động do app đặt**: `Ads.MarkFirstScreenShown()`. Khi có mốc này, `WhenStartupStage(ms)`
  tính từ đó; khi app không gọi thì giữ hành vi 2.0.0 (tính từ AdMob ready). Pool có `startDelayMs`
  cũng dùng mốc mới.

### 3.3. Lịch hiện ads (C3, C4, C5): phần chính của bản này

Thêm một bộ điều phối trong `AdController`, tạm gọi là `AdScheduler`:

- **Một native mỗi khung hình**: các lệnh `showNativeAd` đến gần nhau được xếp hàng, cách nhau tối
  thiểu `nativeShowGapMs` (mặc định khoảng 300ms, đề xuất). Màn có 2 native thì cái thứ hai lên trễ
  một chút thay vì cả màn đứng hình.
- **Chờ màn mới vẽ xong**: `Ads.WhenScreenSettled()` = 2 lần `requestAnimationFrame` + `idleMs`.
  `Screen.NavigateTo` đánh dấu đang chuyển màn; show/load mới chờ hết chuyển màn.
- **Sau fullscreen ad**: interstitial/rewarded/app open vừa đóng thì hoãn mọi load mới
  `afterFullscreenMs` (đề xuất 1000ms). Trong lúc fullscreen đang mở thì không vẽ native mới.
- **Giới hạn load đồng thời toàn cục**: `maxConcurrentLoads` (đề xuất 2) chung cho mọi pool, banner
  và preload interstitial/rewarded.
- **Pool nạp lại có trễ**: `NativeAdPoolOptions.refillDelayMs` (đề xuất 800ms). `Acquire` không gọi
  `Fill()` ngay mà hẹn giờ, và chỉ load khi scheduler cho phép.
- **Cảnh báo cấu hình phí**: pool có `request.video` thì `Acquire`/show với template không có media
  view (`small`) in `logger.warn` một lần.

Mọi giá trị đều chỉnh được qua `settings.adsPerformance` (hoặc RemoteConfig) để A/B mà không cần
build lại.

### 3.4. Plugin native (C6, C7, C8)

- **AdMob banner**: `hideBanner` → `pause()`, `showBanner` → `resume()`; thêm `handleOnPause` /
  `handleOnResume` cho mọi `AdView` đang hiện. iOS: kiểm tra xem `GADBannerView` có cần tương tự không.
- **MAX**: tạo `MaxAdView` và gọi `loadAd()`/`showAd()` trên main thread. Giữ **một** instance
  `MaxInterstitialAd`/`MaxAppOpenAd` cho mỗi ad unit và gọi lại `loadAd()` (theo hướng dẫn MAX),
  hoặc `destroy()` instance cũ trước khi tạo mới.
- **Rect mode**: Android dùng `setTranslationX/Y` (không phải layout lại) khi chỉ đổi vị trí, chỉ đổi
  `LayoutParams` khi đổi kích thước. JS: `UpdateAdMobNativeAdRect` gộp theo `requestAnimationFrame`
  và bỏ lệnh trùng. iOS: đổi `constant` của constraint, đã nhẹ; chỉ cần gộp phía JS.
- **Cờ tối ưu của Google**: xem doc play-services-ads 25.x về `OPTIMIZE_INITIALIZATION` /
  `OPTIMIZE_AD_LOADING` (mặc định bật chưa, có còn tác dụng không) rồi mới thêm vào manifest.
  ⚠ Không ghi theo trí nhớ, phải xác minh.

### 3.5. Mediation (C9): cần quyết định

- Ghim version cụ thể cho 10 adapter MAX thay cho `+`.
- Cân nhắc bỏ adapter đóng góp ít doanh thu (xem báo cáo MAX theo network). Mỗi adapter là một SDK
  init lúc mở app.
- Xem MAX 13.x có cho chỉ init một số adapter, hoặc init adapter trễ không. ⚠ Xác minh trong doc.

---

## 4. Thay đổi phá vỡ (lý do lên 3.0.0)

| Thay đổi | Ảnh hưởng tới app |
|---|---|
| `initSDK` không còn chờ AppsFlyer; `status.appsflyer` có thể là `'pending'` | App đọc `status.appsflyer === 'ok'` ngay sau `initSDK` phải chuyển sang chờ event |
| Thứ tự init song song | App dựa vào thứ tự ngầm (vd Storage xong trước IAP) cần kiểm lại |
| `showNativeAd` có thể lên trễ (xếp hàng) | Promise resolve muộn hơn vài trăm ms; app không được giả định ad hiện ngay trong cùng frame |
| Pool không nạp lại ngay khi `Acquire` | `Size()` ngay sau `Acquire` nhỏ hơn 2.0.0 trong một khoảng ngắn |

Có cờ `settings.adsPerformance.legacy = true` để quay về hành vi 2.0.0 trong một bản chuyển tiếp.

---

## 5. Việc phía game (không thuộc SDK)

- Bỏ `request.video` ở pool `small`, hoặc đổi sang template có `MediaView`.
- Gọi `Ads.MarkFirstScreenShown()` khi màn đầu tiên đã vẽ, **và** đặt
  `settings.adsPerformance.startupAnchor: 'firstScreen'`. Thiếu cờ này thì stage vẫn tính từ AdMob ready
  như 2.0.0 (C2 chưa được sửa).
- Màn nào có 2 native thì để SDK xếp hàng (3.3), đừng tự `Promise.all` hai lệnh show.

---

## 6. Danh sách file cần sửa

| Lớp | File |
|---|---|
| Init | `sdk/alf/index.ts` (song song, timings, AppsFlyer nền) |
| Controller | `sdk/alf/controllers/AdController.ts` (`AdScheduler`, `MarkFirstScreenShown`, `WhenScreenSettled`, `GetPerfStats`, rAF cho rect) |
| Pool | `sdk/alf/controllers/NativeAdPool.ts` (`refillDelayMs`, xin phép scheduler, cảnh báo video) |
| Screen | `sdk/alf/controllers/ScreenController.ts` (báo bắt đầu/kết thúc chuyển màn) |
| Type / config | `sdk/alf/types/config.types.ts` (`adsPerformance`), `sdk/alf/types/ad.types.ts` |
| Android | `sdk/android/.../admob/ALFAdMobPlugin.java` (pause/resume, translation, Trace), `.../applovin/ALFAppLovinMAXPlugin.java` (main thread, một instance mỗi unit, Trace), `sdk/android/build.gradle` (ghim adapter) |
| iOS | `sdk/ios/Sources/ALFAdMobPlugin.swift` (pause banner nếu cần), `ALFAppLovinMAXPlugin.swift` (một instance mỗi unit) |
| Dev app | `src-dev/android/.../MainActivity.java` (StrictMode debug), màn test hiển thị `GetPerfStats` |
| Doc | `design-note/sdk/dev/controllers/AdController.md`, `design-note/sdk/sdk-guide.md`, `design-note/sdk/dev/native-code-ad.md` |
| Release | `CHANGELOG.md`, bump **3.0.0** (`bin/bump-version.mjs`) |

---

## 7. Thứ tự làm

1. Đo (3.1). Chạy lại game, lưu số liệu gốc: thời gian từng bước init, số lần "Skipped frames",
   `dumpsys gfxinfo` (janky frames %).
2. Việc phía game (mục 5): rẻ nhất, đo lại ngay.
3. `initSDK` song song + AppsFlyer nền + `MarkFirstScreenShown` (3.2).
4. `AdScheduler` + pool `refillDelayMs` (3.3).
5. Plugin native (3.4).
6. Mediation (3.5), sau khi có quyết định.
7. Doc, CHANGELOG, bump 3.0.0.

Mỗi bước đo lại và ghi số vào mục 8.

**Tiến độ 2026-11-03:** bước 1, 3, 4, 5 đã code (chưa build lên máy, chưa đo). Các bước được làm
liền một lượt nên số đo sau đó là tổng hiệu quả, không tách được từng bước; muốn tách thì đo với
`adsPerformance.legacy: true` (≈ 2.0.0) rồi `false`. Mặc định đã chọn theo đề xuất: gap 300ms,
`afterFullscreenMs` 1000, `maxConcurrentLoads` 2, `refillDelayMs` 800, AppsFlyer chạy nền, giữ cờ
`legacy`. Thêm so với thiết kế: `startupAnchor` (`'admob'` mặc định | `'firstScreen'`) vì mốc mới chỉ
có ích khi stage biết phải chờ `MarkFirstScreenShown()`.

---

## 8. Đo và nghiệm thu

Cùng máy (SM-A166P), cùng kịch bản: tắt hẳn app → mở → hết tutorial đầu → về Home. Làm hai lần:
`testAds: true` và **unit thật** (`testAds: false`).

```bash
adb shell dumpsys gfxinfo com.zl.auto.brawl.rogue.clash reset
```
```bash
adb shell dumpsys gfxinfo com.zl.auto.brawl.rogue.clash framestats
```
```bash
adb logcat --pid=$(adb shell pidof com.zl.auto.brawl.rogue.clash) -v threadtime
```

| Chỉ số | 2.0.0 (2026-11-03, test ads) | Mục tiêu 3.0.0 |
|---|---|---|
| `initSDK` tổng | 14,2s | < 5s |
| Số lần "Skipped ≥ 30 frames" trong kịch bản | 8 | ≤ 2 |
| Frame dài nhất (Davey) | 849ms | < 200ms |
| Janky frames % (`gfxinfo`) | chưa đo | đo ở bước 1 |
| Impression native / banner / inter mỗi phiên | đo ở bước 1 | không giảm |

---

## ❓ Cần quyết định

1. Có chấp nhận native thứ hai lên trễ khoảng 300ms để bớt giật không? (3.3)
2. AppsFlyer chạy nền, không chặn `initSDK`: đồng ý? Theo ghi chú hiện tại, analytics/AppsFlyer
   đang hoãn và chỉ ưu tiên doanh thu thật.
3. Bỏ bớt adapter MAX nào? Cần báo cáo doanh thu theo network trước. (3.5)
4. Giữ cờ `legacy` một bản hay bỏ luôn? (mục 4)
