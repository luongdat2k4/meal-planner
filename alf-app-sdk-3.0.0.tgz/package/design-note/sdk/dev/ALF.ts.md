# `ALF.ts` — Singleton Class ALF

## Vai trò

`ALF` là singleton (chỉ có một instance duy nhất trên toàn bộ ứng dụng). Nó chứa **ConfigManager** + tất cả các controller dưới dạng **public property**. Bất cứ đâu trong app, chỉ cần `ALF.Instance` là có thể truy cập mọi chức năng.

## Luồng tạo ALF Singleton

```mermaid
flowchart TD
    A["ALF.Instance<br/><i>static getter</i>"] --> B{_instance exists?}
    B -->|No| C["new ALF()<br/><i>private constructor</i>"]
    B -->|Yes| D["Return _instance"]
    
    C --> C1["this.Config = new ConfigManager()"]
    C1 --> C2["this.Ads = new AdController(this)"]
    C2 --> C3["this.Camera = new CameraController(this)"]
    C3 --> C4["this.Permission = new PermissionController(this)"]
    C4 --> C5["this.Storage = new StorageController(this)"]
    C5 --> C6["this.Firebase = new FirebaseController(this)"]
    C6 --> C7["this.Analytics = new AnalyticsController(this)"]
    C7 --> C8["this.Share = new ShareController(this)"]
    C8 --> C9["this.Media = new MediaController(this)"]
    C9 --> D
    
    D --> E["ALF ready<br/>8 controllers + ConfigManager"]
```

## Danh sách property

| Property | Type | Vai trò |
|---|---|---|
| `Config` | `ConfigManager` | Quản lý config — set từ `initSDK()`, các controller đọc từ đây |
| `Ads` | `AdController` | Quảng cáo banner, interstitial, rewarded |
| `Camera` | `CameraController` | Chụp ảnh, pick từ gallery |
| `Permission` | `PermissionController` | Xin/kiểm tra quyền thiết bị |
| `Storage` | `StorageController` | JSON database local |
| `Firebase` | `FirebaseController` | Firebase Remote Config |
| `Analytics` | `AnalyticsController` | AppsFlyer events |
| `Share` | `ShareController` | Chia sẻ ảnh/text/file |
| `Media` | `MediaController` | Capture element HTML, slideshow video |

---

## ConfigManager — class quản lý cấu hình tập trung

### Luồng hoạt động

```mermaid
flowchart LR
    A["initSDK(config)"] --> B["ConfigManager.set(config)<br/><i>lưu vào memory</i>"]
    B --> C["Controllers"]
    
    C --> D["Config.get('keys.applovin.android.sdkKey')<br/><i>dot notation</i>"]
    C --> E["Config.get('settings.dev')"]
    C --> F["Config.getKeys()<br/><i>shortcut</i>"]
    C --> G["Config.getSettings()<br/><i>shortcut</i>"]
    C --> H["Config.isReady()<br/><i>kiểm tra đã set?</i>"]
```

### Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `set(config)` | `Config` | `void` | Lưu config object vào memory. Gọi từ `initSDK()`. |
| `get(path)` | `string` | `any` | Lấy giá trị theo dot notation, VD: `get('settings.dev')` |
| `getAll()` | — | `Config` | Trả về toàn bộ config object |
| `getSettings()` | — | `Settings` | Shortcut: `get('settings')` |
| `getKeys()` | — | `KeysConfig` | Shortcut: `get('keys')` |
| `isReady()` | — | `boolean` | `true` nếu config đã được set |

---

## ConfigConverter — chuyển JSON → object config

### Luồng convert

```mermaid
flowchart TD
    A["config.json<br/><i>từ repo bất kỳ</i>"] --> B["ConfigConverter.convert(raw, fieldMappings?)"]
    
    B --> C{fieldMappings<br/>có không?}
    
    C -->|Không| D["Dùng thẳng raw<br/>(coi như đã đúng Config)"]
    C -->|Có| E["Khởi tạo result với defaults<br/>{ settings:{dev:false,...}, keys:{} }"]
    
    E --> F["Với mỗi mapping<br/>sourcePath → destPath"]
    F --> G["deepGet(raw, sourcePath)"]
    G --> H{Có giá trị?}
    H -->|Yes| I["deepSet(result, destPath, value)"]
    H -->|No| J["Bỏ qua"]
    I --> F
    J --> F
    
    K["ConfigConverter.convertFromJSON(filePath, mappings?)<br/><i>đọc file + convert</i>"] --> L["readJSONFile(filePath)<br/>→ raw object"]
    L --> B
    
    D --> M["Return Config"]
    F -.->|Đã hết mappings| M
```

### Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `convert(raw, mappings?)` | object, object | `Config` | Map JSON raw → Config chuẩn. Nếu không có mappings thì dùng thẳng. |
| `convertFromJSON(path, mappings?)` | string, object | `Promise<Config>` | Đọc file JSON + convert. |

### Ví dụ mapping

```mermaid
flowchart LR
    A["Repo JSON<br/>{ 'max_sdk_key': 'xxx' }"] 
    A -->|"mapping:{'max_sdk_key':'keys.applovin.android.sdkKey'}"| B["Config<br/>{ keys: { applovin: { android: { sdkKey: 'xxx' } } } }"]
```

---

## Cách dùng trong app

```mermaid
flowchart TD
    A["Vue Component"] --> B["ALF.Instance"]
    B --> C["ALF.Ads.InitBannerAd()<br/><i>hiển thị banner</i>"]
    B --> D["ALF.Camera.Take()<br/><i>chụp ảnh</i>"]
    B --> E["ALF.Share.ShareImage(data)<br/><i>chia sẻ ảnh</i>"]
    B --> F["ALF.Config.get('settings.dev')<br/><i>đọc config bất kỳ đâu</i>"]
```

## Cách dùng ConfigManager trong controller

```mermaid
flowchart TD
    A["AdController.init()"] --> B["this.af.Config.get('keys.applovin.android.sdkKey')"]
    A --> C["this.af.Config.get('keys.applovin.android.banner')"]
    
    D["AnalyticsController.init()"] --> E["this.af.Config.get('keys.appsflyer.devKey')"]
    
    F["Bất kỳ controller"] --> G["this.af.Config.get('settings.dev')<br/><i>kiểm tra chế độ dev</i>"]
    G -->|true| H["Bật debug logging"]
    G -->|false| I["Tắt debug"]
```
