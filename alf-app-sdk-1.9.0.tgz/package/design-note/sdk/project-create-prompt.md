# Project Create Prompt

Copy và sử dụng prompt bên dưới để tạo project mới với Cursor hoặc AI agent.

---

## Prompt

```
Tạo một ứng dụng mobile app với Vue 3, TypeScript, Capacitor.

## Yêu cầu chung

- Sử dụng Vue 3 Composition API (script setup) + TypeScript
- Sử dụng Capacitor để chạy native (Android/iOS)
- Khởi tạo dự án với Vite
- Tất cả code ở trong thư mục src/
- Chi tiết toàn bộ tài liệu, cấu trúc, kiến trúc ứng dụng viết vào thư mục design-note/
- Các phân tích, sơ đồ thực thể, kiến trúc chi tiết đặt trong design-note/dev/

## Cấu trúc thư mục bắt buộc

```

design-note/
  overview.md             — tổng quan ứng dụng, mục đích, đối tượng sử dụng
  monetization.md         — chiến lược kiếm tiền: quảng cáo (AdMob/AppLovin) và IAP

  dev/
    architecture.md       — kiến trúc tổng thể, sơ đồ thành phần
    data-flow.md          — luồng dữ liệu chính giữa các module
    entities.md           — các sơ đồ thực thể entity-relationship, các bảng dữ liệu
    screens.md            — danh sách màn hình, flow điều hướng
    api.md                — REST API endpoints nếu có

```

Ghi chú:
- `overview.md` nằm trực tiếp trong `design-note/` (không trong `dev/`)
- `monetization.md` nằm trực tiếp trong `design-note/` (không trong `dev/`)
- `dev/` chứa các tài liệu kỹ thuật chi tiết

## Sử dụng ALF App SDK

App KHÔNG được tự code các chức năng phổ biến mà phải sử dụng các controller
từ singleton `ALF` của SDK `@alf/app-sdk` (đã được import sẵn trong node_modules).

### Nguyên tắc:

1. App chỉ gọi `ALF.Instance.<Controller>.<method>()` để thực thi chức năng.
2. App KHÔNG viết lại các chức năng: device info, network, camera, file/media access,
   notifications, ads, payment/IAP, storage, permissions, deep link, share.
3. App chỉ tập trung vào UI/UX và business logic riêng.

### Các controller có sẵn:

- **NetworkController**: `alf.Network.isOnline()`, `alf.Network.isWifi()`
- **DeviceController**: `alf.Device.getDeviceId()`, `alf.Device.isTablet()`, `alf.Device.vibrate(style)`
- **StorageController**: `alf.Storage.set(key, value)`, `alf.Storage.get(key)`, `alf.Storage.delete(key)`
- **AppDataController**: `alf.Data.load()`, `alf.Data.set(key, value)`, `alf.Data.completeOnboarding()`, `alf.Data.setLocale(locale)`
- **LocalizationController**: `alf.Localization.setLocale(locale)`, `alf.Localization.getI18n()`
- **FirebaseController**: `alf.Firebase.getRemoteConfigValue(key)`, `alf.Firebase.logEvent(name, params)`
- **AdController**: `alf.Ads.InitBannerAd()`, `alf.Ads.LoadInterstitial()`, `alf.Ads.ShowInterstitial()`, `alf.Ads.LoadRewarded()`, `alf.Ads.ShowRewarded(callback)`
- **AnalyticsController**: `alf.Analytics.logEvent(name, params)`, `alf.Analytics.setCustomerUserId(id)`
- **CameraController**: `alf.Camera.takePicture(options)`, `alf.Camera.getCameraPermission()`
- **MediaController**: `alf.Media.CaptureImage(options)`, `alf.Media.CaptureVideo(options)`, `alf.Media.CreateSlideshow(options)`
- **FileController**: `alf.File.pickFile(options)`, `alf.File.pickMultipleFiles(options)`, `alf.File.pickGalleryImages(options)`
- **ShareController**: `alf.Share.share(options)`, `alf.Share.shareWithOptions(options)`
- **NotificationController**: `alf.Notification.scheduleLocal(options)`, `alf.Notification.requestPermission()`
- **PermissionController**: `alf.Permission.request(type)`, `alf.Permission.RequestTracking()`
- **AuthController**: `alf.Auth.login(token)`, `alf.Auth.logout()`, `alf.Auth.isAuthenticated()`
- **IAPController**: `alf.IAP.getProducts(ids)`, `alf.IAP.purchase(product)`, `alf.IAP.restorePurchases()`
- **PaymentController**: `alf.Payment.processPayment(payment)`, `alf.Payment.requestPayout(amount)`
- **DeepLinkController**: `alf.DeepLink.addListener(callback)`, `alf.DeepLink.getInitialLink()`
- **AppLifecycleController**: `alf.Lifecycle.addStateChangeListener(callback)`

### Khởi tạo trong main.ts:

```typescript
import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import { initSDK, ALF, registerSetupRoutes, SetupFlowProvide, SetupFlow } from '@alf/app-sdk'
import '@alf/app-sdk/style.css'

import App from './App.vue'

async function boot() {
  // 1. Đọc config và init SDK
  const config = { /* settings + keys */ }
  const status = await initSDK(config)

  // 2. Tạo Vue app
  const router = createRouter({ history: createWebHistory(), routes: [...] })
  const app = createApp(App)
  const i18n = ALF.Instance.Localization.getI18n()
  app.use(i18n)
  app.use(router)

  // 3. (Nếu có) Setup flow language/onboarding
  registerSetupRoutes(router, config.settings)
  SetupFlowProvide(app, 'home')
  app.mount('#app')
  SetupFlow({ router, settings: config.settings, targetRoute: 'home' })
}

boot()
```

## Lưu ý khác

- Responsive UI cho mobile (dùng dvh/dvw, flexbox)
- Support dark mode (CSS variables)
- i18n đa ngôn ngữ sử dụng ALF Instance.Localization
- Font chữ mặc định lấy từ config (settings.defaultFont)

```

```

