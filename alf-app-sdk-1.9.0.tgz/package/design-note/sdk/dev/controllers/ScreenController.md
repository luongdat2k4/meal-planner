# ScreenController

**Scope:** Quản lý toàn bộ luồng chuyển màn (navigation) và router.

**Access:** `ALF.Instance.Screen`

---

## 1. Mục đích

`ScreenController` là đầu mối duy nhất để thực hiện mọi thao tác điều hướng trong app. Tất cả code điều hướng (từ ViewModel, Component, service, ...) đều phải thông qua controller này, giúp:

- Tập trung logic chuyển màn tại một chỗ
- Dễ dàng thay đổi animation, hiệu ứng transition
- Lịch sử điều hướng có thể trace được
- Dễ kiểm soát deep link, notification routing

---

## 2. Cách dùng

### 2.1. Đăng ký router

Trước khi dùng, consuming app **phải** gọi `setRouter` ở đầu lifecycle:

```typescript
import router from './router'
import { ALF } from '@alf/app-sdk'

const alf = ALF.Instance
alf.Screen.setRouter(router)
```

Thường được gọi trong `main.ts` ngay sau khi tạo router instance.

### 2.2. Chain Navigation API

API chính là `NavigateTo(screen)` trả về `Navigator` cho phép chọn animation kiểu chain:

```typescript
// ── Basic Directional ────────────────────
ALF.Instance.Screen.NavigateTo('home').swipeLeft()       // trượt từ phải sang
ALF.Instance.Screen.NavigateTo('home').swipeRight()      // trượt từ trái sang
ALF.Instance.Screen.NavigateTo('gameplay').slideUp()     // trượt lên từ dưới
ALF.Instance.Screen.NavigateTo('settings').slideDown()   // trượt xuống từ trên

// ── Depth & Seamless ────────────────────
ALF.Instance.Screen.NavigateTo('onboarding').fade()      // cross-fade
ALF.Instance.Screen.NavigateTo('home').scale()            // phóng to từ center
ALF.Instance.Screen.NavigateTo('home').zoomOut()          // màn cũ thu nhỏ + mờ dần
ALF.Instance.Screen.NavigateTo('home').flipX()            // 3D lật ngang (trục Y)
ALF.Instance.Screen.NavigateTo('home').flipY()            // 3D lật dọc (trục X)

// ── Geometric & Spread ───────────────────
ALF.Instance.Screen.NavigateTo('home').circularReveal()   // lan tỏa hình tròn từ tâm
ALF.Instance.Screen.NavigateTo('home').bottomSheet()      // card nhỏ expand toàn màn

// ── Physics Simulation ───────────────────
ALF.Instance.Screen.NavigateTo('home').pageCurl()         // lật trang sách
ALF.Instance.Screen.NavigateTo('home').cube()             // xoay khối lập phương 3D

// ── No animation ─────────────────────────
ALF.Instance.Screen.NavigateTo('home').none()
```

### 2.3. Tuỳ chỉnh config

Mỗi phương thức animation đều nhận object config:

```typescript
ALF.Instance.Screen.NavigateTo('settings').fade({
  duration: 500,       // ms, mặc định 250
  replace: true,       // thay thế history entry thay vì push
  params: { id: 42 },  // route params
  query: { source: 'menu' },  // query params
})
```

### 2.4. Các animation types

#### Basic Directional

| Animation | Chain method | Mô tả |
|-----------|-------------|-------|
| `swipeLeft` | `.swipeLeft()` | Màn mới trượt từ phải sang trái (default). Màn cũ trượt trái 30%. |
| `swipeRight` | `.swipeRight()` | Màn mới trượt từ trái sang phải. Màn cũ trượt phải 30%. |
| `slideUp` | `.slideUp()` | Màn mới trượt lên từ dưới bottom edge. |
| `slideDown` | `.slideDown()` | Màn mới trượt xuống từ trên top edge. |

#### Depth & Seamless

| Animation | Chain method | Mô tả |
|-----------|-------------|-------|
| `scale` | `.scale()` | Màn mới phóng to từ scale(0.6) lên 1. Giống mở một view từ thumbnail. |
| `fade` | `.fade()` | Cross-fade opacity giữa hai màn. |
| `zoomOut` | `.zoomOut()` | Màn cũ thu nhỏ (1 → 0.8) + mờ dần, màn mới fade in. Thường dùng khi **đóng/dismiss** một màn hình (xem ảnh toàn màn, popup). |
| `flipX` | `.flipX()` | 3D rotateY — lật trang quanh trục Y (ngang). Phù hợp mặt trước-mặt sau (flashcard, thẻ tín dụng). |
| `flipY` | `.flipY()` | 3D rotateX — lật trang quanh trục X (dọc). |

#### Geometric & Spread

| Animation | Chain method | Mô tả |
|-----------|-------------|-------|
| `circularReveal` | `.circularReveal()` | Dùng `clip-path: circle()` — màn mới xuất hiện từ một điểm tròn nhỏ ở tâm, lan tỏa bao phủ toàn bộ. |
| `bottomSheet` | `.bottomSheet()` | Bắt đầu như một thẻ card nhỏ nằm ở nửa dưới (scaleY 0.6 + bo góc), sau đó expand chiếm toàn màn. |

#### Physics Simulation

| Animation | Chain method | Mô tả |
|-----------|-------------|-------|
| `pageCurl` | `.pageCurl()` | Mô phỏng lật trang sách: perspective + rotateY + scale nhẹ. Phù hợp ebook, truyện tranh, sổ tay. |
| `cube` | `.cube()` | 3D cube rotation: màn cũ và mới nằm trên hai mặt khối lập phương, xoay khối để hiển thị mặt mới. Phù hợp onboarding, thư viện media. |

#### Other

| Animation | Chain method | Mô tả |
|-----------|-------------|-------|
| `none` | `.none()` | Chuyển màn tức thì, không animation. |

### 2.5. Lấy thông tin route hiện tại

```typescript
const route = ALF.Instance.Screen.currentRoute
// { name: 'home', path: '/', params: {}, query: {} }
```

### 2.6. Go Back

```typescript
ALF.Instance.Screen.GoBack()
```

---

## 3. Screen Name Registry

`ScreenName` là union type được định nghĩa trong `ScreenRegistry` interface. Consuming app có thể mở rộng registry bằng module augmentation:

```typescript
// Trong dự án của bạn, ví dụ src/types/alf-augment.d.ts
import '@alf/app-sdk'

declare module '@alf/app-sdk' {
  interface ScreenRegistry {
    profile: unknown
    checkout: unknown
    payment: unknown
  }
}
```

Sau đó có thể dùng `NavigateTo('profile')` với đầy đủ type safety.

---

## 4. Áp dụng CSS Transitions trong Vue

Khi `ScreenController` navigate, nó set `data-screen-animation` và `data-screen-duration` trên `<html>`. Layout component đọc các attribute này để chọn prefix transition class cho Vue `<Transition>`.

Cách triển khai trong `AppLayout.vue`:

```vue
<script setup lang="ts">
import { ALF } from '@/alf'

function transitionName(): string {
  const anim = ALF.Instance.Screen.currentAnimation
  const dur = ALF.Instance.Screen.currentDuration
  document.documentElement.style.setProperty('--alf-transition-duration', dur + 'ms')
  return 'alf-' + anim
}
</script>

<template>
  <router-view v-slot="{ Component, route }">
    <Transition :name="transitionName()" mode="out-in">
      <component :is="Component" :key="route.fullPath" />
    </Transition>
  </router-view>
</template>
```

**Quan trọng:**
- `mode="out-in"` đảm bảo màn cũ leave xong thì màn mới mới enter.
- `:key="route.fullPath"` giúp Vue phát hiện route thay đổi và trigger transition.

Quy tắc CSS class name:
- Enter: `.alf-{animation}-enter-from` / `.alf-{animation}-enter-to` / `.alf-{animation}-enter-active`
- Leave: `.alf-{animation}-leave-from` / `.alf-{animation}-leave-to` / `.alf-{animation}-leave-active`

Ví dụ với `fade`:
```css
.alf-fade-enter-from { opacity: 0; }
.alf-fade-enter-to   { opacity: 1; }
.alf-fade-enter-active { transition: opacity var(--alf-transition-duration) ease; }
.alf-fade-leave-from { opacity: 1; }
.alf-fade-leave-to   { opacity: 0; }
.alf-fade-leave-active { transition: opacity calc(var(--alf-transition-duration) * 0.7) ease-in; }
```

CSS tuỳ chỉnh duration qua CSS variable `--alf-transition-duration` (mặc định `250ms`).

---

## 5. Tích hợp với Dev App

`src-dev/main.ts` đã được gắn router vào `ScreenController`:

```typescript
setupDefaultRoutes(settings)
ALF.Instance.Screen.setRouter(router)
```

Và dùng chain API để chuyển màn:

```typescript
ALF.Instance.Screen.NavigateTo(RouteNames.HOME as any).fade()
```

Tham khảo thêm màn test A/B tại `src-dev/views/test-view/ScreenATestView.vue` và `ScreenBTestView.vue` để xem demo tất cả animation types.
