# `FirebaseAnalyticsController` — Firebase Analytics

## Vai trò

Gửi event lên **Firebase Analytics / GA4**. App thường không gọi trực tiếp controller này mà gọi
`ALF.Instance.Analytics.LogEvent()`. Hàm đó gửi event sang đây và sang AppsFlyer.

```ts
ALF.Instance.Analytics.LogEvent('level_complete', { level: 3, use_item: false })
ALF.Instance.FirebaseAnalytics.LogScreenView('home')
ALF.Instance.FirebaseAnalytics.SetUserProperty('favorite_hero', 'archer')
```

Phần native nằm trong `sdk/android/src/main/java/alf/firebase/ALFFirebasePlugin.java`. Plugin JS nằm
ở `sdk/plugins/firebase`. Hiện **chỉ có Android**, trên iOS mọi lời gọi không làm gì và warn một lần.

---

## Vì sao là plugin native trong SDK, không dùng `@capacitor-firebase/analytics`

`cap sync` chỉ đăng ký những plugin nằm trong `dependencies` **của app**. Plugin npm mà SDK phụ thuộc
sẽ bị cài lồng trong `node_modules/@alf/app-sdk/node_modules/`, nên phần JS có trong bundle còn phần
native thì không có trong APK. Lỗi này không báo gì. AppsFlyer và Remote Config đã chết theo đúng
cách này trên AutoBattler. Plugin đặt trong `sdk/android` thì được đăng ký qua `alf-app-sdk`.

## Bản nào được tính

```mermaid
flowchart TD
    A["Manifest SDK:<br/>firebase_analytics_collection_enabled = false"] --> B["initSDK() → FirebaseAnalytics.init()"]
    B --> C{"Web?"}
    C -->|Yes| D["Không gửi — chỉ in console"]
    C -->|No| E{"Android?"}
    E -->|No| F["warn 1 lần — tắt"]
    E -->|Yes| G{"getStatus().available?<br/>(có google-services.json)"}
    G -->|No| H["warn 1 lần — tắt"]
    G -->|Yes| I["setCollectionEnabled(<br/>settings.analyticsEnabled ?? !settings.dev)"]
```

- Thu thập **tắt từ manifest**, nên bản không được tính không gửi được gì, kể cả `first_open` và
  `session_start` mà Firebase tự ghi trước khi JS chạy.
- Firebase **lưu cờ này trên máy**, nên lần khởi động nào `init()` cũng set lại cả `true` lẫn `false`.
- Muốn xem DebugView trên bản phát hành:
  `adb shell setprop debug.firebase.analytics.app <package>`. Event gửi ở debug mode không lọt vào
  báo cáo chính. Tắt bằng `adb shell setprop debug.firebase.analytics.app .none.`

## Event do ai log

| Event | Ai log |
|---|---|
| `first_open`, `session_start`, `user_engagement`, `app_remove` | Firebase tự ghi |
| `ad_impression` của AdMob | Firebase / Google Mobile Ads SDK tự ghi |
| `ad_impression` của AppLovin MAX | `ALFAppLovinMAXPlugin.onAdRevenuePaid` (Java), kèm doanh thu USD và `ad_placement` (placement truyền vào `show*()`) |
| Còn lại | App, qua `Analytics.LogEvent` |

## Tham số chung (1.3.1)

Mọi event đều có thêm `timestamp` (epoch ms phía máy, lúc log) và `app_version`. Hai tham số này
được xếp đầu nên không bị cắt ở trần 25, và app không ghi đè được. App muốn gắn thêm tham số chung
của mình thì gọi `SetDefaultEventParams({...})`. `ad_impression` của MAX tự thêm hai tham số này
ngay trong Java.

## Kiểm tra trước khi gửi

Sai thì **warn một lần cho mỗi lỗi** rồi bỏ hoặc cắt, không throw:

- Tên event/tham số: bắt đầu bằng chữ cái, chỉ gồm `[A-Za-z0-9_]`, ≤40 ký tự, không dùng tiền tố
  `firebase_` / `google_` / `ga_`.
- Tên event Firebase dành riêng (`first_open`, `session_start`, `app_background`, `ad_click`…) bị bỏ.
- Tối đa 25 tham số. Chuỗi ≤100 ký tự. Chỉ nhận string/number/boolean, boolean gửi thành `"true"`/`"false"`.
- User property: tên ≤24 ký tự, giá trị ≤36 ký tự.

## Liên quan

- Tham số custom phải được **đăng ký custom definition** trên GA4 thì mới hiện trong báo cáo.
- Remote Config vẫn đi qua `@capacitor-firebase/remote-config` nên cũng dính lỗi plugin lồng ở trên.
  Việc sửa phần này để đợt sau.
