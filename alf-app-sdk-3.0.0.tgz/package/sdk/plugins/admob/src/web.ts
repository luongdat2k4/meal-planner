import type {
  ALFAdMobPlugin,
  InitializeOptions,
  InitializeResult,
  AdUnitOptions,
  IsReadyResult,
  LoadNativeAdOptions,
  MuteNativeAdVideoOptions,
  NativeAdTargetOptions,
  NativeAdData,
  RewardEvent,
  PluginListenerHandle,
  BannerOptions,
  BannerSizeResult,
  ShowNativeAdOptions,
  UpdateNativeAdRectOptions,
  UpdateNativeAdOverlayOptions,
} from './definitions'

export class ALFAdMobWeb implements ALFAdMobPlugin {
  async initialize(_options: InitializeOptions): Promise<InitializeResult> {
    console.warn('[ALFAdMob] Web: initialize is a no-op')
    return { initialized: false }
  }

  async createBanner(_options: BannerOptions): Promise<BannerSizeResult> {
    console.warn('[ALFAdMob] Web: createBanner is a no-op')
    return { width: 0, height: 0 }
  }

  async showBanner(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: showBanner is a no-op')
  }

  async hideBanner(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: hideBanner is a no-op')
  }

  async destroyBanner(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: destroyBanner is a no-op')
  }

  async loadInterstitial(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: loadInterstitial is a no-op')
  }

  async isInterstitialReady(_options: AdUnitOptions): Promise<IsReadyResult> {
    return { ready: false }
  }

  async showInterstitial(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: showInterstitial is a no-op')
  }

  async loadRewardedAd(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: loadRewardedAd is a no-op')
  }

  async isRewardedAdReady(_options: AdUnitOptions): Promise<IsReadyResult> {
    return { ready: false }
  }

  async showRewardedAd(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: showRewardedAd is a no-op')
  }

  async loadOpenAppAd(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: loadOpenAppAd is a no-op')
  }

  async isOpenAppAdReady(_options: AdUnitOptions): Promise<IsReadyResult> {
    return { ready: false }
  }

  async showOpenAppAd(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: showOpenAppAd is a no-op')
  }

  async loadNativeAd(_options: LoadNativeAdOptions): Promise<NativeAdData> {
    console.warn('[ALFAdMob] Web: loadNativeAd is a no-op')
    return {
      adUnitId: '',
      headline: '',
      body: '',
      callToAction: '',
      iconUrl: '',
      imageUrl: '',
      hasVideoContent: false,
      mediaAspectRatio: 0,
      videoDuration: 0,
      videoCustomControlsEnabled: false,
      price: '',
      store: '',
      starRating: 0,
      advertiser: '',
    }
  }

  async isNativeAdReady(_options: NativeAdTargetOptions): Promise<IsReadyResult> {
    return { ready: false }
  }

  async showNativeAd(_options: ShowNativeAdOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: showNativeAd is a no-op')
  }

  async updateNativeAdRect(_options: UpdateNativeAdRectOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: updateNativeAdRect is a no-op')
  }

  async updateNativeAdOverlay(_options: UpdateNativeAdOverlayOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: updateNativeAdOverlay is a no-op')
  }

  async removeNativeAdOverlay(_options: NativeAdTargetOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: removeNativeAdOverlay is a no-op')
  }

  async hideNativeAd(_options: NativeAdTargetOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: hideNativeAd is a no-op')
  }

  async destroyNativeAd(_options: NativeAdTargetOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: destroyNativeAd is a no-op')
  }

  async playNativeAdVideo(_options: NativeAdTargetOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: playNativeAdVideo is a no-op')
  }

  async pauseNativeAdVideo(_options: NativeAdTargetOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: pauseNativeAdVideo is a no-op')
  }

  async muteNativeAdVideo(_options: MuteNativeAdVideoOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: muteNativeAdVideo is a no-op')
  }

  async reportNativeAdClick(_options: AdUnitOptions): Promise<void> {
    console.warn('[ALFAdMob] Web: reportNativeAdClick is a no-op')
  }

  async addListener(
    _eventName: string,
    _listener: (event: any) => void,
  ): Promise<PluginListenerHandle> {
    return { remove: () => {} }
  }

  async removeAllListeners(): Promise<void> {}
}
