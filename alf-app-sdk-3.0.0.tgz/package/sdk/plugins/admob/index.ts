/**
 * AdMob Capacitor plugin — merged into the ALF SDK.
 *
 * Native code lives in ./android and ./ios. Supports 5 ad types:
 * banner (adaptive/fixed/collapsible), interstitial, rewarded, openApp, and native.
 */
export * from './src'
