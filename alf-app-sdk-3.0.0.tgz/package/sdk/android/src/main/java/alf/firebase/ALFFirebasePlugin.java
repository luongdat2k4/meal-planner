package alf.firebase;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;

import java.util.Iterator;

/**
 * Firebase Analytics, shipped inside the SDK so it is registered through
 * `alf-app-sdk` like the ad plugins. A separate npm plugin would sit nested in
 * the SDK's node_modules, where `cap sync` never registers it.
 *
 * Firebase itself starts from the host app's google-services.json. Without it no
 * FirebaseApp exists, and every method resolves as a no-op with `available: false`.
 *
 * Collection starts disabled (see AndroidManifest.xml); JS turns it on with
 * setCollectionEnabled only for builds that should count.
 */
@CapacitorPlugin(name = "ALFFirebase")
public class ALFFirebasePlugin extends Plugin {

    private static final String TAG = "ALFFirebase";

    // MARK: - Status

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("available", isAvailable(getContext()));
        call.resolve(ret);
    }

    @PluginMethod
    public void setCollectionEnabled(PluginCall call) {
        Boolean enabled = call.getBoolean("enabled");
        if (enabled == null) {
            call.reject("enabled is required");
            return;
        }
        FirebaseAnalytics analytics = analytics(getContext());
        if (analytics != null) analytics.setAnalyticsCollectionEnabled(enabled);
        call.resolve();
    }

    // MARK: - Events

    @PluginMethod
    public void logEvent(PluginCall call) {
        String name = call.getString("name");
        if (name == null || name.isEmpty()) {
            call.reject("name is required");
            return;
        }
        FirebaseAnalytics analytics = analytics(getContext());
        if (analytics != null) analytics.logEvent(name, toBundle(call.getObject("params")));
        call.resolve();
    }

    @PluginMethod
    public void setUserId(PluginCall call) {
        FirebaseAnalytics analytics = analytics(getContext());
        // A null userId clears it.
        if (analytics != null) analytics.setUserId(call.getString("userId"));
        call.resolve();
    }

    @PluginMethod
    public void setUserProperty(PluginCall call) {
        String name = call.getString("name");
        if (name == null || name.isEmpty()) {
            call.reject("name is required");
            return;
        }
        FirebaseAnalytics analytics = analytics(getContext());
        // A null value clears the property.
        if (analytics != null) analytics.setUserProperty(name, call.getString("value"));
        call.resolve();
    }

    // MARK: - Native callers

    /**
     * Log an ad_impression with revenue from native ad callbacks (AppLovin MAX
     * onAdRevenuePaid). Logged here instead of in JS so revenue is not lost when
     * the WebView is busy or the JS side never subscribed.
     */
    public static void logAdImpression(
        Context context,
        String adPlatform,
        String adSource,
        String adFormat,
        String adUnitName,
        double value,
        String currency,
        String adPlacement
    ) {
        FirebaseAnalytics analytics = analytics(context);
        if (analytics == null) return;

        Bundle params = new Bundle();
        params.putString(FirebaseAnalytics.Param.AD_PLATFORM, adPlatform);
        params.putString(FirebaseAnalytics.Param.AD_SOURCE, adSource);
        params.putString(FirebaseAnalytics.Param.AD_FORMAT, adFormat);
        params.putString(FirebaseAnalytics.Param.AD_UNIT_NAME, adUnitName);
        params.putDouble(FirebaseAnalytics.Param.VALUE, value);
        params.putString(FirebaseAnalytics.Param.CURRENCY, currency);
        // Where in the app the ad was shown, as passed to show*(placement).
        if (adPlacement != null && !adPlacement.isEmpty()) params.putString("ad_placement", adPlacement);
        // Same common params FirebaseAnalyticsController adds to JS events.
        params.putLong("timestamp", System.currentTimeMillis());
        String appVersion = appVersion(context);
        if (appVersion != null) params.putString("app_version", appVersion);
        analytics.logEvent(FirebaseAnalytics.Event.AD_IMPRESSION, params);
    }

    private static String appVersion(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return null;
        }
    }

    // MARK: - Helpers

    private static boolean isAvailable(Context context) {
        try {
            return !FirebaseApp.getApps(context).isEmpty();
        } catch (Exception e) {
            Log.w(TAG, "FirebaseApp check failed: " + e.getMessage());
            return false;
        }
    }

    private static FirebaseAnalytics analytics(Context context) {
        if (context == null || !isAvailable(context)) return null;
        return FirebaseAnalytics.getInstance(context);
    }

    /**
     * Firebase params take String, long and double only. Booleans become the
     * strings "true"/"false" so they read as a dimension in GA4 reports.
     */
    private static Bundle toBundle(JSObject params) {
        Bundle bundle = new Bundle();
        if (params == null) return bundle;

        Iterator<String> keys = params.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object value = params.opt(key);
            if (value instanceof String) {
                bundle.putString(key, (String) value);
            } else if (value instanceof Boolean) {
                bundle.putString(key, value.toString());
            } else if (value instanceof Integer || value instanceof Long) {
                bundle.putLong(key, ((Number) value).longValue());
            } else if (value instanceof Number) {
                bundle.putDouble(key, ((Number) value).doubleValue());
            }
        }
        return bundle;
    }
}
