import type { ALFFirebasePlugin, FirebaseStatusResult } from './definitions'

/**
 * Web never sends analytics: web/dev sessions must not count toward the app's
 * numbers. FirebaseAnalyticsController prints events to the console instead.
 */
export class ALFFirebaseWeb implements ALFFirebasePlugin {
  async getStatus(): Promise<FirebaseStatusResult> {
    return { available: false }
  }

  async setCollectionEnabled(): Promise<void> {}

  async logEvent(): Promise<void> {}

  async setUserId(): Promise<void> {}

  async setUserProperty(): Promise<void> {}
}
