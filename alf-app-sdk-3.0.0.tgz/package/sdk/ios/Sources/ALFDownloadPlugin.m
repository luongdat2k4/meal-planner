#import <Capacitor/Capacitor.h>

CAP_PLUGIN(ALFDownloadPlugin, "ALFDownload",
  CAP_PLUGIN_METHOD(downloadToDevice, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(downloadToApp, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(getAppPath, CAPPluginReturnPromise);
  CAP_PLUGIN_METHOD(isAppFileExists, CAPPluginReturnPromise);
)
