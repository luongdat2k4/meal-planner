# `AppLifecycleController` — Vòng đời ứng dụng

## Vai trò

Quản lý trạng thái **background/foreground** của ứng dụng qua **Capacitor App** plugin. Phát tín hiệu để tạm dừng tiến trình nặng, ngắt Websocket, hoặc lưu state tạm thời trước khi OS kill app.

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Bắt đầu lắng nghe lifecycle events |
| `onChange(listener)` | `(AppState) => void` | `() => void` | Subscribe thay đổi state → trả về unsubscribe fn |
| `emit(event)` | `LifecycleEvent` | `void` | Phát lifecycle event thủ công (test/dev) |
| `disconnect()` | — | `void` | Dừng lắng nghe, cleanup |

---

## Luồng

```mermaid
flowchart LR
    A["appStateChange<br/>(isActive=true)"] --> B["_state = 'active'"]
    C["appStateChange<br/>(isActive=false)"] --> D["_state = 'background'"]
    E["pause event"] --> D
    F["resume event"] --> B
    B --> G["notify listeners"]
    D --> G
```

---

## Cấu trúc dữ liệu

```typescript
type AppState = 'active' | 'inactive' | 'background'
type LifecycleEvent = 'pause' | 'resume' | 'background' | 'foreground'
```

## Dependencies

- `@capacitor/app` — plugin native

## Lưu ý

- Kết hợp với `NetworkController`: khi app xuống background + mất mạng → lưu state ngay
- `disconnect()` nên được gọi trong `App.vue` `onUnmounted()` nếu cần
