# Cờ `testAds`: bật lên thì toàn bộ quảng cáo là test

**Ngày:** 2026-10-31 · **SDK hiện tại:** 1.8.0 → dự kiến **1.9.0** · **Trạng thái:** ĐÃ LÀM (1.9.0) — chọn A+B; iOS chỉ có B

Mục tiêu: một cờ trong config. Bật lên thì **mọi** ad SDK hiển thị (AdMob + AppLovin MAX, mọi
format, cả Android lẫn iOS) đều là test ad. Không impression thật nào, không doanh thu giả nào lọt
vào Firebase. Tắt đi thì hành vi giữ nguyên như hiện nay.

---

## 1. Hiện trạng (đã kiểm trong code)

SDK đã có một nửa tính năng này, gắn vào `settings.dev`, qua `AdController.isDevMode()`
([AdController.ts:1156](../../../sdk/alf/controllers/AdController.ts)).

| Chỗ | Đang làm gì khi `dev = true` | Vấn đề |
|---|---|---|
| `getAdMobAdUnitId()` (interstitial / rewarded / openApp) | Trả về unit test của Google | OK |
| `getAdMobNativeAdUnitId()` + `LoadAdMobNativeAd`/`ShowAdMobNativeAd` (dòng 495) | Unit native / native video test theo platform, đè cả `adUnitId` do caller truyền | OK |
| `getAdMobBannerId()` → `LoadBannerAd`, `showBannerAdInternal` bước 1 | **Luôn trả unit thật** ("real unit only, never a test unit") | ❌ Bản dev vẫn gọi banner AdMob thật |
| Banner fallback bước 2 (AppLovin) | Unit MAX thật | ❌ |
| `InitMRECAd`, `LoadInterstitial`/`ShowInterstitial`, `LoadRewardedVideo`/`ShowRewardedVideo`, `LoadAppOpenAd`/`ShowAppOpenAd` | Toàn bộ qua **AppLovin MAX, unit thật** | ❌ Không có xử lý test nào |
| `ALFAppLovinMAXPlugin.onAdRevenuePaid` (Android, iOS tương tự) | Tự log `ad_impression` + revenue lên Firebase | ❌ Test mode mà vẫn log thì bẩn số liệu doanh thu |
| `ALFAppLovinMAX.initialize({ sdkKey })` | Không có tuỳ chọn test device | Không có đường nào bật test MAX |

`settings.dev` còn điều khiển việc khác: AppsFlyer sandbox/debug, RemoteConfig, Firebase Analytics
(`analyticsEnabled` mặc định `!dev`), log level. Vì vậy **không nên** dùng lại `dev` làm công tắc
duy nhất cho ads. Bản tester thường cần "ads test + mọi thứ khác như production".

---

## 2. Thiết kế cờ

```ts
// config.types.ts — Settings
/**
 * Mọi quảng cáo là test ad (AdMob: unit test của Google; MAX: test mode).
 * Mặc định: `dev`. Chỉ đọc lúc initSDK — đổi lúc chạy không có tác dụng.
 * Khi bật, SDK không log ad_impression / revenue lên Firebase.
 */
testAds?: boolean
```

- **Mặc định `testAds = settings.dev`**, giống cách `analyticsEnabled` mặc định `!dev`. Bản dev
  hiện tại vẫn chạy như cũ, nhưng giờ đúng nghĩa (kể cả banner và MAX).
- **Chỉ đọc lúc init.** Test device của MAX phải đăng ký trước `sdk.initialize`. Bật/tắt lúc chạy
  không đáng tin, nên không hỗ trợ. Ghi rõ trong doc.
- `AdController`: đổi `isDevMode()` thành `isTestAds()`:
  `settings.testAds ?? settings.dev === true`. Mọi nhánh test đi qua helper này.
- API công khai: `ALF.Ad.IsTestMode(): boolean`, để app hiện badge "TEST ADS" trong debug menu nếu muốn.
- `initSDK`: khi bật thì `logger.warn('[initSDK] ⚠ TEST ADS ON — không có doanh thu thật')`,
  in cả ở build production (cố ý: tránh lỡ tay phát hành bản test).

---

## 3. AdMob: sửa các lỗ hổng

1. `getAdMobBannerId()`: test mode thì trả `getAdMobTestBannerId(size, collapsible)`. Cần truyền
   `bannerOptions` vào, vì unit test phụ thuộc size/collapsible.
2. `bannerProvider`: test mode thì đặt `'admob-test'` ngay từ bước 1, để Hide/Destroy đi đúng nhánh.
3. Banner fallback bước 2 (AppLovin): test mode thì **bỏ qua** hoặc chỉ chạy khi MAX test mode
   hoạt động (tuỳ quyết định ở mục 4).
4. Rà mọi entry point AdMob nhận `adUnitId` hoặc `slot` từ caller (native slot, openApp): test mode
   thì luôn đè bằng unit test, giống dòng 495 đang làm cho native.
5. (Tuỳ chọn, phòng thủ thêm) Native: `RequestConfiguration.setTestDeviceIds([...])` với hash
   device hiện tại. Không bắt buộc, vì unit test của Google luôn trả test ad.

---

## 4. AppLovin MAX: phần khó, **cần chọn phương án**

MAX **không có** bộ unit ID test công khai như Google. Hiện có hai cách:

### Phương án A: MAX test mode qua test device (giữ nguyên MAX)

- `InitializeOptions` thêm `testMode?: boolean`.
- Native Android: lấy GAID (`AdvertisingIdClient`, chạy ở background thread) rồi
  `AppLovinSdkInitializationConfiguration.builder(...).setTestDeviceAdvertisingIds(List.of(gaid))`
  trước `sdk.initialize`.
- Native iOS: `ALSdkInitializationConfiguration` builder, `testDeviceAdvertisingIdentifiers = [idfa]`.
- ⚠ **Cần xác minh trong doc AppLovin 13.x trước khi code**: đúng tên method, và việc iOS cần IDFA,
  tức là phải xin ATT trước init MAX. Nếu user từ chối ATT thì IDFA toàn số 0, test mode không ăn.
- Ưu: test đúng luồng MAX thật (waterfall, bidding, adapter, mediation debugger).
  Nhược: phụ thuộc GAID/IDFA. Máy tắt Ad ID hoặc iOS chưa cấp ATT thì **không** đảm bảo test ad.
  Cách dự phòng: đăng ký máy test thủ công trên dashboard MAX (Test Mode).

### Phương án B: test mode thì chuyển sang AdMob test unit

- `LoadInterstitial`/`ShowInterstitial`, `LoadRewardedVideo`/`ShowRewardedVideo`,
  `LoadAppOpenAd`/`ShowAppOpenAd` khi test mode thì gọi `ALFAdMob.loadInterstitial` /
  `loadRewardedAd` / `loadOpenAppAd` với unit test của Google. Plugin AdMob đã có đủ API này.
- MREC: dùng AdMob banner `MEDIUM_RECTANGLE` + unit test `bannerFixed`.
- Phải map listener: close / reward / skip của AdMob sang cùng callback mà `ShowInterstitial` /
  `ShowRewardedVideo` đang dùng.
- Ưu: luôn có fill, không phụ thuộc Ad ID / ATT, chắc chắn 100% test.
  Nhược: không test được luồng MAX thật. Phải thêm nhánh code cho mỗi format.

### Đề xuất

**A làm chính, B làm lưới an toàn**: test mode thì init MAX với test device. Nếu không lấy được Ad ID
(GAID null / IDFA toàn 0) thì log warn và chuyển các format MAX sang nhánh B. Nếu muốn gọn cho bản
đầu thì **chỉ làm B** (chắc chắn, ít phụ thuộc native), A để sau.

---

## 5. Chặn doanh thu giả

Liên quan memory "AutoBattler: chỉ cần doanh thu thật": số liệu doanh thu không được lẫn test.

- `ALFAppLovinMAXPlugin` (Android + iOS): `initialize` nhận `testMode`. Khi bật thì
  `onAdRevenuePaid` **không** gọi `ALFFirebasePlugin.logAdImpression`.
- JS: event `paid` (native + interstitial AdMob) thêm field `isTest: true` khi test mode, để
  `AdsService` của app bỏ qua khi gửi đi đâu đó.
- AdMob test unit trả revenue = 0, nhưng Firebase tự log `ad_impression` của AdMob khi đã link.
  Ghi chú trong doc: build test nên để `analyticsEnabled: false`, hoặc chấp nhận vài impression
  0 USD.

---

## 6. Danh sách file cần sửa

| Lớp | File |
|---|---|
| Type / config | `sdk/alf/types/config.types.ts` (`testAds`), `sdk/alf/types/ad.types.ts` (`isTest` trên event paid) |
| Controller | `sdk/alf/controllers/AdController.ts` (`isTestAds`, banner, MAX nhánh A/B, `IsTestMode`) |
| Init | `sdk/alf/index.ts` (warn khi bật) |
| Plugin TS | `sdk/plugins/applovin/src/definitions.ts` + `web.ts` (`testMode` trong `InitializeOptions`) |
| Android | `sdk/android/.../applovin/ALFAppLovinMAXPlugin.java` (test device, chặn log revenue) |
| iOS | `sdk/ios/Sources/ALFAppLovinMAXPlugin.swift` (như trên) |
| Doc | `design-note/sdk/dev/config.md`, `design-note/sdk/dev/controllers/AdController.md`, `design-note/sdk/sdk-guide.md` |
| Release | `CHANGELOG.md`, bump **1.9.0** (`bin/bump-version.mjs`) |

---

## 7. Thứ tự làm

1. Type + `isTestAds()` + đổi mọi `isDevMode()` trong AdController. Không đổi hành vi khi `testAds` không set.
2. Sửa banner AdMob (mục 3.1–3.3).
3. MAX theo phương án đã chọn (mục 4).
4. Chặn revenue native + `isTest` trên `paid` (mục 5).
5. `IsTestMode()`, warn lúc init, doc, CHANGELOG, bump version.
6. Kiểm thử trên `src-dev` (mục 8).

---

## 8. Kiểm thử

Chạy `src-dev` với `testAds: true` và `dev: false` (giả lập bản tester), trên cả Android và iOS:

| Format | Cách xác nhận là test ad |
|---|---|
| Banner / collapsible / native / native video / app open AdMob | Có nhãn "Test Ad" của Google; logcat/Xcode in unit `ca-app-pub-3940256099942544/...` |
| Interstitial / rewarded / app open / MREC / banner MAX | A: MAX Mediation Debugger báo test mode, creative có nhãn test. B: nhãn "Test Ad" của Google |
| Revenue | Firebase DebugView: không có `ad_impression` từ `appLovin` |
| Tắt cờ (`testAds: false`, `dev: false`) | Log unit thật. Hành vi giống 1.8.0 (regression) |
| `dev: true`, không set `testAds` | Test ads bật (giữ hành vi mặc định cũ) |

---

## ❓ Cần quyết định

1. **MAX: phương án A, B hay A+B?** (mục 4). Đề xuất: A+B, hoặc chỉ B cho bản đầu.
2. Có giữ mặc định `testAds = dev` không, hay bắt buộc set tay?
3. Bước 3 của banner fallback hiện nay (hết fill thì hiện **banner test** ở production) có nên bỏ
   luôn không? Hiển thị test ad trên bản production không ra tiền và trông lạ với user.
