package alf.applovin;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.MaxReward;
import com.applovin.mediation.MaxRewardedAdListener;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxAppOpenAd;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.mediation.ads.MaxRewardedAd;
import com.applovin.sdk.AppLovinMediationProvider;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkInitializationConfiguration;
import com.applovin.sdk.AppLovinSdkUtils;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import com.google.android.gms.ads.identifier.AdvertisingIdClient;

import alf.firebase.ALFFirebasePlugin;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "ALFAppLovinMAX")
public class ALFAppLovinMAXPlugin extends Plugin {

    private static final String TAG = "ALFAppLovinMAX";

    private AppLovinSdk sdk;
    private boolean isSdkInitialized = false;
    // initialize({ testMode: true }) — every ad is a test ad; revenue is not logged
    private boolean testMode = false;
    // This device's advertising ID was handed to MAX as a test device
    private boolean testDeviceRegistered = false;

    private final Map<String, MaxAdView> banners = new HashMap<>();
    private final Map<String, MaxAdView> mrecs = new HashMap<>();
    private final Map<String, MaxInterstitialAd> interstitials = new HashMap<>();
    private final Map<String, MaxRewardedAd> rewardedAds = new HashMap<>();
    private final Map<String, Boolean> rewardedGranted = new HashMap<>();
    private final Map<String, MaxAppOpenAd> appOpenAds = new HashMap<>();

    // Hidden banners stop auto-refresh: a GONE MaxAdView keeps loading a new ad
    // every refresh cycle (network + an HTML WebView render) that nobody sees.
    // Both sets are touched on the UI thread only.
    //   bannersLoaded        — first load done. Refresh is never paused before
    //                          that, so a banner hidden while still loading
    //                          still delivers its first onAdLoaded.
    //   bannersRefreshPaused — stopAutoRefresh() was called and not undone.
    private final Set<MaxAdView> bannersLoaded = new HashSet<>();
    private final Set<MaxAdView> bannersRefreshPaused = new HashSet<>();

    // MARK: - Revenue

    // MAX impressions never reach Firebase on their own (only AdMob's do), so
    // every MAX ad logs its own ad_impression. Revenue is always USD on MAX.
    // `ad.getPlacement()` is the placement passed to show*() (see placementOf),
    // so each impression says where in the app it came from.
    // Test mode logs nothing: test impressions must not count as revenue.
    private void onAdRevenuePaid(MaxAd ad) {
        if (testMode) return;
        ALFFirebasePlugin.logAdImpression(
            getContext(),
            "appLovin",
            ad.getNetworkName(),
            ad.getFormat().getLabel(),
            ad.getAdUnitId(),
            ad.getRevenue(),
            "USD",
            ad.getPlacement()
        );
    }

    // Optional `placement` of a show*() call: where in the app the ad is shown
    // (e.g. "level_revive"). Null when the caller did not pass one.
    private static String placementOf(PluginCall call) {
        String placement = call.getString("placement");
        return placement == null || placement.isEmpty() ? null : placement;
    }

    // MARK: - Initialize

    @PluginMethod
    public void initialize(PluginCall call) {
        String sdkKey = call.getString("sdkKey");
        if (sdkKey == null || sdkKey.isEmpty()) {
            call.reject("sdkKey is required");
            return;
        }

        if (isSdkInitialized) {
            call.resolve(initializationMessage());
            return;
        }

        testMode = Boolean.TRUE.equals(call.getBoolean("testMode", false));
        if (!testMode) {
            startSdk(call, sdkKey, null);
            return;
        }
        // Reading the advertising ID blocks, so it must stay off the main thread.
        new Thread(() -> {
            String adId = readAdvertisingId();
            new Handler(Looper.getMainLooper()).post(() -> startSdk(call, sdkKey, adId));
        }).start();
    }

    // Test devices must be set before initialize — MAX reads them only then.
    private void startSdk(PluginCall call, String sdkKey, String testAdId) {
        sdk = AppLovinSdk.getInstance(getContext());

        AppLovinSdkInitializationConfiguration.Builder builder =
            AppLovinSdkInitializationConfiguration.builder(sdkKey, getContext())
                .setMediationProvider(AppLovinMediationProvider.MAX);
        if (testAdId != null) {
            builder.setTestDeviceAdvertisingIds(Collections.singletonList(testAdId));
            testDeviceRegistered = true;
        }

        sdk.initialize(builder.build(), configuration -> {
            isSdkInitialized = true;
            call.resolve(initializationMessage());
        });
    }

    // This device's advertising ID, or null when it is unavailable or zeroed
    // (Ad ID turned off / limit ad tracking) — then MAX cannot match a test device.
    private String readAdvertisingId() {
        try {
            AdvertisingIdClient.Info info = AdvertisingIdClient.getAdvertisingIdInfo(getContext());
            String id = info.getId();
            if (info.isLimitAdTrackingEnabled() || id == null || id.isEmpty()
                    || id.equals("00000000-0000-0000-0000-000000000000")) {
                Log.w(TAG, "Advertising ID unavailable — MAX test mode off");
                return null;
            }
            return id;
        } catch (Exception e) {
            Log.w(TAG, "Advertising ID read failed — MAX test mode off", e);
            return null;
        }
    }

    private JSObject initializationMessage() {
        JSObject ret = new JSObject();
        ret.put("initialized", true);
        ret.put("isTablet", AppLovinSdkUtils.isTablet(getContext()));
        ret.put("testDevice", testDeviceRegistered);
        return ret;
    }

    private boolean requireSdk(PluginCall call) {
        if (sdk == null || !isSdkInitialized) {
            call.reject("AppLovin MAX SDK not initialized. Call initialize() first.");
            return false;
        }
        return true;
    }

    @PluginMethod
    public void isTablet(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("isTablet", AppLovinSdkUtils.isTablet(getContext()));
        call.resolve(ret);
    }

    // MARK: - Banner

    @PluginMethod
    public void createBanner(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        if (adUnitId == null || adUnitId.isEmpty()) {
            call.reject("adUnitId is required");
            return;
        }
        if (!requireSdk(call)) return;

        String position = call.getString("position", "BOTTOM_CENTER");

        MaxAdView existing = banners.remove(adUnitId);
        if (existing != null) {
            getActivity().runOnUiThread(() -> {
                removeFromContainer(existing);
                forgetBannerRefreshState(existing);
            });
        }

        MaxAdView adView = new MaxAdView(adUnitId, sdk, getContext());
        // Without this, stopAutoRefresh() only takes effect after the current
        // refresh cycle. Must be set before loadAd().
        adView.setExtraParameter("allow_pause_auto_refresh_immediately", "true");
        AtomicBoolean loadCallCompleted = new AtomicBoolean(false);
        adView.setRevenueListener(this::onAdRevenuePaid);
        adView.setListener(new MaxAdViewAdListener() {
            @Override public void onAdLoaded(MaxAd ad) {
                bannersLoaded.add(adView);
                // Hidden before its first load finished: pause now.
                if (adView.getVisibility() != View.VISIBLE) pauseBannerRefresh(adView);
                if (loadCallCompleted.compareAndSet(false, true)) call.resolve();
            }
            @Override public void onAdLoadFailed(String adUnitId, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "Banner failed to load: " + error.getMessage());
                if (loadCallCompleted.compareAndSet(false, true)) {
                    call.reject(loadErrorMessage("Banner", adUnitId, error));
                }
            }
            @Override public void onAdDisplayed(MaxAd ad) {}
            @Override public void onAdHidden(MaxAd ad) {}
            @Override public void onAdClicked(MaxAd ad) {}
            @Override public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "Banner display failed: " + error.getMessage());
            }
            @Override public void onAdExpanded(MaxAd ad) {}
            @Override public void onAdCollapsed(MaxAd ad) {}
        });

        int heightPx = (int) (50 * getContext().getResources().getDisplayMetrics().density);
        if (AppLovinSdkUtils.isTablet(getContext())) {
            heightPx = (int) (90 * getContext().getResources().getDisplayMetrics().density);
        }

        final boolean bottom = position.equals("BOTTOM_CENTER");
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            heightPx
        );
        params.gravity = bottom ? Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL : Gravity.TOP | Gravity.CENTER_HORIZONTAL;

        getActivity().runOnUiThread(() -> {
            getAdContainer().addView(adView, params);
            if (bottom) applyBottomInset(adView);
        });

        adView.loadAd();
        banners.put(adUnitId, adView);
    }

    @PluginMethod
    public void showBanner(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxAdView adView = banners.get(adUnitId);
        if (adView == null) {
            call.reject("Banner not found");
            return;
        }
        String placement = placementOf(call);
        if (placement != null) adView.setPlacement(placement);
        getBridge().getWebView().post(() -> {
            resumeBannerRefresh(adView);
            adView.setVisibility(android.view.View.VISIBLE);
        });
        call.resolve();
    }

    @PluginMethod
    public void hideBanner(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxAdView adView = banners.get(adUnitId);
        if (adView == null) {
            call.reject("Banner not found");
            return;
        }
        getBridge().getWebView().post(() -> {
            adView.setVisibility(android.view.View.GONE);
            // Still on its first load: onAdLoaded pauses it instead.
            if (bannersLoaded.contains(adView)) pauseBannerRefresh(adView);
        });
        call.resolve();
    }

    @PluginMethod
    public void destroyBanner(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxAdView adView = banners.remove(adUnitId);
        if (adView == null) {
            call.reject("Banner not found");
            return;
        }
        getActivity().runOnUiThread(() -> {
            removeFromContainer(adView);
            forgetBannerRefreshState(adView);
            adView.destroy();
        });
        call.resolve();
    }

    // UI thread only (see bannersLoaded).
    private void pauseBannerRefresh(MaxAdView adView) {
        if (bannersRefreshPaused.add(adView)) adView.stopAutoRefresh();
    }

    private void resumeBannerRefresh(MaxAdView adView) {
        if (bannersRefreshPaused.remove(adView)) adView.startAutoRefresh();
    }

    private void forgetBannerRefreshState(MaxAdView adView) {
        bannersLoaded.remove(adView);
        bannersRefreshPaused.remove(adView);
    }

    // MARK: - MREC

    @PluginMethod
    public void createMRec(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        if (adUnitId == null || adUnitId.isEmpty()) {
            call.reject("adUnitId is required");
            return;
        }
        if (!requireSdk(call)) return;

        String position = call.getString("position", "TOP_CENTER");
        // Optional: put the MREC inside an area of the page instead of anchoring
        // it to a screen edge. Takes precedence over `position`.
        final JSObject rect = call.getObject("rect");

        MaxAdView existing = mrecs.remove(adUnitId);
        if (existing != null) {
            getActivity().runOnUiThread(() -> removeFromContainer(existing));
        }

        MaxAdView adView = new MaxAdView(adUnitId, com.applovin.mediation.MaxAdFormat.MREC, sdk, getContext());
        AtomicBoolean loadCallCompleted = new AtomicBoolean(false);
        adView.setRevenueListener(this::onAdRevenuePaid);
        adView.setListener(new MaxAdViewAdListener() {
            @Override public void onAdLoaded(MaxAd ad) {
                if (loadCallCompleted.compareAndSet(false, true)) call.resolve();
            }
            @Override public void onAdLoadFailed(String adUnitId, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "MREC failed to load: " + error.getMessage());
                if (loadCallCompleted.compareAndSet(false, true)) {
                    call.reject(loadErrorMessage("MREC", adUnitId, error));
                }
            }
            @Override public void onAdDisplayed(MaxAd ad) {}
            @Override public void onAdHidden(MaxAd ad) {}
            @Override public void onAdClicked(MaxAd ad) {}
            @Override public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "MREC display failed: " + error.getMessage());
            }
            @Override public void onAdExpanded(MaxAd ad) {}
            @Override public void onAdCollapsed(MaxAd ad) {}
        });

        FrameLayout.LayoutParams params;
        if (rect != null) {
            params = mrecRectLayoutParams(rect);
        } else {
            int widthPx = (int) (MREC_WIDTH_DP * density());
            int heightPx = (int) (MREC_HEIGHT_DP * density());
            params = new FrameLayout.LayoutParams(widthPx, heightPx);
            params.gravity = gravityForMRecPosition(position);
        }

        final FrameLayout.LayoutParams layout = params;
        getActivity().runOnUiThread(() -> {
            getAdContainer().addView(adView, layout);
            if (rect == null && isBottomMRecPosition(position)) applyBottomInset(adView);
        });

        adView.loadAd();
        mrecs.put(adUnitId, adView);
    }

    /** Move an MREC created with `rect` — call when its area of the page moves. */
    @PluginMethod
    public void updateMRecRect(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxAdView adView = mrecs.get(adUnitId);
        if (adView == null) {
            call.reject("MREC not found");
            return;
        }
        JSObject rect = call.getObject("rect");
        if (rect == null) {
            call.reject("rect is required");
            return;
        }
        final FrameLayout.LayoutParams params = mrecRectLayoutParams(rect);
        getActivity().runOnUiThread(() -> adView.setLayoutParams(params));
        call.resolve();
    }

    @PluginMethod
    public void showMRec(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxAdView adView = mrecs.get(adUnitId);
        if (adView == null) {
            call.reject("MREC not found");
            return;
        }
        String placement = placementOf(call);
        if (placement != null) adView.setPlacement(placement);
        getBridge().getWebView().post(() -> adView.setVisibility(android.view.View.VISIBLE));
        call.resolve();
    }

    @PluginMethod
    public void hideMRec(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxAdView adView = mrecs.get(adUnitId);
        if (adView == null) {
            call.reject("MREC not found");
            return;
        }
        getBridge().getWebView().post(() -> adView.setVisibility(android.view.View.GONE));
        call.resolve();
    }

    @PluginMethod
    public void destroyMRec(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxAdView adView = mrecs.remove(adUnitId);
        if (adView == null) {
            call.reject("MREC not found");
            return;
        }
        getActivity().runOnUiThread(() -> {
            removeFromContainer(adView);
            adView.destroy();
        });
        call.resolve();
    }

    // MARK: - Interstitial

    @PluginMethod
    public void loadInterstitial(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        if (adUnitId == null || adUnitId.isEmpty()) {
            call.reject("adUnitId is required");
            return;
        }
        if (!requireSdk(call)) return;

        MaxInterstitialAd interstitial = new MaxInterstitialAd(adUnitId, sdk, getContext());
        AtomicBoolean loadCallCompleted = new AtomicBoolean(false);
        interstitial.setRevenueListener(this::onAdRevenuePaid);
        interstitial.setListener(new MaxAdViewAdListener() {
            @Override public void onAdLoaded(MaxAd ad) {
                if (loadCallCompleted.compareAndSet(false, true)) call.resolve();
            }
            @Override public void onAdLoadFailed(String adUnitId, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "Interstitial failed to load: " + error.getMessage());
                if (loadCallCompleted.compareAndSet(false, true)) {
                    call.reject(loadErrorMessage("Interstitial", adUnitId, error));
                }
            }
            @Override public void onAdDisplayed(MaxAd ad) {}
            @Override public void onAdHidden(MaxAd ad) {
                JSObject data = new JSObject();
                data.put("adUnitId", ad.getAdUnitId());
                notifyListeners("OnInterstitialAdHiddenEvent", data);
            }
            @Override public void onAdClicked(MaxAd ad) {}
            @Override public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "Interstitial display failed: " + error.getMessage());
            }
            @Override public void onAdExpanded(MaxAd ad) {}
            @Override public void onAdCollapsed(MaxAd ad) {}
        });

        interstitials.put(adUnitId, interstitial);
        interstitial.loadAd();
    }

    @PluginMethod
    public void isInterstitialReady(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        if (adUnitId == null) {
            call.reject("adUnitId is required");
            return;
        }
        MaxInterstitialAd interstitial = interstitials.get(adUnitId);
        boolean ready = interstitial != null && interstitial.isReady();
        JSObject ret = new JSObject();
        ret.put("ready", ready);
        call.resolve(ret);
    }

    @PluginMethod
    public void showInterstitial(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxInterstitialAd interstitial = interstitials.get(adUnitId);
        if (interstitial == null || !interstitial.isReady()) {
            call.reject("Interstitial ad is not ready");
            return;
        }
        interstitial.showAd(placementOf(call));
        call.resolve();
    }

    // MARK: - Rewarded

    @PluginMethod
    public void loadRewardedAd(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        if (adUnitId == null || adUnitId.isEmpty()) {
            call.reject("adUnitId is required");
            return;
        }
        if (!requireSdk(call)) return;

        MaxRewardedAd rewarded = MaxRewardedAd.getInstance(adUnitId, sdk, getContext());
        AtomicBoolean loadCallCompleted = new AtomicBoolean(false);
        rewarded.setRevenueListener(this::onAdRevenuePaid);
        rewarded.setListener(new MaxRewardedAdListener() {
            @Override public void onUserRewarded(MaxAd ad, MaxReward reward) {
                rewardedGranted.put(adUnitId, true);
                JSObject data = new JSObject();
                data.put("adUnitId", ad.getAdUnitId());
                data.put("amount", reward.getAmount());
                notifyListeners("OnRewardedAdReceivedRewardEvent", data);
            }
            @Override public void onAdLoaded(MaxAd ad) {
                rewardedGranted.put(adUnitId, false);
                if (loadCallCompleted.compareAndSet(false, true)) call.resolve();
            }
            @Override public void onAdLoadFailed(String adUnitId, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "Rewarded failed to load: " + error.getMessage());
                if (loadCallCompleted.compareAndSet(false, true)) {
                    call.reject(loadErrorMessage("Rewarded", adUnitId, error));
                }
            }
            @Override public void onAdDisplayed(MaxAd ad) {}
            @Override public void onAdHidden(MaxAd ad) {
                JSObject data = new JSObject();
                data.put("adUnitId", ad.getAdUnitId());
                notifyListeners("OnRewardedAdHiddenEvent", data);

                Boolean granted = rewardedGranted.get(adUnitId);
                if (granted == null || !granted) {
                    notifyListeners("OnRewardedAdSkippedEvent", data);
                }
            }
            @Override public void onAdClicked(MaxAd ad) {}
            @Override public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "Rewarded display failed: " + error.getMessage());
            }
        });

        rewardedAds.put(adUnitId, rewarded);
        rewarded.loadAd();
    }

    @PluginMethod
    public void isRewardedAdReady(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        if (adUnitId == null) {
            call.reject("adUnitId is required");
            return;
        }
        MaxRewardedAd rewarded = rewardedAds.get(adUnitId);
        boolean ready = rewarded != null && rewarded.isReady();
        JSObject ret = new JSObject();
        ret.put("ready", ready);
        call.resolve(ret);
    }

    @PluginMethod
    public void showRewardedAd(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxRewardedAd rewarded = rewardedAds.get(adUnitId);
        if (rewarded == null || !rewarded.isReady()) {
            call.reject("Rewarded ad is not ready");
            return;
        }
        rewarded.showAd(placementOf(call));
        call.resolve();
    }

    // MARK: - App Open

    @PluginMethod
    public void loadAppOpenAd(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        if (adUnitId == null || adUnitId.isEmpty()) {
            call.reject("adUnitId is required");
            return;
        }
        if (!requireSdk(call)) return;

        MaxAppOpenAd appOpenAd = new MaxAppOpenAd(adUnitId, sdk);
        AtomicBoolean loadCallCompleted = new AtomicBoolean(false);
        appOpenAd.setRevenueListener(this::onAdRevenuePaid);
        appOpenAd.setListener(new MaxAdListener() {
            @Override public void onAdLoaded(MaxAd ad) {
                if (loadCallCompleted.compareAndSet(false, true)) call.resolve();
            }
            @Override public void onAdLoadFailed(String adUnitId, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "App open failed to load: " + error.getMessage());
                if (loadCallCompleted.compareAndSet(false, true)) {
                    call.reject(loadErrorMessage("AppOpen", adUnitId, error));
                }
            }
            @Override public void onAdDisplayed(MaxAd ad) {}
            @Override public void onAdHidden(MaxAd ad) {
                JSObject data = new JSObject();
                data.put("adUnitId", ad.getAdUnitId());
                notifyListeners("OnAppOpenAdHiddenEvent", data);
            }
            @Override public void onAdClicked(MaxAd ad) {}
            @Override public void onAdDisplayFailed(MaxAd ad, MaxError error) {
                android.util.Log.e("ALFAppLovinMAX", "App open display failed: " + error.getMessage());
            }
        });

        appOpenAds.put(adUnitId, appOpenAd);
        appOpenAd.loadAd();
    }

    @PluginMethod
    public void isAppOpenAdReady(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        if (adUnitId == null) {
            call.reject("adUnitId is required");
            return;
        }
        MaxAppOpenAd appOpenAd = appOpenAds.get(adUnitId);
        boolean ready = appOpenAd != null && appOpenAd.isReady();
        JSObject ret = new JSObject();
        ret.put("ready", ready);
        call.resolve(ret);
    }

    @PluginMethod
    public void showAppOpenAd(PluginCall call) {
        String adUnitId = call.getString("adUnitId");
        MaxAppOpenAd appOpenAd = appOpenAds.get(adUnitId);
        if (appOpenAd == null || !appOpenAd.isReady()) {
            call.reject("App open ad is not ready");
            return;
        }
        appOpenAd.showAd(placementOf(call));
        call.resolve();
    }

    private String loadErrorMessage(String format, String adUnitId, MaxError error) {
        return format + " failed to load (adUnitId=" + adUnitId
            + ", code=" + error.getCode() + "): " + error.getMessage();
    }

    // Maps MREC position names to FrameLayout gravity flags.
    private int gravityForMRecPosition(String position) {
        switch (position) {
            case "TOP_LEFT":
                return Gravity.TOP | Gravity.START;
            case "TOP_CENTER":
                return Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            case "TOP_RIGHT":
                return Gravity.TOP | Gravity.END;
            case "CENTER":
                return Gravity.CENTER;
            case "BOTTOM_LEFT":
                return Gravity.BOTTOM | Gravity.START;
            case "BOTTOM_RIGHT":
                return Gravity.BOTTOM | Gravity.END;
            case "BOTTOM_CENTER":
            default:
                return Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        }
    }

    private static final int MREC_WIDTH_DP = 300;
    private static final int MREC_HEIGHT_DP = 250;

    /**
     * An MREC is always 300x250dp. `rect` (CSS px of the web view, as from
     * getBoundingClientRect()) is the area to put it in: the ad is centred in it,
     * never stretched — a larger or smaller rect only moves it.
     */
    private FrameLayout.LayoutParams mrecRectLayoutParams(JSObject rect) {
        float d = density();
        float x = (float) rect.optDouble("x", 0d);
        float y = (float) rect.optDouble("y", 0d);
        float w = (float) rect.optDouble("width", MREC_WIDTH_DP);
        float h = (float) rect.optDouble("height", MREC_HEIGHT_DP);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
            Math.round(MREC_WIDTH_DP * d), Math.round(MREC_HEIGHT_DP * d));
        params.gravity = Gravity.TOP | Gravity.START;
        params.leftMargin = Math.round((x + (w - MREC_WIDTH_DP) / 2f) * d);
        params.topMargin = Math.round((y + (h - MREC_HEIGHT_DP) / 2f) * d);
        return params;
    }

    private float density() {
        return getContext().getResources().getDisplayMetrics().density;
    }

    // True when the ad is anchored to the bottom of the screen.
    private boolean isBottomMRecPosition(String position) {
        return "BOTTOM_CENTER".equals(position)
            || "BOTTOM_LEFT".equals(position)
            || "BOTTOM_RIGHT".equals(position);
    }

    // Native ad views must be added to the window content FrameLayout, NOT the WebView.
    // The Capacitor WebView is AbsoluteLayout-derived and ignores FrameLayout gravity,
    // which made banners/MRECs always render at the top regardless of position.
    private FrameLayout getAdContainer() {
        return (FrameLayout) getActivity().findViewById(android.R.id.content);
    }

    private void removeFromContainer(View view) {
        ViewGroup parent = (ViewGroup) view.getParent();
        if (parent != null) parent.removeView(view);
    }

    // Keeps bottom-anchored ads above the navigation bar on edge-to-edge Android 15+.
    private void applyBottomInset(final View view) {
        view.setOnApplyWindowInsetsListener((v, insets) -> {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
            if (lp != null) {
                lp.bottomMargin = insets.getSystemWindowInsetBottom();
                v.setLayoutParams(lp);
            }
            return insets;
        });
        view.requestApplyInsets();
    }
}
