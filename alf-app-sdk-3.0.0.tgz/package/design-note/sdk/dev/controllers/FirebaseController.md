# `FirebaseController` — Firebase Remote Config

## Vai trò

Quản lý kết nối với **Firebase Remote Config** (`@capacitor-firebase/remote-config`). Lấy cấu hình từ server (A/B testing, feature flag). Không có SDK riêng cần init — chỉ fetch dữ liệu.

---

## Luồng Init

```mermaid
flowchart TD
    A["init()"] --> B["TRY: FirebaseRemoteConfig.fetchAndActivate()"]
    B --> C{"Thành công?"}
    C -->|Yes| D["Config mới được fetch + kích hoạt"]
    C -->|No| E["LOG error<br/>(non-fatal — app vẫn chạy)"]
```

## Luồng GetRemoteValue

```mermaid
flowchart TD
    A["GetRemoteValue(key)"] --> B{"remoteConfig.has(key)<br/>(cache trong session)?"}
    B -->|Yes| C["Return cached value"]
    B -->|No| D["TRY: FirebaseRemoteConfig.getValue({ key })"]
    
    D --> E{"Thành công?"}
    E -->|No| F["LOG error → Return null"]
    E -->|Yes| G["parseValue(value)<br/><i>parse JSON string → object</i>"]
    G --> H["this.remoteConfig.set(key, parsedValue)<br/><i>lưu cache</i>"]
    H --> I["Return parsedValue"]
```

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Fetch + activate remote config từ Firebase |
| `GetRemoteValue(key)` | string | `Promise<any>` | Lấy giá trị remote config (có cache trong session) |
| `FetchNewConfig()` | — | `Promise<void>` | Chủ động fetch config mới + clear cache cũ |
| `GetAllRemoteValues()` | — | `Promise<Object>` | Lấy tất cả remote config |

## Private helper

| Hàm | Chức năng |
|---|---|
| `parseValue(value)` | Parse `{ value: string, source: string }` → thử JSON.parse, fallback string |

## Dependencies

- **ConfigManager**: `get('keys.firebase')` nếu cần dùng runtime (tuỳ chọn)
- Không gọi controller khác — hoạt động độc lập

## Lưu ý

- `init()` gọi `fetchAndActivate()` ngay khi app khởi động.
- Nếu không có mạng, dùng giá trị mặc định từ lần fetch trước.
- Không throw error — Firebase lỗi thì app vẫn chạy bình thường.

## Cách dùng

```mermaid
flowchart LR
    A["ALF.Firebase.GetRemoteValue('show_new_feature')"]
    A --> B{"value === true?"}
    B -->|Yes| C["Bật feature mới"]
    B -->|No| D["Giữ nguyên UI"]
```
