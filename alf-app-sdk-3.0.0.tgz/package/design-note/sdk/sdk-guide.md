# @alf/app-sdk — SDK Usage Guide

## 1. Overview

`@alf/app-sdk` is a **framework SDK** (not a standalone app). It provides:

- **ALF singleton** — Central runtime with 16+ controllers for ads, analytics, device info, network, etc.
- **initSDK(config)** — Single-call initialization of all SDKs and controllers.
- **Shared types** — TypeScript interfaces for config and controllers.
- **Style assets** — Fonts and base CSS.

The consuming project is responsible for:

1. Calling `initSDK()` during boot.
2. Creating its own Vue app instance.
3. Managing its own routes, views, and UI.

---

## 2. Project Structure

```
node_modules/@alf/app-sdk/
├── dist/
│   ├── index.mjs           # ES module build
│   ├── index.cjs           # CommonJS build
│   ├── index.d.ts          # TypeScript declarations
│   ├── app-sdk.css         # Base styles (fonts etc.)
│   └── assets/fonts/       # Bundled font files
├── bin/                    # CLI tools
└── dist-remote/            # Remote asset distribution
```

---

## 3. Quick Start

### 3.1 Install

```bash
npm install @alf/app-sdk
```

### 3.2 Initialize in Your App

**src/main.ts** (your consuming project):

```typescript
import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import { initSDK, ALF } from '@alf/app-sdk'
import '@alf/app-sdk/style.css'

import App from './App.vue'
import HomeView from './views/HomeView.vue'

async function boot() {
  // 1. Load your config
  const config = {
    settings: {
      dev: false,
      isGame: false,
      isApp: true,
      appName: 'MyApp',
      appVersion: '1.0.0',
      environment: 'production',
      hasSettingsScreen: true,
      hasGameplayScreen: false,
    },
    keys: {
      applovin: {
        android: { sdkKey: '...', banner: '...', interstitial: '...', rewarded: '...', mrec: '...' },
        ios: { sdkKey: '...', banner: '...', interstitial: '...', rewarded: '...', mrec: '...' },
      },
      appsflyer: { devKey: '...', iosAppId: '...', androidAppId: '...' },
      firebase: { apiKey: '...', projectId: '...', appId: '...', messagingSenderId: '...' },
    },
  }

  // 2. Initialize framework (controllers, SDKs, i18n)
  const sdkStatus = await initSDK(config)
  console.log('SDK status:', sdkStatus)

  // 3. Create Vue app with your own routes
  const router = createRouter({
    history: createWebHistory(),
    routes: [
      { path: '/', component: HomeView },
    ],
  })

  const app = createApp(App)
  app.use(router)

  // 4. (Optional) Install i18n from ALF if you need translations
  const i18n = ALF.Instance.Localization.getI18n()
  app.use(i18n)

  // 5. Mount, then give the router to ScreenController (needed by Screen.NavigateTo)
  app.mount('#app')
  ALF.Instance.Screen.setRouter(router)
}

boot()
```

### 3.3 Use Controllers

```typescript
import { ALF } from '@alf/app-sdk'

// Inside any component or service:
const alf = ALF.Instance

// Network
const online = await alf.Network.isOnline()
const wifi = await alf.Network.isWifi()

// Device
const isTablet = alf.Device.isTablet()
const deviceId = alf.Device.getDeviceId()

// Ads
await alf.Ads.InitBannerAd()
await alf.Ads.LoadInterstitial()
await alf.Ads.ShowInterstitial()

// Storage
await alf.Storage.set('key', 'value')
const val = await alf.Storage.get('key')

// App Data (persisted preferences)
await alf.Data.set('mySetting', 'someValue')
const data = await alf.Data.load()

// Analytics
await alf.Analytics.logEvent('purchase', { amount: 9.99 })

// Firebase Remote Config (raw)
const remoteValue = await alf.Firebase.GetRemoteValue('feature_flag')

// Firebase Remote Config (typed — with fallbacks)
const interstitialTimeout = await alf.RemoteConfig.GetFloat('interstitial_timeout', 30)
const isFeatureOn = await alf.RemoteConfig.GetBoolean('is_feature_on', false)
const bannerText = await alf.RemoteConfig.GetString('banner_text', 'Play')
await alf.RemoteConfig.FetchNewConfig()

// Camera
const photo = await alf.Camera.takePicture({ quality: 90 })

// Share
await alf.Share.share({ text: 'Hello!', url: 'https://example.com' })

// Media
const imageDataUrl = await alf.Media.CaptureImage({ elementId: 'my-element' })

// Permissions
await alf.Permission.request('camera')

// Haptics (via DeviceController)
await alf.Device.vibrate('light')
```

---

## 4. Config Guide

### 4.1 Config Structure

```typescript
interface Config {
  settings: Settings
  keys: KeysConfig
}

interface Settings {
  dev: boolean               // Enable dev-only features
  testAds?: boolean          // Every ad is a test ad (default: dev)
  isGame: boolean            // Game mode
  isApp: boolean             // App mode
  appName: string
  appVersion: string
  environment: 'dev' | 'staging' | 'production'
  hasSettingsScreen?: boolean
  hasGameplayScreen?: boolean
  defaultFont?: string               // e.g. 'Nunito', 'Roboto'
  defaultLocale?: string             // e.g. 'en', 'vi', 'ja'
}

interface KeysConfig {
  applovin?: { android: AppLovinPlatformKeys; ios: AppLovinPlatformKeys }
  admob?: { android: AdMobPlatformKeys; ios: AdMobPlatformKeys }
  appsflyer?: { devKey: string; iosAppId: string; androidAppId: string }
  firebase?: { apiKey: string; projectId: string; appId: string; messagingSenderId: string }
}
```

### 4.2 Environment-Specific Config

Use your own config loading strategy. Example:

```typescript
import devConfig from './config.dev.json'
import prodConfig from './config.prod.json'

const config = process.env.NODE_ENV === 'production' ? prodConfig : devConfig
```

### 4.3 Test Ads (`settings.testAds`, 1.9.0+)

Turn every ad the SDK shows into a test ad — for tester / QA builds, so nobody clicks real ads
(which risks the AdMob / MAX account) and no fake revenue reaches Firebase.

```typescript
settings: {
  dev: false,       // analytics, RemoteConfig… behave like production
  testAds: true,    // …but every ad is a test ad
}
```

- **Default:** `testAds` follows `dev`, so dev builds already get test ads. Set it explicitly to
  split them (e.g. a tester build with `dev: false, testAds: true`).
- **Read once at `initSDK`.** Changing it later does nothing — rebuild instead.
- **AdMob** (banner, native, interstitial, rewarded, app open): Google's test ad units, even when
  you pass your own `adUnitId`.
- **AppLovin MAX:** on Android the device is registered as a MAX test device via its advertising
  ID. Where that fails (iOS, Ad ID turned off) interstitial, rewarded, app open and MREC are served
  by AdMob test units instead — same calls, same `onClose` / reward callbacks.
- **Revenue:** MAX `ad_impression` is not logged to Firebase; native ad `paid` events carry
  `isTest: true` — skip those when forwarding revenue.
- `ALF.Instance.Ads.IsTestMode()` tells you whether it is on (e.g. for a "TEST ADS" badge).
  `initSDK` logs a `⚠ TEST ADS ON` warning, even in production builds.

> ⚠️ Never ship a store release with `testAds: true` (or `dev: true` without `testAds: false`):
> it earns nothing. Check the console for the `TEST ADS ON` warning before releasing.

### 4.4 Native Ad Pool (`Ads.NativePool`, 2.0.0+)

Keep native ads **loaded but not shown**, so a placeholder that appears draws one at once instead of
waiting 2–10 s on the network.

```typescript
const Ads = ALF.Instance.Ads
void Ads.InitAdMobEarly()                 // Android: start AdMob without waiting for initSDK

Ads.NativePool.Configure('mrec', {
  adUnitIds: [META_UNIT, ADMOB_UNIT],     // priority order = fallback tiers
  request: { video: { startMuted: true }, mediaAspectRatio: 'any' },
  capacity: 2,
})

// A placeholder appears:
const ad = await Ads.NativePool.Acquire('mrec', { maxWaitMs: 6000, isCurrent: () => mounted })
if (ad) {
  await ALFAdMob.showNativeAd({
    slot: ad.slot, adUnitId: ad.adUnitId, template: 'mrec', rect,
    video: { startMuted: true }, mediaAspectRatio: 'any',   // same request as the pool
  })
}
// The placeholder goes away: destroy the shown ad (never put a shown ad back).
await ALFAdMob.destroyNativeAd({ slot: ad.slot })
```

- **Refill:** taking an ad starts loading its replacement. A round that misses every tier backs off
  `retryDelayMs` (a caller waiting in `Acquire` skips the back-off).
- **Staggered tiers:** tier 2 is requested when tier 1 has not answered after `tierStaggerMs`
  (default 2.5 s); tier 1 keeps loading. Every ad that loads is kept — late ones land in the pool.
- **Expiry:** ads older than `maxAgeMs` (default 50 min) are dropped; AdMob natives expire at 1 h.
- **Taken but not shown?** `GiveBack(ad)`. **Failed to show?** `Discard(ad)`.
- Pool slots start with `pool-` (`isNativePoolSlot(slot)`) — filter them in native event handlers.
- Paused while the app is in the background and when remove-ads is owned. Test ads swap the units
  for Google's native test unit.
- **iOS:** the plugin does not key natives by slot yet, so an iOS pool holds at most one ad per unit.

**Startup schedule.** `Ads.WhenStartupStage(ms)` resolves `ms` after AdMob became ready (at once
later in the session). Give pools a `startDelayMs` and await stages before heavier formats, so the
first ads do not compete for bandwidth:

```typescript
Ads.NativePool.Configure('bottom', { adUnitIds: [BN_UNIT], startDelayMs: 2500 })
await Ads.WhenStartupStage(2500); showBanner()
await Ads.WhenStartupStage(5000); Ads.LoadInterstitial(); Ads.LoadRewardedVideo()
```

### 4.5 Ads Performance (`settings.adsPerformance`, 3.0.0+)

The SDK paces ad work so it does not land on the frames that matter. Nothing is dropped; calls
wait their turn:

- Native ads draw one at a time, `nativeShowGapMs` apart (default 300). A screen with two natives
  shows the second a little later instead of freezing. Do **not** `Promise.all` two shows to beat it.
- After a screen change, shows and loads wait for the new screen to draw (`Screen.NavigateTo` reports
  changes; if you navigate another way, call `Ads.NotifyScreenChange(routerPromise, animationMs)`).
- While a fullscreen ad is open and `afterFullscreenMs` (default 1000) after it closes, no native
  draws and no load starts — the reload after an interstitial no longer lands on the next screen's build.
- At most `maxConcurrentLoads` (default 2) loads run at once, across every format.
- A pool reloads `refillDelayMs` (default 800) after an ad is taken, not at once.

```typescript
const config = {
  settings: {
    // every field optional
    adsPerformance: { startupAnchor: 'firstScreen', nativeShowGapMs: 300, maxConcurrentLoads: 2 },
  },
  keys: { /* ... */ },
}
await initSDK(config)
// ... once the first real screen (e.g. Home) is drawn:
ALF.Instance.Ads.MarkFirstScreenShown()
// A/B from Remote Config without a rebuild:
ALF.Instance.Ads.SetPerformanceOptions({ nativeShowGapMs: await RC.GetInt('native_gap_ms', 300) ?? 300 })
```

- `startupAnchor: 'firstScreen'` makes `WhenStartupStage(ms)` and pools' `startDelayMs` count from
  `MarkFirstScreenShown()` instead of AdMob ready, so a slow boot does not release every stage at once.
- `initSDK` no longer waits for AppsFlyer: `status.appsflyer` is `'pending'` until it is done. Await
  `ALF.Instance.Analytics.WhenReady()` if you need it. Events logged meanwhile still reach AppsFlyer.
- Don't request video (`request.video`) for a pool shown with the `small` template: it has no media
  view, so the video downloads and decodes unseen (the SDK warns once).
- `adsPerformance.legacy: true` restores the 2.0.0 behaviour (sequential init, no pacing).
- `Ads.GetPerfStats()` shows loads in flight/queued, natives on screen, fullscreen open.

---

## 5. Controller Reference

| Controller | Property | Description |
|------------|----------|-------------|
| AdController | `ALF.Instance.Ads` | AppLovin MAX + AdMob — Banner, MREC, Interstitial, Rewarded Video, App Open, Native; test ads via `settings.testAds` (§4.3) |
| AnalyticsController | `ALF.Instance.Analytics` | AppsFlyer event tracking |
| FirebaseController | `ALF.Instance.Firebase` | Remote Config (raw), Crashlytics, Analytics |
| RemoteConfigController | `ALF.Instance.RemoteConfig` | Firebase Remote Config — typed getters (`GetFloat`, `GetInt`, `GetString`, `GetBoolean`) with optional fallbacks |
| StorageController | `ALF.Instance.Storage` | Capacitor Preferences (key-value) |
| AppDataController | `ALF.Instance.Data` | Persisted app data (chosen language) |
| NetworkController | `ALF.Instance.Network` | Connection status, WiFi check, change listener |
| DeviceController | `ALF.Instance.Device` | Device ID, OS version, screen size, haptics |
| AppLifecycleController | `ALF.Instance.Lifecycle` | Foreground/background state |
| DeepLinkController | `ALF.Instance.DeepLink` | Universal/App Links handling |
| NotificationController | `ALF.Instance.Notification` | Local & Push notifications |
| AuthController | `ALF.Instance.Auth` | Secure token/session management |
| PermissionController | `ALF.Instance.Permission` | Runtime permission requests (ATT, camera, etc.) |
| CameraController | `ALF.Instance.Camera` | Photo capture, live camera |
| ShareController | `ALF.Instance.Share` | Native share sheet |
| MediaController | `ALF.Instance.Media` | Screenshot capture, slideshow video |
| LocalizationController | `ALF.Instance.Localization` | i18n setup, language switching |

---

## 6. Startup Navigation & Overlay Components

The SDK no longer ships a setup flow (choose-language / onboarding screens were
removed). The app owns its first screens; the SDK only needs the router.

### 6.1 Quick Setup

```typescript
import { createApp } from 'vue'
import { createRouter, createWebHistory } from 'vue-router'
import { initSDK, ALF } from '@alf/app-sdk'

async function boot() {
  const app = createApp(App)
  await ALF.Instance.initControllers()
  ALF.Instance.Localization.init('en')
  app.use(ALF.Instance.Localization.getI18n())

  const router = createRouter({
    history: createWebHistory(),
    routes: [
      { path: '/', name: 'home', component: HomeView },
      // ... your other routes
    ],
  })
  app.use(router)
  app.mount('#app')

  await initSDK(config)

  // Give the router to ScreenController (needed by Screen.NavigateTo), then go home
  ALF.Instance.Screen.setRouter(router)
  ALF.Instance.Screen.NavigateTo('home').fade()
}

boot()
```

### 6.2 Language

- `initSDK` re-applies the locale saved with `ALF.Instance.Data.setLocale(code)`
  (falls back to `settings.defaultLocale`).
- To build a language picker in your app: list `SUPPORTED_LOCALES`, then call
  `ALF.Instance.Localization.setLocale(code)` and `ALF.Instance.Data.setLocale(code)`.

### 6.3 Overlay Components

`OverlayContainer`, `DateTimePicker` and `TimePicker` render as **fullscreen
overlays** (Teleport + `position: fixed`), so they are **not affected** by the
consumer app's layout, CSS, or parent components.

```vue
<script setup>
import { OverlayContainer } from '@alf/app-sdk'
</script>

<template>
  <OverlayContainer>
    <p>My custom overlay content</p>
  </OverlayContainer>
</template>
```

### 6.4 How It Works (Technical)

- Each overlay component creates `<div id="alf-overlay">` in `<body>` on setup
  if it doesn't exist yet — no call needed from the app.
- The overlay components use `<Teleport to="#alf-overlay">` + `position: fixed;
  inset: 0; z-index: 99999` to render outside the app's DOM tree.
- CSS isolation is achieved with `all: initial` and `isolation: isolate` on the
  overlay root, preventing global styles from leaking in.

---

## 7. CSS System & Styling Isolation

The SDK's UI components (OverlayContainer, DateTimePicker, TimePicker) render as
**fullscreen overlays** via `<Teleport>`. They carry their own CSS and are
**isolated** from the host project's styles — no leak in either direction.

### 7.1 Import Base Styles

You should import the base CSS file once in your app entry:

```typescript
// src/main.ts or src/App.vue
import '@alf/app-sdk/style.css'
```

This provides:
- `@font-face` for Nunito (bundled font)
- Base `html`, `body`, `#app` defaults (font-family, colors, sizing)

> If your project has its own global styles (Tailwind, reset, custom fonts),
> they will **not** conflict with SDK overlay components (see §7.2).

### 7.2 How CSS Isolation Works

```
┌──────────────────────────────────────┐
│  Host App DOM                        │
│  ┌────────────────────────────────┐  │
│  │  #app                           │  │
│  │  <Your Vue App>                 │  │
│  │  ┌──────────────────────────┐   │  │
│  │  │ <router-view>             │   │  │
│  │  │   Your views + CSS here   │   │  │
│  │  └──────────────────────────┘   │  │
│  └────────────────────────────────┘  │
│                                      │
│  ┌────────────────────────────────┐  │
│  │  #alf-overlay (auto-created)   │  │
│  │  ┌─────────────────────────┐   │  │
│  │  │ .alf-overlay-root       │   │  │
│  │  │   all: initial          │   │  │
│  │  │   isolation: isolate    │   │  │
│  │  │   ├─ .page              │   │  │
│  │  │   │  (SDK base layout)  │   │  │
│  │  │   └─ SDK scoped styles  │   │  │
│  │  └─────────────────────────┘   │  │
│  └────────────────────────────────┘  │
└──────────────────────────────────────┘
```

`OverlayContainer` (and the pickers' own overlay root) does this:

1. **`all: initial`** — Resets all inherited styles, so your project's
   `font-family`, `color`, `margin`, etc. do **not** leak into the overlay.
2. **`isolation: isolate`** — Creates a fresh stacking context, preventing
   `z-index`, `mix-blend-mode`, and other cascading effects from crossing
   the boundary.
3. **`.alf-overlay-root * { box-sizing: border-box }`** — Re-applies only
   what the SDK components need.
4. **`.alf-overlay-root .page`** — Defines the shared `.page` layout class
   (`100% width/height`, `position: absolute`) for screens built on
   `OverlayContainer`.
5. **`<style scoped>` in each .vue file** — Individual component styles
   (colors, borders, spacing, flex) are scoped and applied on top.

**Result**: Your project's CSS (Tailwind, Bootstrap, custom resets) stays
completely separate from the SDK overlay CSS. No conflicts.

### 7.3 When You Only Use Controllers (No UI)

If your project **only** uses controller APIs and does **not** use the overlay
components, you don't need to import any CSS:

```typescript
import { initSDK, ALF } from '@alf/app-sdk'
// No CSS import needed — controllers are logic-only
```

The `@alf/app-sdk/style.css` import is only required when you use
OverlayContainer, DateTimePicker or TimePicker.

### 7.4 Using OverlayContainer for Custom Screens

You can reuse the same CSS-isolated overlay for your own screens:

```vue
<script setup>
import { OverlayContainer } from '@alf/app-sdk'
</script>

<template>
  <OverlayContainer>
    <div class="my-custom-screen">
      <h1>Custom Screen</h1>
      <p>This screen is isolated from the host app's CSS.</p>
    </div>
  </OverlayContainer>
</template>

<style scoped>
.my-custom-screen {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background: #fff;
  color: #333;
}
</style>
```

The `OverlayContainer` provides:
- Fullscreen fixed positioning (`inset: 0`, `z-index: 99999`)
- CSS isolation (`all: initial`, `isolation: isolate`)
- `box-sizing: border-box` for all children
- Shared `.page` class (optional, use it if your screen needs `width: 100%; height: 100%`)

---

## 8. i18n — Custom Translations

The SDK ships with built-in translations for 18 locales. Your project can
**override** any existing key or **add** new locales by passing
`extraMessages` to `initSDK()`.

### 8.1 Structure

Create one `.json` file per locale in your project, mirroring the SDK's
structure under `sdk/alf/i18n/`:

```
src/i18n/
├── en.json       # English overrides
├── vi.json       # Vietnamese overrides
└── my.json       # New locale: Burmese (SDK doesn't have it)
```

Each file contains **only** the keys you want to override or add:

```json
{
  "home": { "title": "My App" },
  "picker": {
    "time_picker": { "title": "Pick a time" }
  }
}
```

### 8.2 Usage

Import each JSON file and pass them to `initSDK()` as the second argument:

```typescript
import myEn from './i18n/en.json'
import myVi from './i18n/vi.json'
import myMy from './i18n/my.json'

await initSDK(config, {
  en: myEn,       // override English keys
  vi: myVi,       // override Vietnamese keys
  my: myMy,       // add new Burmese locale (SDK doesn't have it)
})
```

> The `extraMessages` parameter must be called **before** `ALF.Instance.Localization.init()`. Since `initSDK()` handles both in order, you only need to pass it at `initSDK()` time.

### 8.3 How Merge Works

- **Deep merge**: nested objects are merged recursively, not replaced.
  SDK has `picker.time_picker.{title,ok,cancel}` → you only override `title`.
- **Locale-level**: if a locale key (`en`, `vi`) already exists in SDK,
  only the specified keys inside are overridden; all other SDK keys stay.
- **New locale**: if a locale key doesn't exist in SDK (e.g. `my`),
  the entire object is added as a new locale.
- **Arrays**: arrays are replaced entirely (not merged by index).
  To override `picker.months[1]`, you must provide the full `months` array.

### 8.4 Per-Locale File Pattern (Recommended)

```typescript
// src/i18n/en.json  (partial overrides only)
{ "home": { "title": "My App" } }

// src/i18n/vi.json  (partial overrides only)
{ "home": { "title": "Ứng dụng của tôi" } }

// src/main.ts
import myEn from './i18n/en.json'
import myVi from './i18n/vi.json'

await initSDK(config, { en: myEn, vi: myVi })
```

This keeps each locale file small and focused, exactly like the SDK's
internal i18n structure.

## 9. Import Paths

```typescript
// Main SDK
import { initSDK, ALF, type Config } from '@alf/app-sdk'

// Styles (fonts + base reset)
import '@alf/app-sdk/style.css'

// Vite dev reload plugin (tooling)
import { alfReloadPlugin } from '@alf/app-sdk/vite'
```

---

## 10. Migration from v1.0 (Monolithic App)

If you were using the old `@alf/app-sdk` that shipped with embedded views/routing:

| Old Pattern | New Pattern |
|------------|-------------|
| `import { init } from '@alf/app-sdk'` | `import { initSDK } from '@alf/app-sdk'` |
| `init(config)` auto-created Vue app | You create your own `createApp()` |
| Router built-in with `setupDefaultRoutes()` | You define your own routes |
| Views (Home, Settings, etc.) shipped in SDK | Views are now in your project's `src/dev/` (demo only) |
| Dev UI always in `src/views/` | Dev UI now in `src/dev/` — excluded from `npm run build` |

---

## 11. Running the Demo (Dev Environment)

The framework ships with a demo app under `src/dev/` for testing during development.

```bash
npm run dev
```

This starts Vite on port 4000 with the demo UI (src/dev/ views, router, App.vue).
The demo is **not** included in the library build (`npm run build` only builds `src/index.ts`).

To add the demo to your own project, refer to `src/dev/main.ts` as a reference bootstrap.
