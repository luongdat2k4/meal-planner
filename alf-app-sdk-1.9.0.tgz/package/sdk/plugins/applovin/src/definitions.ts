export interface InitializeOptions {
  sdkKey: string
  /**
   * Register this device as a MAX test device (its advertising ID) so MAX serves
   * test ads, and stop logging MAX revenue to Firebase. Only applies on the first
   * initialize() of the process.
   */
  testMode?: boolean
}

export interface InitializeResult {
  initialized: boolean
  /**
   * True when this device was registered as a MAX test device. False when
   * `testMode` was off, or the advertising ID was unavailable (Ad ID disabled,
   * iOS — not supported by this plugin yet).
   */
  testDevice?: boolean
}

export interface AdUnitOptions {
  adUnitId: string
}

/**
 * Options of a show*() call. `placement` names where in the app the ad is shown
 * (e.g. "level_revive"); MAX attaches it to the impression, and the SDK sends it
 * as `ad_placement` on the Firebase `ad_impression`.
 */
export interface AdShowOptions extends AdUnitOptions {
  placement?: string
}

export interface AdUnitPositionOptions {
  adUnitId: string
  position: 'TOP_CENTER' | 'BOTTOM_CENTER'
}

export type MRecPosition =
  | 'TOP_CENTER'
  | 'BOTTOM_CENTER'
  | 'TOP_LEFT'
  | 'TOP_RIGHT'
  | 'BOTTOM_LEFT'
  | 'BOTTOM_RIGHT'
  | 'CENTER'

/** An area of the page in CSS px of the web view, e.g. from getBoundingClientRect(). */
export interface MRecRect {
  x: number
  y: number
  width: number
  height: number
}

export interface MRecAdUnitOptions {
  adUnitId: string
  position: MRecPosition
  /**
   * Put the MREC inside this area of the page instead of anchoring it to a
   * screen edge — takes precedence over `position`. The ad stays 300x250dp and
   * is centred in the rect (Android; ignored on iOS).
   */
  rect?: MRecRect
}

export interface UpdateMRecRectOptions {
  adUnitId: string
  rect: MRecRect
}

export interface IsReadyResult {
  ready: boolean
}

export interface IsTabletResult {
  isTablet: boolean
}

export interface RewardEvent {
  /** The ad unit id that triggered the reward */
  adUnitId: string
  /** Optional reward amount */
  amount?: number
}

export interface ALFAppLovinMAXPlugin {
  initialize(options: InitializeOptions): Promise<InitializeResult>
  isTablet(): Promise<IsTabletResult>

  // Banner
  createBanner(options: AdUnitPositionOptions): Promise<void>
  showBanner(options: AdShowOptions): Promise<void>
  hideBanner(options: AdUnitOptions): Promise<void>
  destroyBanner(options: AdUnitOptions): Promise<void>

  // MREC
  createMRec(options: MRecAdUnitOptions): Promise<void>
  /** Move an MREC created with `rect` (Android). */
  updateMRecRect(options: UpdateMRecRectOptions): Promise<void>
  showMRec(options: AdShowOptions): Promise<void>
  hideMRec(options: AdUnitOptions): Promise<void>
  destroyMRec(options: AdUnitOptions): Promise<void>

  // Interstitial
  loadInterstitial(options: AdUnitOptions): Promise<void>
  isInterstitialReady(options: AdUnitOptions): Promise<IsReadyResult>
  showInterstitial(options: AdShowOptions): Promise<void>

  // Rewarded
  loadRewardedAd(options: AdUnitOptions): Promise<void>
  isRewardedAdReady(options: AdUnitOptions): Promise<IsReadyResult>
  showRewardedAd(options: AdShowOptions): Promise<void>

  // App Open
  loadAppOpenAd(options: AdUnitOptions): Promise<void>
  isAppOpenAdReady(options: AdUnitOptions): Promise<IsReadyResult>
  showAppOpenAd(options: AdShowOptions): Promise<void>

  // Events
  addListener(eventName: 'OnRewardedAdReceivedRewardEvent', listener: (event: RewardEvent) => void): Promise<PluginListenerHandle>
  addListener(eventName: 'OnRewardedAdSkippedEvent', listener: (event: { adUnitId: string }) => void): Promise<PluginListenerHandle>
  addListener(eventName: 'OnInterstitialAdHiddenEvent', listener: (event: { adUnitId: string }) => void): Promise<PluginListenerHandle>
  addListener(eventName: 'OnRewardedAdHiddenEvent', listener: (event: { adUnitId: string }) => void): Promise<PluginListenerHandle>
  addListener(eventName: 'OnAppOpenAdHiddenEvent', listener: (event: { adUnitId: string }) => void): Promise<PluginListenerHandle>
  removeAllListeners(): Promise<void>
}

export interface PluginListenerHandle {
  remove: () => void
}
