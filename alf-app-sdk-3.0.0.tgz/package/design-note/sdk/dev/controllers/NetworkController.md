# `NetworkController` — Kết nối mạng

## Vai trò

Lắng nghe trạng thái kết nối mạng (online/offline/wifi/cellular) qua **Capacitor Network** plugin. Đóng vai trò gác cổng: quyết định khi nào app được phép gọi API, khi nào nên đọc từ local cache, hoặc trigger UI thông báo mất mạng.

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Lấy trạng thái hiện tại + bắt đầu lắng nghe thay đổi |
| `isOnline()` | — | `Promise<boolean>` | Kiểm tra thiết bị đang online |
| `isWifi()` | — | `Promise<boolean>` | Kiểm tra thiết bị đang dùng WiFi |
| `onChange(listener)` | `(NetworkStatus) => void` | `() => void` | Subscribe thay đổi mạng → trả về unsubscribe fn |
| `disconnect()` | — | `void` | Dừng lắng nghe, cleanup |

---

## Luồng Init

```mermaid
flowchart TD
    A["init()"] --> B["Network.getStatus()"]
    B --> C["Lưu _status"]
    C --> D["Network.addListener('networkStatusChange')"]
    D --> E["Mỗi khi thay đổi: cập nhật _status + notify listeners"]
```

---

## Cấu trúc dữ liệu

```typescript
type ConnectionType = 'wifi' | 'cellular' | 'none' | 'unknown'

interface NetworkStatus {
  connected: boolean
  connectionType: ConnectionType
}
```

## Dependencies

- `@capacitor/network` — plugin native

## Các controller/view có thể dùng

| Module | Mục đích |
|---|---|
| Mọi view | `isOnline()` trước khi gọi API |
| `HomeView` | Hiển thị banner "Mất kết nối" |
| `onChange()` | Lưu cache, delay API calls |
