# `NotificationController` — Thông báo

## Vai trò

Quản lý **Push Notification** và **Local Notification**. Xử lý payload thông báo, đăng ký push token, và điều hướng khi user tap vào notification.

---

## Danh sách hàm

| Hàm | Input | Output | Chức năng |
|---|---|---|---|
| `init()` | — | `Promise<void>` | Xin permission, đăng ký push, lắng nghe |
| `scheduleLocal(notification)` | `LocalNotification` | `Promise<void>` | Lên lịch thông báo local |
| `cancelLocal(id)` | number | `Promise<void>` | Huỷ thông báo local theo id |
| `getPending()` | — | `Promise<LocalNotification[]>` | Lấy danh sách thông báo đang chờ |
| `onPushReceived(callback)` | callback | `void` | Đăng ký handler khi nhận push (foreground) |
| `onPushTapped(callback)` | callback | `void` | Đăng ký handler khi tap vào push |

---

## Cấu trúc dữ liệu

```typescript
interface LocalNotification {
  id: number
  title: string
  body: string
  schedule?: { at: Date; repeats?: boolean; every?: 'minute' | 'hour' | 'day' | 'week' | 'month' }
  data?: Record<string, any>
}

interface PushNotificationData {
  data: Record<string, any>
  title?: string
  body?: string
}

type NotificationPermission = 'granted' | 'denied' | 'prompt'
```

## Dependencies

- `@capacitor/local-notifications` — local notification
- `@capacitor/push-notifications` — push notification

## Lưu ý

- Push notification chỉ hoạt động trên thiết bị thật (iOS/Android)
- `onPushTapped` dùng để điều hướng đến màn hình chi tiết sau khi user tap
- Kết hợp với `DeepLinkController` để xử lý routing từ notification
