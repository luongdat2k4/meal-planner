# @alf/app-sdk 1.2.0 — Hướng dẫn tích hợp Native Ad (AdMob)

> Dành cho dev app dùng `@alf/app-sdk`. Tài liệu này chỉ nói phần **mới / đổi ở 1.2.0** — native ad
> AdMob render bằng view native thật, event từ Google SDK, và native **video**. Phần còn lại của SDK
> (init, config, controller khác, setup flow, CSS, i18n) xem [sdk-guide.md](../sdk/sdk-guide.md).
>
> Chi tiết kỹ thuật: [CHANGELOG.md](../../CHANGELOG.md) · [AdController.md](../sdk/dev/controllers/AdController.md) ·
> [native-code-ad.md](../sdk/dev/native-code-ad.md)

---

## 1. Tóm tắt thay đổi

| Trước (≤ 1.1.31) | Từ 1.2.0 |
|---|---|
| `LoadAdMobNativeAd()` trả asset → app tự vẽ bằng HTML | `ShowAdMobNativeAd()` — Google SDK vẽ `NativeAdView` thật, đè lên WebView |
| Không ghi impression, click chết, vi phạm policy → doanh thu ≈ 0 | Impression / click do Google SDK ghi nhận |
| `ReportAdMobNativeAdClick()` để báo click | **Luôn reject** — click do SDK tự xử lý |
| Không có event nào của native | `SetOnNativeAdEventHandler()`: `loaded`, `failed`, `impression`, `clicked`, `paid`, `video` |
| Không có video | Template `medium` phát video; tùy chọn `video`, `mediaAspectRatio`; điều khiển play/pause/mute |
| `NativeAdData.mediaUrl` (thực ra là `toString()` của Drawable, không dùng được) | Bỏ; thay bằng `hasVideoContent`, `mediaAspectRatio`, `videoDuration`, `videoCustomControlsEnabled` |
| Dev mode iOS dùng nhầm test unit Android | Test unit đúng theo nền tảng, có unit riêng cho native video |

**Ý tưởng cốt lõi:** app không vẽ ad nữa. App chỉ **giữ chỗ** trong layout, đo rect của chỗ đó, rồi
bảo SDK đặt view native khít vào.

---

## 2. Cài đặt / nâng cấp

```bash
npm install @alf/app-sdk@1.2.0
npx cap sync android     # BẮT BUỘC — code native của plugin đã đổi
```

Chưa publish lên registry mà cần test trên máy? Đóng gói local:

```bash
# trong app-framework
npm run build && npm pack                          # → alf-app-sdk-1.2.0.tgz
# trong app
npm install ./vendor/alf-app-sdk-1.2.0.tgz         # chép tgz vào vendor/ của app trước
npx cap sync android
```

Đừng để `package.json` trỏ tới thư mục tạm. Test xong thì đổi lại `"@alf/app-sdk": "1.2.0"` và xoá `vendor/`.

### Config

Không có key mới. Native dùng `keys.admob.{android|ios}.native`, init qua `initSDK(config)` như cũ
(`initSDK` đã tự gọi `Ads.initAdMob()`).

```ts
keys: {
  admob: {
    android: { appId: 'ca-app-pub-…~…', native: 'ca-app-pub-…/…', /* banner, interstitial, … */ },
    ios:     { appId: 'ca-app-pub-…~…', native: 'ca-app-pub-…/…' },
  },
}
```

Android vẫn cần `com.google.android.gms.ads.APPLICATION_ID` trong `AndroidManifest.xml` của app
(xem `src-dev/android/app/src/main/AndroidManifest.xml`).

Muốn có video ở production: bật **video** cho native ad unit trên AdMob dashboard. Không cần unit riêng.

---

## 3. Migration từ 1.1.x

| Code cũ | Làm gì |
|---|---|
| `LoadAdMobNativeAd()` rồi vẽ `iconUrl`/`headline`/… bằng HTML | Thay bằng ô giữ chỗ + `ShowAdMobNativeAd({ rect })` — mục 4 |
| `ReportAdMobNativeAdClick()` | Xoá. Hàm giờ luôn reject |
| Đọc `ad.mediaUrl` | Xoá. Không có thay thế — media do `MediaView` trong template tự vẽ |
| `addListener('OnAdLoadedEvent' / 'OnAdFailedToLoadEvent')` | Chưa bao giờ chạy. Dùng `SetOnNativeAdEventHandler()` |
| Nhãn "Quảng cáo" tự vẽ | Bỏ — template native đã có nhãn "Ad" |

`LoadAdMobNativeAd()` vẫn còn nhưng chỉ nên dùng để **preload** (nạp trước rồi `ShowAdMobNativeAd()`
dùng lại ad trong cache) hoặc debug asset. Không dùng dữ liệu nó trả về để vẽ ad.

---

## 4. Hiển thị native ad

### 4.1 Hai chế độ đặt vị trí

| Mode | Tham số | Dùng khi |
|---|---|---|
| **rect** | `rect: { x, y, width, height }` (px CSS của viewport) | Ad nằm trong layout — **cách nên dùng** |
| anchor | `position: 'TOP_CENTER' \| 'BOTTOM_CENTER'`, `height` (dp) | Ad neo mép màn hình như banner |

`rect` lấy thẳng từ `element.getBoundingClientRect()`. Trong WebView Android/iOS, px CSS = dp/point,
và giá trị này **đã gồm** `transform: scale()` nếu app scale cả khung game — không phải tự quy đổi.

### 4.2 Template

| Template | Chiều cao tối thiểu | Nội dung |
|---|---|---|
| `small` | **~64dp** (thoáng: ~84dp) | icon + headline + body 1 dòng + advertiser + CTA, một hàng ngang. **Không có media → không phát video** |
| `medium` (mặc định) | **~320dp** | icon + headline + advertiser + rating + body + **media (video/ảnh)** + CTA |

Ô thấp hơn mức tối thiểu thì view native bị **cắt đáy** — mất CTA hoặc nhãn "Ad" (vi phạm policy).
Không đủ chỗ thì **đừng hiện ad**, đừng ép nhỏ.

`medium` cần media view ≥ 120dp — đó là sàn AdMob cho video.

### 4.3 Style

Template chỉ nhận **màu** — không mang font hay gradient của app sang được.

```ts
style: {
  background: '#141A21',
  textColor: '#FFFFFF',
  secondaryTextColor: '#A9B4C0',
  ctaBackground: '#3F74B3',
  ctaTextColor: '#F2F7FF',
  cornerRadius: 10,          // dp
}
```

Màu nhận `#RGB`, `#RRGGBB`, `#AARRGGBB`. Đừng tô CTA giống hệt nút của app — "ad trông như nội dung
app" là vi phạm policy.

### 4.4 Ví dụ tối thiểu

```ts
const r = placeholder.getBoundingClientRect()
const ok = await ALF.Instance.Ads.ShowAdMobNativeAd({
  template: 'medium',
  rect: { x: r.left, y: r.top, width: r.width, height: r.height },
  style: { background: '#FFFFFF', textColor: '#111111', cornerRadius: 12 },
})
// ok === true chỉ nghĩa là view ĐÃ GẮN — không phải đã được nhìn thấy (xem mục 6)
```

---

## 5. Component giữ chỗ — công thức đã chạy thật

Dưới đây là mẫu rút ra khi tích hợp vào AutoBattler (`src/monetization/components/NativeAdCard.vue`).
Nên đặt mọi lời gọi SDK trong một service riêng của app và cho component gọi qua đó.

```vue
<script setup>
import { onMounted, onUnmounted, ref, watch } from 'vue'
import { ALF } from '@alf/app-sdk'

const props = defineProps({
  template: { type: String, default: 'medium' },
  minHeightDp: { type: Number, default: 320 },
  suspended: { type: Boolean, default: false },   // overlay đang đè lên ô?
})
const emit = defineEmits(['settled'])

const box = ref(null)
let alive = true
let shown = false

function measure() {
  const r = box.value?.getBoundingClientRect()
  if (!r || r.width <= 0 || r.height <= 0) return null
  return { x: r.left, y: r.top, width: r.width, height: r.height }
}

function sync() {
  if (!shown || props.suspended) return
  // Đổi scale (transform) không bắn ResizeObserver — chờ 2 frame cho layout mới rồi đo.
  requestAnimationFrame(() => requestAnimationFrame(() => {
    const rect = measure()
    if (rect && alive) ALF.Instance.Ads.UpdateAdMobNativeAdRect(rect)
  }))
}

onMounted(async () => {
  await new Promise(r => requestAnimationFrame(r))   // chờ layout/scale áp xong
  const rect = measure()
  if (!rect || rect.height < props.minHeightDp) return emit('settled', false)

  const ok = await ALF.Instance.Ads.ShowAdMobNativeAd({ template: props.template, rect })
  if (!alive) return           // xem 5.2 — lệnh destroy phải chạy SAU lệnh show
  shown = ok
  if (ok && props.suspended) ALF.Instance.Ads.HideAdMobNativeAd()
  if (ok) window.addEventListener('resize', sync)
  emit('settled', ok)
})

watch(() => props.suspended, (s) => {
  if (!shown) return
  if (s) return ALF.Instance.Ads.HideAdMobNativeAd()
  const rect = measure()
  if (rect) ALF.Instance.Ads.ShowAdMobNativeAd({ template: props.template, rect })  // hiện lại, KHÔNG tính thêm impression
})

onUnmounted(() => {
  alive = false
  window.removeEventListener('resize', sync)
  ALF.Instance.Ads.DestroyAdMobNativeAd()
})
</script>

<template>
  <div ref="box" class="native-ad-slot" />
</template>
```

Kích thước ô do nơi dùng quyết định. Nếu app scale cả khung bằng `transform: scale(var(--app-scale))`,
đặt chiều cao theo **dp thật**:

```css
.loading-native-ad { height: calc(330px / var(--app-scale)); }   /* = 330dp trên mọi máy */
```

### 5.1 Năm điều bắt buộc nhớ

1. **View native nằm TRÊN toàn bộ WebView.** Popup, dialog, menu pause, coach mark — z-index bao nhiêu
   cũng bị ad che. Overlay nào mở đè lên chỗ ad thì `HideAdMobNativeAd()` (prop `suspended` ở trên),
   đóng thì `ShowAdMobNativeAd()` lại.
2. **Không đi theo DOM.** Không cuộn, không transition/GSAP, không fade. Đổi layout (resize, scroll,
   banner vừa hiện làm co khung) → `UpdateAdMobNativeAdRect()`. Chỉ show khi màn đã đứng yên.
3. **Đổi route không gỡ ad.** Vue Router unmount component nhưng view native vẫn còn — phải
   `DestroyAdMobNativeAd()` trong `onUnmounted` / `onBeforeUnmount`.
4. **Cả app chỉ có MỘT native ad.** Hai ô cùng lúc = ô này destroy ad của ô kia. Mỗi màn tối đa một ô.
5. **Khoảng cách với banner ≥ 48dp.** Ad native dính sát banner = accidental click / ad stacking
   (invalid traffic). Tính cả trường hợp khung game dính mép banner trên máy 16:9.

### 5.2 Race khi unmount lúc ad còn đang nạp

`ShowAdMobNativeAd()` có thể mất 1–2 giây (phải load ad). Nếu component unmount giữa chừng và gọi
destroy **trước** khi show xong, native sẽ load xong rồi **vẫn gắn view lên màn hình** của một
component đã chết.

Cách xử lý: cho mọi lệnh native chạy **tuần tự** qua một hàng đợi trong service của app, để destroy
luôn chạy sau show:

```js
let queue = Promise.resolve()
function nativeOp(fn) {
  const run = queue.then(fn).catch((e) => { console.warn('[ads] native op failed:', e); return false })
  queue = run
  return run
}
// showNative   = (rect) => nativeOp(() => ALF.Instance.Ads.ShowAdMobNativeAd({ … rect }))
// destroyNative = ()    => nativeOp(() => ALF.Instance.Ads.DestroyAdMobNativeAd())
```

---

## 6. Event từ Google SDK

```ts
const off = ALF.Instance.Ads.SetOnNativeAdEventHandler((e) => {
  switch (e.type) {
    case 'loaded':     /* e.ad: NativeAdData */ break
    case 'failed':     /* e.error — no-fill là chuyện bình thường */ break
    case 'impression': /* ad THẬT SỰ được nhìn thấy */ break
    case 'clicked':    /* user đang rời app sang advertiser */ break
    case 'paid':       /* e.value, e.currencyCode, e.precision */ break
    case 'video':      /* e.state */ break
  }
})
// off() để huỷ đăng ký. Đăng ký nhiều handler được. No-op trên web.
```

| Event | Dùng để |
|---|---|
| `impression` | Tín hiệu **duy nhất** đáng tin là ad đã hiện. `ShowAdMobNativeAd()` trả `true` cả khi rect ngoài màn hình, bị che, hoặc cao 0 |
| `clicked` | Pause game/âm thanh; hoãn interstitial kế tiếp để không chiếu 2 ad liên tiếp khi user quay lại |
| `paid` | Gửi doanh thu cho AppsFlyer/Firebase. `value` là **đơn vị tiền nguyên** (vd `0.0031` USD) ở cả hai nền tảng. Test unit thường trả `0` |
| `video` | Xem mục 7.3 |

---

## 7. Native video

### 7.1 Hiển thị

Không cần làm gì thêm: creative video tự phát trong media view của template **`medium`**, bắt đầu
**tắt tiếng**. Template `small` không có media view nên creative video vẫn hiện nhưng chỉ icon/chữ.

### 7.2 Tùy chọn request

Nhận bởi cả `ShowAdMobNativeAd()` và `LoadAdMobNativeAd()`:

```ts
await ALF.Instance.Ads.ShowAdMobNativeAd({
  template: 'medium',
  rect,
  video: {
    startMuted: true,                 // mặc định true — nên giữ
    customControlsRequested: false,   // chỉ publisher được Google allowlist mới được cấp
    clickToExpandRequested: false,    // tap video → mở full screen thay vì đi advertiser
  },
  mediaAspectRatio: 'landscape',      // 'any' (mặc định) | 'landscape' | 'portrait' | 'square'
})
```

⚠️ **Tùy chọn chốt lúc LOAD.** Ad đã nằm trong cache (vd đã `LoadAdMobNativeAd()` trước đó) giữ nguyên
tùy chọn cũ. Muốn đổi → `DestroyAdMobNativeAd()` rồi show lại.

⚠️ **Dev mode:** truyền `video` sẽ chuyển sang test unit **native video** của Google (luôn trả video).
Request không có `video` giữ unit đang dùng, nên `ShowAdMobNativeAd()` trơn vẫn hiện lại được ad video
đã ẩn. Production luôn dùng một unit `keys.admob.{platform}.native`.

### 7.3 Event video và âm thanh

`e.state`: `start` (chỉ Android) · `play` · `pause` · `end` · `mute` · `unmute`.

`unmute` = user tự bật tiếng video → **hạ nhạc nền** của app; `mute` / `end` / destroy → trả lại:

```ts
ALF.Instance.Ads.SetOnNativeAdEventHandler((e) => {
  if (e.type !== 'video') return
  if (e.state === 'unmute') bgm.volume = 0.05
  if (e.state === 'mute' || e.state === 'end') bgm.volume = 0.25
})
// Nhớ trả volume khi DestroyAdMobNativeAd() lúc video còn đang có tiếng.
```

### 7.4 Điều khiển player

```ts
await ALF.Instance.Ads.PlayAdMobNativeAdVideo()        // → boolean
await ALF.Instance.Ads.PauseAdMobNativeAdVideo()
await ALF.Instance.Ads.SetAdMobNativeAdVideoMuted(true)
```

Trả `false` khi không có ad video. Chỉ **chắc chắn** có tác dụng khi custom controls được cấp
(`NativeAdData.videoCustomControlsEnabled === true`); khi SDK tự quản control, player có thể bỏ qua lệnh.

### 7.5 Dữ liệu media

`NativeAdData` (có trong event `loaded`):

| Field | Ý nghĩa |
|---|---|
| `hasVideoContent` | Creative là video |
| `mediaAspectRatio` | rộng / cao của media, `0` nếu không rõ |
| `videoDuration` | giây, `0` với ảnh |
| `videoCustomControlsEnabled` | SDK có cấp custom controls không |

---

## 8. API tham chiếu (`ALF.Instance.Ads`)

| Hàm | Trả về | Ghi chú |
|---|---|---|
| `ShowAdMobNativeAd(options?)` | `Promise<boolean>` | Tự load nếu chưa có ad. Gọi lại khi view đã có = hiện lại + đổi rect, không thêm impression |
| `UpdateAdMobNativeAdRect(rect)` | `Promise<void>` | Rect mode — gọi khi layout đổi |
| `HideAdMobNativeAd()` | `Promise<void>` | Ẩn, giữ ad |
| `DestroyAdMobNativeAd()` | `Promise<void>` | Gỡ view + huỷ ad. Gọi khi rời màn |
| `IsAdMobNativeAdReady()` | `Promise<boolean>` | Có ad trong cache |
| `LoadAdMobNativeAd(options?)` | `Promise<NativeAdData \| null>` | Preload / debug. **Không** dùng để vẽ ad |
| `SetOnNativeAdEventHandler(handler)` | `() => void` | Unsubscribe fn |
| `PlayAdMobNativeAdVideo()` | `Promise<boolean>` | |
| `PauseAdMobNativeAdVideo()` | `Promise<boolean>` | |
| `SetAdMobNativeAdVideoMuted(muted)` | `Promise<boolean>` | |
| `ReportAdMobNativeAdClick()` | — | ⛔ Luôn fail |

`options` (`NativeAdInitOptions`): `template`, `rect` | (`position` + `height`), `style`, `video`,
`mediaAspectRatio`. Type export từ `@alf/app-sdk`: `NativeAdInitOptions`, `NativeAdLoadOptions`,
`NativeAdEvent`, `NativeAdEventHandler`, `NativeAdData`, `NativeAdStyle`, `NativeAdRect`,
`NativeAdTemplate`, `NativeAdVideoOptions`, `NativeAdVideoState`, `NativeAdMediaAspectRatio`.

---

## 9. Test trên máy

Dev mode (`settings.dev: true`) tự dùng test unit của Google, luôn fill. Test view có sẵn:
`src-dev/views/test-view/NativeAdTestView.vue` (chọn template, theme, image/video, nút
Play/Pause/Mute, đếm Impressions/Clicks).

Checklist:

- [ ] Ad nằm khít ô, không đè UI khác, không bị cắt CTA/nhãn "Ad"
- [ ] Logcat / console có event `impression`
- [ ] Mở mọi overlay có thể đè lên ô → ad biến mất; đóng → hiện lại
- [ ] Rời màn / đổi route → ad biến mất, không sót view
- [ ] Rotate / đổi kích thước / banner hiện ra → ad vẫn khít ô
- [ ] Video: tự phát không tiếng; bật tiếng → nhạc nền hạ
- [ ] Khoảng cách với banner ≥ 48dp trên máy 16:9 (máy hẹp nhất bạn hỗ trợ)
- [ ] iOS: event `impression` và `video` thật sự tới (delegate sai tên là **im lặng**, build vẫn pass)

---

## 10. Hạn chế đã biết

- **iOS chưa được build/verify trên Mac** ở bản này. Android đã compile trong project thật.
- **Không có banner AdMob trên iOS** (không đổi so với trước).
- **iOS không có `start`** trong event video.
- Chưa có `handleOnPause` / `handleOnResume` cho video — cần verify video có dừng tiếng khi app xuống nền.
- `requireSdk()` của plugin Android **không dừng** luồng khi SDK chưa init — gọi `ALFAdMob.loadInterstitial`
  trực tiếp trước khi init có thể crash app. Luôn đi qua `ALF.Instance.Ads` sau `initSDK()`.
- Test unit của interstitial / rewarded / app open trên iOS vẫn là id Android.
- AppLovin MAX không có native ad.
