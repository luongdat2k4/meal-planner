import { registerPlugin } from '@capacitor/core'
import type { ALFAppLovinMAXPlugin } from './definitions'

const ALFAppLovinMAX = registerPlugin<ALFAppLovinMAXPlugin>('ALFAppLovinMAX', {
  web: () => import('./web').then((m) => new m.ALFAppLovinMAXWeb()),
})

export * from './definitions'
export { ALFAppLovinMAX }
