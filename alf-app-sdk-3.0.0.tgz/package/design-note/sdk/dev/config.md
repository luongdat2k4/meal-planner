# `Config` — Cấu hình tập trung

## Vị trí

```
project-root/
├── config.json          # <— mỗi repo tự có, cấu trúc tuỳ ý
└── src/af/...
```

## Vai trò

Config là object duy nhất chứa mọi cấu hình cho framework: **settings** (bật/tắt tính năng, chế độ dev/game/app) và **keys** (API/SDK key, ad unit ID).

- Được truyền vào `initSDK(config)` từ `main.ts`.
- `ALF.Config` lưu trong memory — controller đọc qua `this.af.Config.get(...)`.
- Không controller nào đọc file trực tiếp.

## Cấu trúc Config

```mermaid
flowchart TD
    A["Config"] --> B["settings<br/><i>Settings</i>"]
    A --> C["keys<br/><i>KeysConfig</i>"]
    
    B --> B1["dev: boolean<br/>debug + sandbox mode"]
    B --> B1a["testAds?: boolean<br/>mọi ad là test ad (mặc định = dev)"]
    B --> B2["isGame: boolean<br/>true nếu app là game"]
    B --> B3["isApp: boolean<br/>true nếu app là ứng dụng"]
    B --> B4["appName: string<br/>tên app"]
    B --> B5["appVersion: string<br/>VD: '1.0.0'"]
    B --> B6["environment: string<br/>'dev' | 'staging' | 'production'"]
    
    C --> C1["applovin<br/><i>AppLovinPlatformKeys</i>"]
    C --> C2["admob<br/><i>AdMobPlatformKeys</i>"]
    C --> C3["appsflyer<br/><i>AppsFlyerKeys</i>"]
    C --> C4["firebase<br/><i>FirebaseKeys</i>"]
    
    C1 --> C1a["android: { sdkKey, banner, mrec, interstitial, rewarded }"]
    C1 --> C1b["ios: { sdkKey, banner, mrec, interstitial, rewarded }"]
    
    C2 --> C2a["android: { appId, banner, interstitial, rewarded }"]
    C2 --> C2b["ios: { appId, banner, interstitial, rewarded }"]
    
    C3 --> C3a["devKey, iosAppId, androidAppId"]
    C4 --> C4a["apiKey, projectId, appId, messagingSenderId"]
```

## Luồng dữ liệu

```mermaid
flowchart TD
    A["config.json<br/>(mỗi repo)"] --> B["ConfigConverter.convert(raw, mappings)"]
    B --> C["initSDK(config)"]
    C --> D["ALF.Config.set(config)"]
    D --> E["AdController<br/>keys.applovin.android.sdkKey"]
    D --> F["AnalyticsController<br/>keys.appsflyer.devKey"]
    D --> G["FirebaseController<br/>keys.firebase"]
    D --> H["Mọi controller<br/>settings.dev"]
```

## Ví dụ config.json

```json
{
  "settings": {
    "dev": true,
    "isGame": false,
    "isApp": true,
    "appName": "MyCapacitorApp",
    "appVersion": "2.1.0",
    "environment": "dev"
  },
  "keys": {
    "applovin": {
      "android": {
        "sdkKey": "YOUR_SDK_KEY",
        "banner": "YOUR_BANNER_ID",
        "mrec": "YOUR_MREC_ID",
        "interstitial": "YOUR_INTERSTITIAL_ID",
        "rewarded": "YOUR_REWARDED_ID"
      },
      "ios": { "...": "..." }
    },
    "appsflyer": {
      "devKey": "YOUR_DEV_KEY",
      "iosAppId": "YOUR_IOS_APP_ID",
      "androidAppId": "YOUR_ANDROID_APP_ID"
    },
    "firebase": {
      "apiKey": "...",
      "projectId": "...",
      "appId": "...",
      "messagingSenderId": "..."
    }
  }
}
```

## ConfigConverter — Mapping linh hoạt

ConfigConverter cho phép map JSON từ repo có cấu trúc bất kỳ thành Config chuẩn.

```mermaid
flowchart TD
    subgraph "Repo A — cấu trúc flat"
        A1["{ max_sdk_key: 'xxx',<br/>  max_banner: 'yyy' }"]
    end
    subgraph "Repo B — cấu trúc lồng"
        B1["{ adConfig: { max: { sdk: 'xxx' } } }"]
    end
    
    A1 --> C["ConfigConverter.convert(raw, mappings)"]
    B1 --> C
    
    C --> D["Config chuẩn<br/>{ keys:{ applovin:{ android:{ sdkKey:'xxx' }}}}"]
```

```mermaid
flowchart LR
    A["Repo A: flat JSON"] -->|"mapping:{'max_sdk_key':'keys.applovin.android.sdkKey'}"| B["Config chuẩn"]
    C["Repo B: lồng JSON"] -->|"mapping:{'adConfig.max.sdk':'keys.applovin.android.sdkKey'}"| B
    D["Repo C: đúng cấu trúc"] -->|"không cần mapping"| B
```

## Lưu ý

- `ConfigConverter` không bắt buộc — có thể truyền object trực tiếp vào `initSDK()`.
- `config.json` của mỗi repo nên được thêm vào `.gitignore` nếu chứa key thật.
- Các field thiếu sẽ được fill bằng default values.
