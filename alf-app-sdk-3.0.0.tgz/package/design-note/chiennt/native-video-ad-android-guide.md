# Hướng dẫn implement Native Video Ad (AdMob) — tầng Android Java

**Ngày:** 2026-10-06 · **Tham chiếu:** `sdk/android/src/main/java/alf/admob/ALFAdMobPlugin.java` (app-sdk 1.2.0)
**Author:** Nguyễn Thế Chiến

> Code mẫu dưới đây rút từ implementation đang chạy trong app-sdk, đã bỏ phần Capacitor
> (`PluginCall`, `JSObject`, `notifyListeners`) và thay bằng `org.json.JSONObject` + một interface
> `EventSink`. Logic AdMob giữ nguyên.

---

## 1. Ba điều không được làm sai

1. **Ad phải được vẽ bằng `NativeAdView` thật.** Đúng lúc gọi `adView.setNativeAd(nativeAd)` thì SDK
   mới ghi nhận impression và gắn click handler. Nếu bóc asset (headline, icon…) ra rồi vẽ lại bằng
   UI của engine (Unity UI, sprite, HTML…) thì sẽ:
   - không có impression nào được ghi, tức không có doanh thu;
   - bấm CTA không mở được trang của advertiser;
   - vi phạm policy native ad, nên ad unit thật fill rất thấp hoặc bằng 0. Test unit vẫn load bình
     thường, nên lúc dev trông như mọi thứ vẫn chạy.
2. **Video chỉ phát được trong `MediaView`.** Không lấy URL video ra để tự phát được, vì SDK không
   đưa URL đó ra ngoài. `MediaView` phải được đăng ký bằng `adView.setMediaView(...)` và kích thước
   tối thiểu là **120×120dp**.
3. **Bắt buộc có nhãn "Ad"/"Quảng cáo"** nằm trong `NativeAdView` (yêu cầu của policy).

---

## 2. Kiến trúc

```
┌────────────── Engine (C# / JS / GDScript) ──────────────┐
│  LoadNativeAd / ShowNativeAd / Hide / Destroy           │
│  Play / Pause / Mute video                              │
│  ◄── nhận event: Loaded, Impression, Paid, Video...     │
└───────────────────────┬─────────────────────────────────┘
                        │  bridge (AndroidJavaObject / JNI / ...)
┌───────────────────────▼─────────────────────────────────┐
│  NativeAdManager (Java)                                 │
│   Map<adUnitId, NativeAd>       ads    — ad đã load     │
│   Map<adUnitId, NativeAdView>   views  — view đang gắn  │
│   EventSink                     sink   — đẩy event lên  │
└───────────────────────┬─────────────────────────────────┘
                        │
              Google Mobile Ads SDK
                        │
       NativeAdView ──► add vào android.R.id.content
                        (nằm ĐÈ lên view của engine)
```

- State được lưu theo `adUnitId`: mỗi unit có tối đa **một** `NativeAd` và **một** `NativeAdView`.
- Ad view là một Android `View` nằm đè lên view của engine. Nó **không** tự cuộn hay di chuyển theo
  UI của engine. Nếu ad nằm trong một list/layout của game thì engine phải gửi lại toạ độ mỗi khi
  layout thay đổi (xem §6.2).

---

## 3. Setup

### 3.1 Gradle

```groovy
dependencies {
    implementation "com.google.android.gms:play-services-ads:25.4.0"
}
```

> **Unity:** nếu dự án đã có plugin Google Mobile Ads cho Unity, hoặc mediation adapter của
> AppLovin MAX (`google-adapter`), thì `play-services-ads` đã có sẵn qua EDM4U. Phải dùng **cùng
> version** với cái EDM4U resolve ra, không khai báo thêm một version khác, nếu không sẽ bị duplicate
> class hoặc crash runtime.

### 3.2 AndroidManifest

```xml
<application android:hardwareAccelerated="true" ...>
    <meta-data
        android:name="com.google.android.gms.ads.APPLICATION_ID"
        android:value="ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy"/>
</application>
```

- **Video ad cần hardware acceleration.** Nếu nó bị tắt ở `<application>` hoặc ở chính activity đang
  hiện ad thì `MediaView` có thể trắng hoặc đen. Hãy kiểm tra **manifest sau khi merge**
  (`build/intermediates/merged_manifests/...`), không chỉ file mình viết, vì một số template activity
  của engine cũ có tự set `hardwareAccelerated="false"`.

### 3.3 Đóng gói (Unity)

Layout XML (§4) là Android resource, nên nó phải nằm trong một **Android library**: file `.aar`, hoặc
thư mục `Assets/Plugins/Android/<Tên>.androidlib/` có `AndroidManifest.xml` và `res/layout/`. Đừng
đặt file `.xml` lẻ vào `Assets/Plugins/Android/res`. Còn nếu không muốn dùng resource thì có thể
dựng layout bằng code Java.

### 3.4 Khởi tạo

```java
MobileAds.initialize(activity, status -> { /* sdkReady = true */ });
```

Chỉ load ad sau khi `initialize` đã callback.

---

## 4. Layout template

Root **phải** là `NativeAdView`. Đây là template `medium` (có media) đang dùng, đã lược bớt style:

```xml
<com.google.android.gms.ads.nativead.NativeAdView
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content">

    <LinearLayout
        android:id="@+id/native_root"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical"
        android:padding="12dp">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="horizontal"
            android:gravity="center_vertical">

            <ImageView android:id="@+id/native_icon"
                android:layout_width="48dp" android:layout_height="48dp"
                android:layout_marginEnd="10dp" android:scaleType="fitCenter"/>

            <LinearLayout
                android:layout_width="0dp" android:layout_height="wrap_content"
                android:layout_weight="1" android:orientation="vertical">
                <TextView android:id="@+id/native_headline"
                    android:layout_width="match_parent" android:layout_height="wrap_content"
                    android:maxLines="2" android:ellipsize="end" android:textStyle="bold"/>
                <TextView android:id="@+id/native_advertiser"
                    android:layout_width="match_parent" android:layout_height="wrap_content"
                    android:maxLines="1"/>
                <RatingBar android:id="@+id/native_rating"
                    style="?android:attr/ratingBarStyleSmall"
                    android:layout_width="wrap_content" android:layout_height="wrap_content"
                    android:numStars="5" android:stepSize="0.5" android:isIndicator="true"
                    android:visibility="gone"/>
            </LinearLayout>

            <!-- Bắt buộc theo policy -->
            <TextView android:id="@+id/native_ad_badge"
                android:layout_width="wrap_content" android:layout_height="wrap_content"
                android:text="Ad" android:textSize="10sp" android:textStyle="bold"/>
        </LinearLayout>

        <TextView android:id="@+id/native_body"
            android:layout_width="match_parent" android:layout_height="wrap_content"
            android:layout_marginTop="8dp" android:maxLines="3" android:ellipsize="end"/>

        <!-- height 0 + weight 1: media ăn hết chiều cao còn lại mà engine cấp cho ad.
             minHeight 120dp: dưới mức này SDK không phát video. -->
        <com.google.android.gms.ads.nativead.MediaView
            android:id="@+id/native_media"
            android:layout_width="match_parent"
            android:layout_height="0dp"
            android:layout_weight="1"
            android:layout_marginTop="8dp"
            android:minHeight="120dp"/>

        <Button android:id="@+id/native_cta"
            android:layout_width="match_parent" android:layout_height="wrap_content"
            android:layout_marginTop="10dp" android:textAllCaps="false"/>
    </LinearLayout>
</com.google.android.gms.ads.nativead.NativeAdView>
```

Một template không có `MediaView` (ví dụ dạng nhỏ cao khoảng 80dp) **vẫn hiện được** creative video,
nhưng chỉ có icon và text, video không phát. Muốn có video thì template phải có media.

---

## 5. Load ad

### 5.1 Video options được chốt lúc load

`VideoOptions` và `mediaAspectRatio` được truyền vào `AdLoader`. Sau khi ad đã về thì **không có API
nào đổi được** chúng. Vì vậy:

- Option phải đi cùng lời gọi **load**, không phải lúc show.
- Ad đã preload sẽ giữ option của lần load đó. Đừng âm thầm reload để áp option mới, vì như vậy mất
  ad đang có và tốn thêm một request.

| Option | Mặc định nên dùng | Ghi chú |
|---|---|---|
| `startMuted` | `true` | Default của SDK và là khuyến nghị của AdMob cho ad tự phát. Nên truyền tường minh để không phụ thuộc default của từng version SDK. |
| `customControlsRequested` | `false` | Chỉ là *xin*. Có được cấp hay không thì xem `VideoController.isCustomControlsEnabled()` sau khi load. |
| `clickToExpandRequested` | `false` | |
| `mediaAspectRatio` | `ANY` | `LANDSCAPE` / `PORTRAIT` / `SQUARE` / `ANY` |

### 5.2 Code

```java
public final class NativeAdManager {

  /** How events get back to the engine — see §9 for a Unity implementation. */
  public interface EventSink {
    void emit(String event, JSONObject payload);
  }

  public interface LoadCallback {
    void onLoaded(NativeAd ad);
    void onFailed(String error);
  }

  public static final class VideoConfig {
    public boolean startMuted = true;
    public boolean customControlsRequested = false;
    public boolean clickToExpandRequested = false;
    public String mediaAspectRatio = "any"; // landscape | portrait | square | any
  }

  private final Activity activity;
  private final EventSink sink;
  // Touched only on the UI thread — every public method posts there first (§8).
  private final Map<String, NativeAd> ads = new HashMap<>();
  private final Map<String, NativeAdView> views = new HashMap<>();

  public NativeAdManager(Activity activity, EventSink sink) {
    this.activity = activity;
    this.sink = sink;
  }

  /** Load (or reload) the unit's ad. Replaces whatever was cached for it. */
  public void load(final String adUnitId, final VideoConfig config, final LoadCallback cb) {
    activity.runOnUiThread(() -> {
      // Drop the old ad AND the view rendering it — that view points at an ad
      // that is about to be destroyed.
      destroyView(adUnitId);
      NativeAd old = ads.remove(adUnitId);
      if (old != null) old.destroy();

      final AtomicBoolean settled = new AtomicBoolean(false);
      AdLoader loader = new AdLoader.Builder(activity, adUnitId)
        .forNativeAd(nativeAd -> {
          if (settled.getAndSet(true)) return;
          ads.put(adUnitId, nativeAd);
          // Attach these BEFORE anyone can show the ad: the paid event fires off
          // the impression, which happens as soon as the view is on screen.
          nativeAd.setOnPaidEventListener(v -> emitPaid(adUnitId, v));
          attachVideoLifecycle(adUnitId, nativeAd);
          sink.emit("OnNativeAdLoadedEvent", toJson(adUnitId, nativeAd));
          if (cb != null) cb.onLoaded(nativeAd);
        })
        .withAdListener(new AdListener() {
          @Override public void onAdFailedToLoad(LoadAdError e) {
            if (settled.getAndSet(true)) return;
            ads.remove(adUnitId);
            JSONObject ev = obj("adUnitId", adUnitId);
            put(ev, "error", e.getMessage());
            sink.emit("OnNativeAdFailedToLoadEvent", ev);
            if (cb != null) cb.onFailed(e.getMessage());
          }
          // For native ads these are the only truthful "seen" / "tapped" signals.
          @Override public void onAdImpression() {
            sink.emit("OnNativeAdImpressionEvent", obj("adUnitId", adUnitId));
          }
          @Override public void onAdClicked() {
            sink.emit("OnNativeAdClickedEvent", obj("adUnitId", adUnitId));
          }
        })
        // Leave setReturnUrlsForImageAssets at its default (false): the SDK then
        // downloads assets and fills BOTH Drawable and Uri. NativeAdView needs the
        // Drawable — turning URLs on leaves the rendered ad without an icon.
        .withNativeAdOptions(buildOptions(config))
        .build();

      loader.loadAd(new AdRequest.Builder().build());
    });
  }

  private NativeAdOptions buildOptions(VideoConfig c) {
    if (c == null) c = new VideoConfig();
    VideoOptions video = new VideoOptions.Builder()
      .setStartMuted(c.startMuted)
      .setCustomControlsRequested(c.customControlsRequested)
      .setClickToExpandRequested(c.clickToExpandRequested)
      .build();
    return new NativeAdOptions.Builder()
      .setVideoOptions(video)
      .setMediaAspectRatio(aspect(c.mediaAspectRatio))
      .build();
  }

  private static int aspect(String v) {
    if ("landscape".equals(v)) return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_LANDSCAPE;
    if ("portrait".equals(v))  return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_PORTRAIT;
    if ("square".equals(v))    return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_SQUARE;
    return NativeAdOptions.NATIVE_MEDIA_ASPECT_RATIO_ANY;
  }
```

Lưu ý:
- **`AtomicBoolean settled`** đảm bảo callback `onLoaded`/`onFailed` của lời gọi chỉ chạy đúng **một
  lần**. Bridge của engine thường không chịu được việc một request được trả kết quả hai lần.
- `OnPaidEventListener`, video lifecycle và các listener impression/click phải được gắn **ngay khi ad
  load xong**, không đợi tới lúc show.

---

## 6. Render & hiển thị

### 6.1 Bind asset rồi `setNativeAd`

```java
  /** Show the unit's ad. Loads first if nothing is cached. */
  public void show(final String adUnitId, final Placement placement, final VideoConfig config) {
    activity.runOnUiThread(() -> {
      // Already rendered: just reposition + unhide. Registering the same NativeAd
      // on a fresh NativeAdView would record a SECOND impression for one ad.
      NativeAdView existing = views.get(adUnitId);
      if (existing != null) {
        existing.setLayoutParams(placement.toLayoutParams(activity));
        existing.setVisibility(View.VISIBLE);
        return;
      }
      NativeAd cached = ads.get(adUnitId);
      if (cached != null) { render(adUnitId, cached, placement); return; }

      load(adUnitId, config, new LoadCallback() {
        @Override public void onLoaded(NativeAd ad) { render(adUnitId, ad, placement); }
        @Override public void onFailed(String error) { /* already emitted */ }
      });
    });
  }

  private void render(String adUnitId, NativeAd ad, Placement placement) {
    destroyView(adUnitId);
    NativeAdView adView = (NativeAdView) LayoutInflater.from(activity)
      .inflate(R.layout.native_ad_medium, null);

    bindAssets(adView, ad);
    // Records the impression and wires up the registered (clickable) asset views.
    adView.setNativeAd(ad);

    FrameLayout container = activity.findViewById(android.R.id.content);
    container.addView(adView, placement.toLayoutParams(activity));
    if (placement.isBottomAnchored()) applyBottomInset(adView);
    views.put(adUnitId, adView);
  }

  private void bindAssets(NativeAdView v, NativeAd ad) {
    TextView headline = v.findViewById(R.id.native_headline);
    headline.setText(ad.getHeadline());
    v.setHeadlineView(headline);

    TextView body = v.findViewById(R.id.native_body);
    if (ad.getBody() != null) { body.setText(ad.getBody()); v.setBodyView(body); }
    else body.setVisibility(View.GONE);

    Button cta = v.findViewById(R.id.native_cta);
    if (ad.getCallToAction() != null) { cta.setText(ad.getCallToAction()); v.setCallToActionView(cta); }
    else cta.setVisibility(View.GONE);

    ImageView icon = v.findViewById(R.id.native_icon);
    Drawable d = ad.getIcon() != null ? ad.getIcon().getDrawable() : null;
    if (d != null) { icon.setImageDrawable(d); v.setIconView(icon); }
    else icon.setVisibility(View.GONE);

    TextView advertiser = v.findViewById(R.id.native_advertiser);
    if (ad.getAdvertiser() != null) { advertiser.setText(ad.getAdvertiser()); v.setAdvertiserView(advertiser); }
    else advertiser.setVisibility(View.GONE);

    RatingBar rating = v.findViewById(R.id.native_rating);
    if (ad.getStarRating() != null) {
      rating.setRating(ad.getStarRating().floatValue());
      rating.setVisibility(View.VISIBLE);
      v.setStarRatingView(rating);
    }

    // The video player. setMediaContent + setMediaView is all it takes —
    // MediaView plays the video itself, no extra code needed.
    MediaView media = v.findViewById(R.id.native_media);
    if (ad.getMediaContent() != null) {
      media.setMediaContent(ad.getMediaContent());
      v.setMediaView(media);
    } else {
      media.setVisibility(View.GONE);
    }
  }
```

Asset nào ad không có thì **ẩn view** và **không đăng ký** nó lên `NativeAdView`. Không để một view
trống mà vẫn bấm được.

### 6.2 Vị trí: anchor và rect

| Mode | Engine gửi xuống | LayoutParams |
|---|---|---|
| anchor | `TOP` / `BOTTOM` + `height` (dp) | `MATCH_PARENT × height`, `gravity = TOP\|BOTTOM, CENTER_HORIZONTAL` |
| rect | `x, y, width, height` | `width × height`, `gravity = TOP\|START`, `leftMargin = x`, `topMargin = y` |

```java
  /** Move an ad shown in rect mode — engine calls this whenever its layout moves. */
  public void updateRect(final String adUnitId, final Placement placement) {
    activity.runOnUiThread(() -> {
      NativeAdView v = views.get(adUnitId);
      if (v != null) v.setLayoutParams(placement.toLayoutParams(activity));
    });
  }
```

**Đơn vị toạ độ là chỗ hay sai nhất.** Hãy chốt rõ trong contract của bridge:

| Nguồn | Đơn vị | Gốc toạ độ | Đổi sang LayoutParams (px, gốc top-left) |
|---|---|---|---|
| WebView (app-sdk của mình) | CSS px | top-left | nhân `density` |
| **Unity** `Screen` / `RectTransformUtility.WorldToScreenPoint` | **pixel thật** | **bottom-left** | không nhân density; `top = Screen.height − (y + height)` |
| Anchor `height` | dp | — | nhân `density` |

> Với Unity, `Screen.height` là chiều cao surface của Unity. Nếu app không chạy fullscreen (có status
> bar hoặc cutout) thì nó có thể lệch so với chiều cao của `android.R.id.content`. Hãy log cả hai trên
> device thật trước khi tin công thức trên.

### 6.3 Container và inset

- Add vào `android.R.id.content` (một `FrameLayout`). View được add sau sẽ nằm đè lên view của engine
  (`UnityPlayer`, `WebView`…).
- Từ Android 15 app mặc định chạy edge-to-edge, nên ad neo đáy sẽ bị navigation bar che. Cách xử lý:

```java
  private static void applyBottomInset(View view) {
    view.setOnApplyWindowInsetsListener((v, insets) -> {
      FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
      if (lp != null) {
        lp.bottomMargin = insets.getSystemWindowInsetBottom();
        v.setLayoutParams(lp);
      }
      return insets;
    });
    view.requestApplyInsets();
  }
```

### 6.4 Hide / destroy

```java
  public void hide(final String adUnitId) {
    activity.runOnUiThread(() -> {
      NativeAdView v = views.get(adUnitId);
      if (v != null) v.setVisibility(View.GONE);
    });
  }

  /** Release both the view and the ad. NativeAd and NativeAdView each need destroy(). */
  public void destroy(final String adUnitId) {
    activity.runOnUiThread(() -> {
      destroyView(adUnitId);
      NativeAd ad = ads.remove(adUnitId);
      if (ad != null) ad.destroy();
    });
  }

  private void destroyView(String adUnitId) {
    NativeAdView v = views.remove(adUnitId);
    if (v == null) return;
    ViewGroup parent = (ViewGroup) v.getParent();
    if (parent != null) parent.removeView(v);
    v.destroy();
  }
```

- `hide` chỉ set `GONE` và **giữ** cả view lẫn ad. Gọi `show` lại thì view cũ hiện lên, không bị tính
  thêm impression.
- `destroy` là bắt buộc khi không dùng nữa, vì `NativeAd` giữ tài nguyên của video player.

---

## 7. Video: event và điều khiển

### 7.1 Event — gắn ngay khi load

```java
  private void attachVideoLifecycle(final String adUnitId, NativeAd ad) {
    MediaContent media = ad.getMediaContent();
    if (media == null || !media.hasVideoContent()) return;

    media.getVideoController().setVideoLifecycleCallbacks(
      new VideoController.VideoLifecycleCallbacks() {
        @Override public void onVideoStart() { emitVideo(adUnitId, "start"); }
        @Override public void onVideoPlay()  { emitVideo(adUnitId, "play"); }
        @Override public void onVideoPause() { emitVideo(adUnitId, "pause"); }
        @Override public void onVideoEnd()   { emitVideo(adUnitId, "end"); }
        @Override public void onVideoMute(boolean muted) {
          emitVideo(adUnitId, muted ? "mute" : "unmute");
        }
      });
  }

  private void emitVideo(String adUnitId, String state) {
    JSONObject ev = obj("adUnitId", adUnitId);
    put(ev, "state", state);
    sink.emit("OnNativeAdVideoEvent", ev);
  }
```

Dùng **một** event có field `state`, không tách thành 6 event riêng: cả 6 trường hợp đều mang cùng
một payload.

Game cần event này chủ yếu vì hai việc:
- **`unmute` → giảm hoặc tắt nhạc nền của game.** Không làm thì nhạc game và tiếng ad sẽ chồng lên
  nhau.
- Phân biệt video đã thực sự chạy (`start`/`play`) với video chưa bao giờ phát.

> `start` chỉ có trên Android. Nếu SDK còn có phía iOS thì `VideoControllerDelegate` bên đó không có
> callback tương ứng, và frame đầu tiên sẽ đến dưới dạng `play`. Code của engine không nên phụ thuộc
> vào `start`.

### 7.2 Điều khiển

```java
  public void play(String adUnitId)  { withVideo(adUnitId, VideoController::play); }
  public void pause(String adUnitId) { withVideo(adUnitId, VideoController::pause); }
  public void mute(String adUnitId, boolean muted) { withVideo(adUnitId, c -> c.mute(muted)); }

  private void withVideo(final String adUnitId, final Consumer<VideoController> action) {
    activity.runOnUiThread(() -> {
      NativeAd ad = ads.get(adUnitId);
      if (ad == null) return;                       // not loaded
      MediaContent m = ad.getMediaContent();
      if (m == null || !m.hasVideoContent()) return; // image creative
      action.accept(m.getVideoController());
    });
  }
```

(Trong bridge thật thì nên **trả lỗi** về engine cho hai trường hợp `not loaded` và `no video`, thay
vì im lặng `return`.)

- `VideoController` phải được gọi trên **UI thread**.
- Khi **không** được cấp custom controls (`isCustomControlsEnabled() == false`), player dùng control
  của chính nó và **có thể bỏ qua** play/pause/mute. Hiện mình chỉ ghi chú điều này chứ không chặn,
  vì chưa xác minh trên device xem player thực sự phản hồi hay không.

---

## 8. Threading

| Ở đâu | Thread |
|---|---|
| Callback của GMA SDK (`onNativeAdLoaded`, `AdListener`, video lifecycle, paid) | Android main / UI |
| Lời gọi từ engine vào Java (Unity `AndroidJavaObject.Call`, JNI…) | **thread của engine**, không phải UI thread |
| Mọi thao tác với `View`, `NativeAdView`, `VideoController` | **bắt buộc UI thread** |

Quy tắc đơn giản nhất, cũng là cách code mẫu đang làm: **mọi public method đều `runOnUiThread` ngay
từ đầu.** Khi đó các map chỉ bị chạm từ một thread, nên không cần lock.

Chiều ngược lại (Java gửi lên engine) thì tuỳ engine. Xem §9.

---

## 9. Bridge lên engine

### 9.1 Payload `OnNativeAdLoadedEvent`

```java
  private static JSONObject toJson(String adUnitId, NativeAd ad) {
    JSONObject o = obj("adUnitId", adUnitId);
    put(o, "headline", nz(ad.getHeadline()));
    put(o, "body", nz(ad.getBody()));
    put(o, "callToAction", nz(ad.getCallToAction()));
    put(o, "advertiser", nz(ad.getAdvertiser()));
    put(o, "starRating", ad.getStarRating() != null ? ad.getStarRating() : 0d);

    MediaContent m = ad.getMediaContent();
    boolean hasVideo = m != null && m.hasVideoContent();
    put(o, "hasVideoContent", hasVideo);
    put(o, "mediaAspectRatio", m != null ? (double) m.getAspectRatio() : 0d); // width / height
    put(o, "videoDuration", hasVideo ? (double) m.getDuration() : 0d);         // seconds
    put(o, "videoCustomControlsEnabled",
      hasVideo && m.getVideoController().isCustomControlsEnabled());
    return o;
  }
```

- **`mediaAspectRatio`**: engine dùng giá trị này để tính chiều cao vùng giữ chỗ cho ad (rect mode),
  để video không bị letterbox.
- **Không có `mediaUrl`.** `getMediaContent().getMainImage()` trả về một `Drawable`, nên gọi
  `.toString()` sẽ ra `BitmapDrawable@7f3a1b2` chứ không phải URL. Video cũng không có URL. Payload
  này chỉ để engine **biết** ad có gì, không phải để engine tự vẽ (xem §1).

### 9.2 Payload `OnNativeAdPaidEvent` (doanh thu)

```java
  private void emitPaid(String adUnitId, AdValue v) {
    JSONObject ev = obj("adUnitId", adUnitId);
    put(ev, "value", v.getValueMicros() / 1_000_000d);  // whole currency units
    put(ev, "currencyCode", v.getCurrencyCode());
    put(ev, "precision", precision(v.getPrecisionType())); // unknown|estimated|publisherProvided|precise
    sink.emit("OnNativeAdPaidEvent", ev);
  }
```

Hãy chia micros ở tầng Java, để engine luôn nhận đơn vị tiền tệ nguyên, giống nhau trên mọi nền tảng.

### 9.3 `EventSink` cho Unity

Có hai cách:

**a) `UnityPlayer.UnitySendMessage`** — đơn giản nhất. Nó thread-safe và message được giao trên main
thread của Unity ở frame kế tiếp:

```java
EventSink sink = (event, payload) -> {
  JSONObject msg = new JSONObject();
  put(msg, "event", event);
  put(msg, "payload", payload);
  UnityPlayer.UnitySendMessage("AdsBridge", "OnNativeEvent", msg.toString());
};
```

**b) `AndroidJavaProxy`** — C# implement một interface Java. Callback sẽ chạy **trên thread Java
đang gọi nó** (ở đây là UI thread), **không phải** main thread của Unity, nên phía C# phải đẩy vào
một queue rồi xử lý trong `Update()`. Nếu không, mọi lời gọi Unity API trong callback sẽ throw.

---

## 10. Lifecycle

```java
  /** Call from Activity.onDestroy (Unity: plugin activity / ActivityLifecycleCallbacks). */
  public void onDestroy() {
    // Already on the main thread — touch views directly. A post could run
    // after the activity is gone.
    for (NativeAdView v : views.values()) {
      ViewGroup p = (ViewGroup) v.getParent();
      if (p != null) p.removeView(v);
      v.destroy();
    }
    views.clear();
    for (NativeAd ad : ads.values()) ad.destroy();
    ads.clear();
  }
```

Bước này là bắt buộc. Khi activity bị huỷ thật (back thoát app, config change mà app không tự xử lý,
hệ thống thu hồi task), code dọn dẹp ở phía engine **không kịp chạy**. Trong khi đó `NativeAd` và
`NativeAdView` đều cần `destroy()` tường minh.

Với Unity, có thể đăng ký `Application.ActivityLifecycleCallbacks` từ Java để không phải sửa
`UnityPlayerActivity`.

**`onPause`/`onResume`:** chưa xác minh được video có tự dừng tiếng khi app xuống nền hay không. Cách
tạm thời là engine gọi `pause()` khi mất focus (Unity: `OnApplicationPause(true)`). Xem §12.

---

## 11. Test

### 11.1 Test unit ID (Android)

| Loại | ID |
|---|---|
| Native (thường) | `ca-app-pub-3940256099942544/2247696110` |
| **Native video** | `ca-app-pub-3940256099942544/1044960115` |

Test unit native thường **gần như không trả video**. Muốn test video thì phải dùng unit video.

### 11.2 Checklist trên device

1. Load bằng unit video, `startMuted = true`, rồi show bằng template có `MediaView`. Phải thấy log
   `OnNativeAdLoadedEvent` với `hasVideoContent = true`.
2. Video tự phát **không tiếng**. Phải nhận được `start` rồi `play`.
3. Bấm nút loa trên player để bật tiếng. Phải nhận được `unmute`, và game giảm nhạc nền.
4. Chờ hết video. Phải nhận được `end`.
5. Phải có `OnNativeAdImpressionEvent` và `OnNativeAdPaidEvent` (test unit vẫn bắn paid event với
   value 0 hoặc rất nhỏ).
6. Bấm CTA. Phải nhận được `OnNativeAdClickedEvent` và trang advertiser mở ra.
7. `hide` rồi `show` lại. View hiện lại và **không** có impression thứ hai.
8. Với ad neo đáy trên Android 15+, ad không bị navigation bar che.
9. Thoát app bằng back. Không có crash hay leak (LeakCanary nếu có).

---

## 12. Chưa xác minh — cần đo trên device

Những điểm dưới đây ngay cả app-sdk của mình cũng chưa xác minh trên device. Team nào đo được trước
thì báo lại giúp:

1. **App xuống nền:** video có tự dừng hay tắt tiếng không? Nếu không thì cần thêm `pause()` trong
   `onPause`.
2. **`hide` (GONE) khi video đang phát có tiếng:** player có dừng không?
3. **Play/Pause/Mute khi không có custom controls:** player phản hồi hay bỏ qua?
4. **Unity riêng:** `MediaView` có phát video bình thường khi nằm đè lên `SurfaceView` của
   `UnityPlayer` không (không bị đen, không bị che)?

---

## Phụ lục — helper dùng trong code mẫu

```java
  private static JSONObject obj(String k, Object v) { JSONObject o = new JSONObject(); put(o, k, v); return o; }
  private static void put(JSONObject o, String k, Object v) {
    try { o.put(k, v); } catch (JSONException ignored) { /* keys are literals */ }
  }
  private static String nz(String s) { return s != null ? s : ""; }

  private static String precision(int t) {
    switch (t) {
      case AdValue.PrecisionType.ESTIMATED:          return "estimated";
      case AdValue.PrecisionType.PUBLISHER_PROVIDED: return "publisherProvided";
      case AdValue.PrecisionType.PRECISE:            return "precise";
      default:                                       return "unknown";
    }
  }
} // end NativeAdManager
```

`Placement` là một value class nhỏ, chứa `mode` (anchor/rect), các field toạ độ và hàm
`toLayoutParams(Context)` để đổi đơn vị theo bảng ở §6.2. Phần này phụ thuộc vào engine nên không
viết sẵn ở đây.
